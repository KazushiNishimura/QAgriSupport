# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'import_mobile_ui.ui'
#
# Created: Tue Apr 11 18:05:04 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(779, 661)
        self.gridLayout_2 = QtGui.QGridLayout(Dialog)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tableWidget_report = QtGui.QTableWidget(self.groupBox)
        self.tableWidget_report.setObjectName(_fromUtf8("tableWidget_report"))
        self.tableWidget_report.setColumnCount(0)
        self.tableWidget_report.setRowCount(0)
        self.gridLayout.addWidget(self.tableWidget_report, 0, 0, 1, 2)
        self.gridLayout_2.addWidget(self.groupBox, 0, 0, 3, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.tableWidget_operator = QtGui.QTableWidget(self.groupBox_2)
        self.tableWidget_operator.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_operator.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_operator.setObjectName(_fromUtf8("tableWidget_operator"))
        self.tableWidget_operator.setColumnCount(0)
        self.tableWidget_operator.setRowCount(0)
        self.gridLayout_3.addWidget(self.tableWidget_operator, 0, 0, 1, 2)
        self.gridLayout_2.addWidget(self.groupBox_2, 0, 1, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tableWidget_machine = QtGui.QTableWidget(self.groupBox_3)
        self.tableWidget_machine.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_machine.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_machine.setObjectName(_fromUtf8("tableWidget_machine"))
        self.tableWidget_machine.setColumnCount(0)
        self.tableWidget_machine.setRowCount(0)
        self.gridLayout_4.addWidget(self.tableWidget_machine, 0, 0, 1, 2)
        self.gridLayout_2.addWidget(self.groupBox_3, 1, 1, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.tableWidget_material = QtGui.QTableWidget(self.groupBox_4)
        self.tableWidget_material.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_material.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_material.setObjectName(_fromUtf8("tableWidget_material"))
        self.tableWidget_material.setColumnCount(0)
        self.tableWidget_material.setRowCount(0)
        self.gridLayout_5.addWidget(self.tableWidget_material, 0, 0, 1, 2)
        self.gridLayout_2.addWidget(self.groupBox_4, 2, 1, 2, 1)
        self.btn_show_attribute_table = QtGui.QPushButton(Dialog)
        self.btn_show_attribute_table.setObjectName(_fromUtf8("btn_show_attribute_table"))
        self.gridLayout_2.addWidget(self.btn_show_attribute_table, 3, 0, 1, 1)
        self.btn_import = QtGui.QPushButton(Dialog)
        self.btn_import.setObjectName(_fromUtf8("btn_import"))
        self.gridLayout_2.addWidget(self.btn_import, 4, 1, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "モバイルデータの取り込み", None))
        self.groupBox.setTitle(_translate("Dialog", "新規作業実績", None))
        self.groupBox_2.setTitle(_translate("Dialog", "作業者一覧", None))
        self.groupBox_3.setTitle(_translate("Dialog", "使用機材一覧", None))
        self.groupBox_4.setTitle(_translate("Dialog", "使用資材一覧", None))
        self.btn_show_attribute_table.setText(_translate("Dialog", "圃場テーブルの表示", None))
        self.btn_import.setText(_translate("Dialog", "データの取り込み", None))

