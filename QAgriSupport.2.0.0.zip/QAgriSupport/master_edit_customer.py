# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from master_edit_customer_ui import  Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_table()

        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)


    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")

        cursor=db.cursor()
        cursor.execute("select id ,customer from customer_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tablewidget_customor.clear()
        self.ui.tablewidget_customor.setSortingEnabled(True)
        self.ui.tablewidget_customor.setRowCount(row_count)
        headers=["id",u"販売先"]
        self.ui.tablewidget_customor.setColumnCount(len(headers))
        self.ui.tablewidget_customor.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_customor.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_customor.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tablewidget_customor.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_customor.setItem(i,1,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tablewidget_customor.resizeColumnsToContents()
        self.ui.tablewidget_customor.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.ledit_customor.text()=="":
            pyqgis_processing.show_msgbox(u"生育ステージを入力してください")
            return
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        growth_stage=self.ui.ledit_customor.text()
        new_row=(growth_stage,growth_stage)
        db.execute('insert into customer_master (customor,customer) values (?,?)',new_row)
        db.commit()
        db.close()
        self.ui.ledit_customor.clear()
        self.populate_table()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        for i in range(0,self.ui.tablewidget_customor.rowCount()):
            if self.ui.tablewidget_customor.item(i,0).isSelected()==True:
                db.execute('delete from customer_master where id = ?',(int(self.ui.tablewidget_customor.item(i,0).text()),))


        db.commit()
        db.close()

        self.populate_table()


