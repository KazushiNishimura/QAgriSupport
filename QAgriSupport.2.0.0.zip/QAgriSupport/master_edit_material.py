# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from master_edit_material_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox()

        self.connect(self.ui.cmb_box_crop, SIGNAL("currentIndexChanged(const QString&)"),self.populate_table)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.ui.tableWidget_material.itemSelectionChanged.connect(self.selection_changed)
        self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)

    def populate_cmbbox(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()

        self.ui.cmb_box_crop.clear()
        self.ui.cmb_box_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmb_box_crop.addItem(row[0])

    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=db.cursor()
        cursor.execute('select id,material,material_unit,package_unit,package_amount from material_master where crop=?',(self.ui.cmb_box_crop.currentText(),))
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tableWidget_material.clear()
        self.ui.tableWidget_material.setSortingEnabled(True)
        self.ui.tableWidget_material.setRowCount(row_count)
        headers=["id",u"資材名",u"資材単位",u"パッケージ単位",u"パッケージ当たり数量"]
        self.ui.tableWidget_material.setColumnCount(len(headers))
        self.ui.tableWidget_material.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_material.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_material.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tableWidget_material.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_material.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_material.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tableWidget_material.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tableWidget_material.setItem(i,4,QTableWidgetItem(str(int(row[4]))))
            i=i+1
        self.ui.tableWidget_material.resizeColumnsToContents()
        self.ui.tableWidget_material.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.lineEdit_name1.text()=="":
            pyqgis_processing.show_msgbox(u"資材名を入力してください")
            return
        if self.ui.lineEdit_unit1.text()=="":
            pyqgis_processing.show_msgbox(u"資材単位を入力してください")
            return
        if self.ui.lineEdit_package1.text()=="":
            pyqgis_processing.show_msgbox(u"パッケージ単位を入力してください")
            return
        if self.ui.lineEdit_amount1.text()=="":
            pyqgis_processing.show_msgbox(u"パッケージ当たり数量を入力してください")
            return

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        crop =self.ui.cmb_box_crop.currentText()
        material_name=self.ui.lineEdit_name1.text()
        material_unit=self.ui.lineEdit_unit1.text()
        material_package=self.ui.lineEdit_package1.text()
        package_amount=float(self.ui.lineEdit_amount1.text())
        new_row=(crop,material_name,material_unit,material_package,package_amount)
        db.execute('insert into material_master (crop,material,material_unit,package_unit,package_amount) values (?,?,?,?,?)',new_row)
        db.commit()
        db.close()
        self.ui.lineEdit_name1.clear()
        self.ui.lineEdit_unit1.clear()
        self.ui.lineEdit_package1.clear()
        self.ui.lineEdit_amount1.clear()
        self.populate_table()

    def selection_changed(self):
        rows=[]
        for index in self.ui.tableWidget_material.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            self.ui.lineEdit_name2.setText(self.ui.tableWidget_material.item(row,1).text())
            self.ui.lineEdit_unit2.setText(self.ui.tableWidget_material.item(row,2).text())
            self.ui.lineEdit_package2.setText(self.ui.tableWidget_material.item(row,3).text())
            self.ui.lineEdit_amount2.setText(self.ui.tableWidget_material.item(row,4).text())

    def update_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=db.cursor()
        rows=[]
        for index in self.ui.tableWidget_material.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        if len(rows)==0:
            pyqgis_processing.show_msgbox(u"対象資材を選択してください")
            return
        for row in rows:
            material_name=self.ui.lineEdit_name2.text()
            material_unit=self.ui.lineEdit_unit2.text()
            material_package=self.ui.lineEdit_package2.text()
            package_amount=self.ui.lineEdit_amount2.text()
            id=int(self.ui.tableWidget_material.item(row,0).text())
            cursor.execute('update material_master set material=?,material_unit=?,package_unit=?,package_amount=? where id=?',(material_name,material_unit,material_package,package_amount,id,))
            self.ui.tableWidget_material.setItem(row,0,QTableWidgetItem(str(id)))
            self.ui.tableWidget_material.setItem(row,1,QTableWidgetItem(material_name))
            self.ui.tableWidget_material.setItem(row,2,QTableWidgetItem(material_unit))
            self.ui.tableWidget_material.setItem(row,3,QTableWidgetItem(material_package))
            self.ui.tableWidget_material.setItem(row,4,QTableWidgetItem(package_amount))

        db.commit()
        db.close()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        rows=[]
        for index in self.ui.tableWidget_material.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            db.execute('delete from material_master where id=?',(int(self.ui.tableWidget_material.item(row,0).text()),))

        db.commit()
        db.close()

        self.populate_table()

