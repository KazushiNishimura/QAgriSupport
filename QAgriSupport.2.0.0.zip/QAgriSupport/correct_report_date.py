# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from correct_report_date_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,dlg):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.dlg=dlg
        self.ui.dateEdit.setDate(datetime.date.today())

        self.connect(self.ui.btn_ok,SIGNAL("clicked()"),self.ok)
        self.connect(self.ui.btn_cancel,SIGNAL("clicked()"),self.cancel)

    def ok(self):
        self.dlg.date=self.ui.dateEdit.date().toString("yyyy/MM/dd")
        self.close()

    def cancel(self):
        self.dlg.date="cancel"
        self.close()