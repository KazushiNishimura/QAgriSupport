# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_stock_yard_ui.ui'
#
# Created: Wed Mar 04 11:47:46 2020
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(646, 958)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tablewidget_stock_yard = QtGui.QTableWidget(Dialog)
        self.tablewidget_stock_yard.setObjectName(_fromUtf8("tablewidget_stock_yard"))
        self.tablewidget_stock_yard.setColumnCount(0)
        self.tablewidget_stock_yard.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_stock_yard)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.ledit_stock_yard = QtGui.QLineEdit(self.groupBox)
        self.ledit_stock_yard.setObjectName(_fromUtf8("ledit_stock_yard"))
        self.gridLayout.addWidget(self.ledit_stock_yard, 0, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout.addWidget(self.btn_insert, 1, 1, 1, 1)
        self.verticalLayout_2.addWidget(self.groupBox)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_2)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.verticalLayout.addWidget(self.btn_delete)
        self.verticalLayout_2.addWidget(self.groupBox_2)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "保管場所登録", None))
        self.groupBox.setTitle(_translate("Dialog", "保管場所登録", None))
        self.label.setText(_translate("Dialog", "保管場所", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox_2.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

