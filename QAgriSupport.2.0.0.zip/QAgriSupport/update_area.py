# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from update_area_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import csv
import sqlite3
import types

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.list_csv=[]
        self.load_csv()

        proc=pyqgis_processing

        #proc.remove_join()
        proc.clear_query(self.farmland_table)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_kind()

        self.render_farmland()

        self.farmland_table.selectionChanged.connect(self.selection_changed)
        self.connect(self.ui.btn_update_area_selected,SIGNAL("clicked()"),self.update_area_selected)
        self.connect(self.ui.btn_update_all,SIGNAL("clicked()"),self.update_area_all)
        self.connect(self.ui.btn_write_geom,SIGNAL("clicked()"),self.write_geom)
        self.connect(self.ui.btn_farmland_code,SIGNAL("clicked()"),self.update_farmland_code)
        self.connect(self.ui.btn_district,SIGNAL("clicked()"),self.update_district)
        self.connect(self.ui.btn_kind,SIGNAL("clicked()"),self.update_kind)
        self.connect(self.ui.btn_area,SIGNAL("clicked()"),self.update_area)

    def populate_cmbbox_kind(self):
        self.ui.cmbbox_kind.addItem(u"経営耕地")
        self.ui.cmbbox_kind.addItem(u"受託地")
        self.ui.cmbbox_kind.addItem(u"その他")

    def create_renderer_rule(self):
        list_rule=[]
        query_string= '\"kind\" ='+ u'\'経営耕地\''
        label_string=u"経営耕地"
        list_rule.append([label_string,query_string])
        query_string= '\"kind\" ='+ u'\'受託地\''
        label_string=u"受託地"
        list_rule.append([label_string,query_string])
        query_string= '\"kind\" ='+ u'\'その他\''
        label_string=u"その他"
        list_rule.append([label_string,query_string])

        return list_rule

    def render_farmland(self):
        pyqgis_processing.renderer_map1(self.farmland_table, self.create_renderer_rule())
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def load_csv(self):
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        table_csv=open(path + "/"+u"農地台帳.csv")
        data=csv.reader(table_csv)
        header = data.next()

        for row in data:
            self.list_csv.append([row[0].decode("cp932"),row[1].decode("cp932"),row[2].decode("cp932"),row[3].decode("cp932"),row[4].decode("cp932"),row[5].decode("cp932")])


    def selection_changed(self):
        self.population_tablewidget_land()
        self.get_farmland_info()


    def update_farmland_code(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        if self.ui.lineEdit_farmland_code.text()=='':
            pyqgis_processing.show_msgbox(u"圃場名を入力してください")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('farmland_code'):self.ui.lineEdit_farmland_code.text()}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            self.ui.lbl_landfield.setText(self.ui.lineEdit_farmland_code.text())
            break
        self.get_farmland_info()

    def update_district(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        if self.ui.lineEdit_district.text()=='':
            pyqgis_processing.show_msgbox(u"地区名を入力してください")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('district'):self.ui.lineEdit_district.text()}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})

            break
        self.get_farmland_info()

    def update_kind(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('kind'):self.ui.cmbbox_kind.currentText()}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})

            break

        self.get_farmland_info()

    def update_area(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        if self.ui.lineEdit_area.text()=='':
            pyqgis_processing.show_msgbox(u"面積を入力してください")
            return
        for feature in features:
            try:
                new_value={feature.fieldNameIndex('land_area'):float(self.ui.lineEdit_area.text())}
            except:
                pyqgis_processing.show_msgbox(u"数値を入力してください")
                return
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            self.get_farmland_info()

            break

        self.get_farmland_info()

    def get_farmland_info(self):
        features=self.farmland_table.selectedFeatures()
        for feature in features:
            try:
                self.ui.lineEdit_farmland_code.setText(feature['farmland_code'])
            except:
                self.ui.lineEdit_farmland_code.setText('')
            try:
                self.ui.lineEdit_district.setText(feature['district'])
            except:
                self.ui.lineEdit_district.setText('')
            try:
                if feature['kind']==u'経営耕地':
                    self.ui.cmbbox_kind.setCurrentIndex(0)
                elif feature['kind']==u'受託地':
                    self.ui.cmbbox_kind.setCurrentIndex(1)
                else:
                    self.ui.cmbbox_kind.setCurrentIndex(2)
            except:
                pass
            try:
                self.ui.lineEdit_area.setText(str(feature['land_area']))
            except:
                self.ui.lineEdit_area.setText('')

            break

    def population_tablewidget_land(self):
        features=self.farmland_table.selectedFeatures()
        for feature in features:
            farmland_code=feature['farmland_code']
            try:
                self.ui.lbl_landfield.setText(farmland_code)
            except:
                self.ui.lbl_landfield.setText('')
            break

        try:

            list_filter=filter(lambda x: x[1]==farmland_code,self.list_csv)
            self.ui.tablewidget_land.clear()
            self.ui.tablewidget_land.setSortingEnabled(True)
            self.ui.tablewidget_land.setRowCount(len(list_filter))
            headers=[u"地区",u"圃場名",u"地名地番",u"台帳面積",u"実利用面積",u"地権者"]
            self.ui.tablewidget_land.setColumnCount(len(headers))
            self.ui.tablewidget_land.setHorizontalHeaderLabels(headers)

            i=0
            sum_area=0
            for item in list_filter:
                self.ui.tablewidget_land.setItem(i,0,QTableWidgetItem(str(item[0])))
                self.ui.tablewidget_land.setItem(i,1,QTableWidgetItem(str(item[1])))
                self.ui.tablewidget_land.setItem(i,2,QTableWidgetItem(str(item[2])))
                self.ui.tablewidget_land.setItem(i,3,QTableWidgetItem(str(item[3])))
                self.ui.tablewidget_land.setItem(i,4,QTableWidgetItem(str(item[4])))
                self.ui.tablewidget_land.setItem(i,5,QTableWidgetItem(str(item[5])))
                sum_area=sum_area+float(item[4])

                i=i+1
            self.ui.lbl_area.setText(str(sum_area))
            self.ui.tablewidget_land.resizeColumnsToContents()
        except:
            pass

    def update_area_selected(self):
        area=float(self.ui.lbl_area.text())
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"複数枚の圃場が選択されています")
            return
        for feature in features:
            new_value={feature.fieldNameIndex('land_area'):area}
            self.farmland_table.dataProvider().changeAttributeValues({feature.id():new_value})
            break

        self.get_farmland_info()

    def update_area_all(self):
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'進捗状況')
        max = len(self.list_csv)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)

        widget.show()
        widget.raise_()

        self.farmland_table.startEditing()
        features=self.farmland_table.getFeatures()
        i=1
        for feature in features:
            pbar.setValue(i)
            farmland_code=feature['farmland_code']
            #print farmland_code
            list_filter=filter(lambda x: x[1]==farmland_code,self.list_csv)
            sum_area=0
            for item in list_filter:
                sum_area=sum_area+float(item[4])
            if sum_area!=0:
                feature[feature.fieldNameIndex('land_area')]=sum_area
            else:
                feature[feature.fieldNameIndex('land_area')]=0
            self.farmland_table.updateFeature(feature)
            i=i+1

        self.farmland_table.commitChanges()
        self.farmland_table.endEditCommand()

        self.get_farmland_info()


    def write_geom(self):
        self.write_vertex(self.farmland_table.getFeatures())
        self.write_centroid(self.farmland_table.getFeatures())

    def write_vertex(self,features):
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'頂点座標計算中')
        max = self.farmland_table.featureCount()
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)

        widget.show()
        widget.raise_()
        self.farmland_table.startEditing()
        i=1
        for feature in features:
            pbar.setValue(i)
            geom=QgsGeometry(feature.geometry())
            sourcecrs=self.farmland_table.crs()
            targetcrs=QgsCoordinateReferenceSystem(4326)
            crstransform=QgsCoordinateTransform(sourcecrs,targetcrs)
            geom.transform(crstransform)
            points=[]
            polygon = geom.asPolygon()
            for line in polygon:
                points.extend(line)
            str_point=""
            for point in points:
                str_point=str_point + str(point.y())+"|"+str(point.x())+","
            str_point=str_point[:-1]
            #print type(str_point)
            feature[feature.fieldNameIndex('vertex')]=str_point

            self.farmland_table.updateFeature(feature)
            i=i+1
        self.farmland_table.commitChanges()
        self.farmland_table.endEditCommand()

    def write_centroid(self,features):
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'重心座標計算中')
        max = self.farmland_table.featureCount()
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, max)

        widget.show()
        widget.raise_()
        self.farmland_table.startEditing()
        i=1
        for feature in features:
            pbar.setValue(i)
            geom=QgsGeometry(feature.geometry())
            sourcecrs=self.farmland_table.crs()
            targetcrs=QgsCoordinateReferenceSystem(4326)
            crstransform=QgsCoordinateTransform(sourcecrs,targetcrs)
            geom.transform(crstransform)
            cgeom=geom.centroid()
            point=cgeom.asPoint()
            str_point=""
            str_point=str_point + str(point.y())+"|"+str(point.x()) +","
            str_point=str_point[:-1]
#             print type(str_point)
#             print str_point
            feature[feature.fieldNameIndex('centroid')]=str_point
            #feature[feature.fieldNameIndex('centroid')]="test"
            self.farmland_table.updateFeature(feature)
            i=i+1
        self.farmland_table.commitChanges()
        self.farmland_table.endEditCommand()




