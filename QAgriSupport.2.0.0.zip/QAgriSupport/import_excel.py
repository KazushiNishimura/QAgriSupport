# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
# from import_mobile_ui import Ui_Dialog
from import_excel_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime
import sys

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,db_path,year):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.year=year
        self.db_path=db_path


        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\' or "kind"=\'受託地\'')

        #proc.add_join_operation_table()

        proc.hide_all_columns(self.farmland_table)
        proc.set_column_visibility(self.farmland_table,'operation_table_operator',True)
        proc.set_column_visibility(self.farmland_table,'operation_table_operation_day',True)

        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        proc.renderer_simple(self.farmland_table)


        self.populate_tablewidget_report()


        #self.ui.tableWidget_report.itemClicked.connect(self.populate_tablewidgets)
        self.ui.tablewidget_report.itemSelectionChanged.connect(self.selection_changed)
#         self.connect(self.ui.btn_import,SIGNAL("clicked()"),self.insert_row)

        self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.insert_row_report)
#         self.connect(self.ui.btn_import_product,SIGNAL("clicked()"),self.insert_row_product)
#         self.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
#         self.connect(self.ui.btn_import_shipment,SIGNAL("clicked()"),self.update_shipping_inspection)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_report)
#         self.connect(self.ui.btn_correct_date,SIGNAL("clicked()"),self.correct_date)
#         self.connect(self.ui.btn_correct_operator,SIGNAL("clicked()"),self.correct_operator)
#         self.connect(self.ui.btn_delete_suboperator,SIGNAL("clicked()"),self.delete_sub_operator)
#         self.connect(self.ui.btn_correct_suboperator,SIGNAL("clicked()"),self.correct_suboperator)
#         self.connect(self.ui.btn_correct_machine,SIGNAL("clicked()"),self.correct_machine)
#         self.connect(self.ui.btn_delete_machine,SIGNAL("clicked()"),self.delete_machine)

    def return_key_value(self):
        row_count=self.ui.tablewidget_report.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_report.item(i,0).isSelected()==True:
                operation_day=self.ui.tablewidget_report.item(i,1).text()
                crop=self.ui.tablewidget_report.item(i,2).text()
                operation=self.ui.tablewidget_report.item(i,3).text()
                operator=self.ui.tablewidget_report.item(i,4).text()
                break
        key_value=(operation_day,crop,operation,operator)
        #print operator
        return key_value

    def selection_changed(self):
        try:
            self.select_landfields()
        except:
            return

    def select_landfields(self):
        proc=pyqgis_processing

        #
        mobile_db=sqlite3.connect(self.db_path)
        query="select farmland_code from operation_table where operation_day=? and crop=? and operation=? and operator=?"
        cursor=mobile_db.cursor()
        cursor.execute(query,self.return_key_value())
        rows=cursor.fetchall()

        list_id=[]
        for row in rows:
            query="select pkuid from farmland_table where farmland_code=?"
            cursor=mobile_db.cursor()
            cursor.execute(query,(row[0],))
            id=cursor.fetchone()[0]

            list_id.append(id)

        proc.select_features(self.farmland_table, list_id)

    def populate_tablewidget_report(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="select id,operation_day , crop, operation,operator from report_table "
        try:
            cursor.execute(query)
        except:
            pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
            return
        rows=cursor.fetchall()
        list_mobile_data=[]
        for row in rows:
            key=[row[1],row[2],row[3],row[4]]
            cursor=db.cursor()
            query="SELECT count(*)  FROM report_table WHERE operation_day=? and crop = ? and operation = ? and operator= ?"
            cursor.execute(query,key)
            count = cursor.fetchone()[0]
            if count == 0:
                list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])
#             list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])

        self.ui.tablewidget_report.clear()
        self.ui.tablewidget_report.setSortingEnabled(True)
        self.ui.tablewidget_report.setRowCount(len(list_mobile_data))
        headers=["id",u"作業実施日",u"作物",u"作業名",u"作業者名"]
        self.ui.tablewidget_report.setColumnCount(len(headers))
        self.ui.tablewidget_report.setHorizontalHeaderLabels(headers)
        i=0
        for row in list_mobile_data:
            self.ui.tablewidget_report.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_report.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tablewidget_report.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_report.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tablewidget_report.setItem(i,4,QTableWidgetItem(row[4]))
            i=i+1
        self.ui.tablewidget_report.resizeColumnsToContents()
        self.ui.tablewidget_report.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ui.tablewidget_report.hideColumn(0)

    def insert_row_report(self):

        row_count=self.ui.tablewidget_report.rowCount()
        selection=False
        for i in range(row_count):
            if self.ui.tablewidget_report.item(i,0).isSelected()==True:
                selection=True
                break
        if selection==False:
            pyqgis_processing.show_msgbox(u"インポート対象の日報を選択してください。")

            return

        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        key=self.return_key_value()
        year=self.year
        crop=key[1]
        operation=key[2]
        operator=key[3]
        operation_day=key[0]

        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]
            sql=u""" update operation_table set  operator=?,operation_day=?, progress = '完了'
            where year=? and crop = ? and operation =? and farmland_code=?"""
            update_row=(operator,operation_day,year,crop,operation,farmland_code)
            db.execute(sql,update_row)
        db.commit()



        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

        #台帳テーブルへの登録
        insert_row=(crop,operation,operator,operation_day)
        sql=u"""insert into report_table (crop,operation,operator,operation_day) values(?,?,?,?)"""
        db.execute(sql,insert_row)
        db.commit()
        db.close()

        pyqgis_processing.show_msgbox(u"作業日："+key[0]+u"　作物："+key[1]+u"　作業："+key[2]+u"　作業者："+key[3]+u"を登録しました")


        self.populate_tablewidget_report()
#         self.load_data()


