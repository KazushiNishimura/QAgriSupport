# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_customer_ui.ui'
#
# Created: Thu Mar 05 08:59:10 2020
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(308, 458)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tablewidget_customor = QtGui.QTableWidget(Dialog)
        self.tablewidget_customor.setObjectName(_fromUtf8("tablewidget_customor"))
        self.tablewidget_customor.setColumnCount(0)
        self.tablewidget_customor.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_customor)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.ledit_customor = QtGui.QLineEdit(self.groupBox)
        self.ledit_customor.setObjectName(_fromUtf8("ledit_customor"))
        self.gridLayout.addWidget(self.ledit_customor, 0, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout.addWidget(self.btn_insert, 1, 1, 1, 1)
        self.verticalLayout_2.addWidget(self.groupBox)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_2)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.verticalLayout.addWidget(self.btn_delete)
        self.verticalLayout_2.addWidget(self.groupBox_2)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "販売先登録", None))
        self.groupBox.setTitle(_translate("Dialog", "販売先登録", None))
        self.label.setText(_translate("Dialog", "販売先", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox_2.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

