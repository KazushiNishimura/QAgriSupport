# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from operating_plan_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.year=y
        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.cropping_table=proc.get_cropping_table()

        #テーブル結合削除コード↓
        #proc.remove_join()

        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.clear_query(self.cropping_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\'')

        proc.set_query(self.cropping_table,'"year"='+str(self.year))
        proc.set_query(self.operation_table,'"year"='+str(self.year))

        #テーブル結合コード↓
        #proc.add_join_cropping_table()
        #proc.add_join_operation_table()

        proc.hide_all_columns(self.farmland_table)
        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_cropping_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_column_visibility(self.farmland_table, "operation_table_progress", True)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_cropping_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        self.ui.tableWidget_sum.setVisible(False)

        self.populate_cmbbox_crop()
        self.populate_cmbbox_operator()
        self.ui.dateEdit_start.setDate(datetime.date.today())
        self.ui.dateEdit_end.setDate(datetime.date.today())
        self.connect(self.ui.cmbbox_crop_2,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
        self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)

        self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_insert_2,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
        self.ui.gbox_sum.clicked.connect(self.gbox_sum_expand)
        self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
        self.connect(self.ui.chkbox_progress,SIGNAL("stateChanged (int)"),self.check_progress)
#         self.connect(self.ui.chkbox_progress,SIGNAL("stateChanged (int)"),self.populate_sum_table)
#         self.connect(self.ui.chkbox_progress,SIGNAL("stateChanged (int)"),self.renderer_map)
        #self.ui.tableWidget_sum.itemClicked.connect(self.select_landfields)
        self.ui.tableWidget_sum.itemSelectionChanged.connect(self.select_landfields)


        self.farmland_table.selectionChanged.connect(self.sum_selected_area)

    def check_variety(self):
        if self.ui.chkbox_variety.checkState()==Qt.Checked:
            pyqgis_processing.add_rule_variety(self.ui.cmbbox_crop_2.currentText())
        elif self.ui.chkbox_variety.checkState()==Qt.Unchecked:
            self.renderer_map()

    def check_progress(self):
        self.populate_sum_table()
        self.renderer_map()

    def cmbbox_crop_change(self):
        self.populate_cmbbox_operate()
        self.set_query_cropping_table()

    def cmbbox_operate_change(self):
        self.set_query_operation_table()
        self.populate_sum_table()
        self.renderer_map()
        self.check_variety()





    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        self.ui.cmbbox_crop_2.addItem("")
        for row in proc.return_crop():
            self.ui.cmbbox_crop_2.addItem(row[0])



    def populate_cmbbox_operate(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        crop=self.ui.cmbbox_crop_2.currentText()
        cursor=db.cursor()
        cursor.execute("select operation from cultivation_calendar_master where crop=?",(crop,))
        rows=cursor.fetchall()
        self.ui.cmbbox_operate.clear()
        for row in rows:
            self.ui.cmbbox_operate.addItem(row[0])

        db.close()

    def gbox_sum_expand(self):
        if self.ui.gbox_sum.isChecked()==True:
            self.ui.tableWidget_sum.setVisible(True)
        else:
            self.ui.tableWidget_sum.setVisible(False)

    def create_query_string_crop(self):

        crop=self.ui.cmbbox_crop_2.currentText()


        query_string=""" "year"=%s and "crop"='%s' """ %(str(self.year),crop)
        return query_string

    def set_query_cropping_table(self):
        pyqgis_processing.set_query(self.cropping_table,self.create_query_string_crop())


    def create_query_string_operation(self):
        operation=self.ui.cmbbox_operate.currentText()
        crop=self.ui.cmbbox_crop_2.currentText()
        query_string=""" "year"=%s and "crop"='%s' and "operation"='%s'""" %(str(self.year),crop,operation)

        return query_string

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table, self.create_query_string_operation())


    def populate_sum_table(self):
        self.ui.tableWidget_sum.clear()
        self.ui.tableWidget_sum.setSortingEnabled(True)
        headers=[u"作業予定期間",u"作業予定者",u"面積"]
        self.ui.tableWidget_sum.setColumnCount(len(headers))
        self.ui.tableWidget_sum.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_sum.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_sum.setRowCount(0)
        proc=pyqgis_processing
        year=self.year
        crop=self.ui.cmbbox_crop_2.currentText()
        operation=self.ui.cmbbox_operate.currentText()
        if self.ui.chkbox_progress.checkState()==Qt.Unchecked:
            query_string=proc.create_sql_string_plan()
        else:
            query_string=proc.create_sql_string_plan2()
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(query_string,(year,crop,operation,year,crop))
        rows=cursor.fetchall()
        i=0
        for row in rows:

            self.ui.tableWidget_sum.insertRow(i)
            self.ui.tableWidget_sum.setItem(i,0,QTableWidgetItem(row[0]))
            self.ui.tableWidget_sum.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_sum.setItem(i,2,QTableWidgetItem(str(round(row[2],1))))
            i=i+1




    def show_attribute_table(self):
        if self.ui.cmbbox_crop_2.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        pyqgis_processing.clear_attributetable()

        layer=self.farmland_table

        if self.attribute_table==None:
            self.attribute_table=iface.showAttributeTable(layer)
            self.attribute_table.finished.connect(self.none_attribute_table)

    def none_attribute_table(self):
        self.attribute_table=None



    def populate_cmbbox_operator(self):
        db=pyqgis_processing.connect_db()
        cursor=db.cursor()
        cursor.execute("select operator from operator_master ")
        rows=cursor.fetchall()
        self.ui.cmbbox_operator.clear()
        for row in rows:
            self.ui.cmbbox_operator.addItem(row[0])
        db.close()

    def insert_row(self):
        db=pyqgis_processing.connect_db()
        year=self.year
        crop=self.ui.cmbbox_crop_2.currentText()
        operation=self.ui.cmbbox_operate.currentText()
        term_start=self.ui.dateEdit_start.dateTime().toString("yyyy/MM/dd")
        term_end=self.ui.dateEdit_end.dateTime().toString("yyyy/MM/dd")
        term_start_= "{0:02d}".format(self.ui.dateEdit_start.date().month())+ "/"  +"{0:02d}".format(self.ui.dateEdit_start.date().day())
        term_end_="{0:02d}".format(self.ui.dateEdit_end.date().month())+"/"+"{0:02d}".format(self.ui.dateEdit_end.date().day())
        term=term_start_ + "-" + term_end_
        operator=self.ui.cmbbox_operator.currentText()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return

        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]
            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            #既存計画値のチェック
            if feature[u'operation_table_operation_schedule'] is not None:
                if feature[u'operation_table_progress'] ==u"未完了":
                    exist_row=(year,farmland_code,crop,operation)
                    db.execute('delete from operation_table where year=? and farmland_code=? and crop=? and operation=?',exist_row)
                    db.commit()
                    new_row=(year,farmland_code,crop,operation,term_start,term_end,term,operator,u"未完了")
                    #ここで作業状況のデフォルト値「未完了」を入れておく
                    db.execute('insert into operation_table (year,farmland_code,crop,operation,schedule_start,schedule_end,operation_schedule,operator_candidate,progress) values (?,?,?,?,?,?,?,?,?)',new_row)
                    db.commit()
            else:
                new_row=(year,farmland_code,crop,operation,term_start,term_end,term,operator,u"未完了")
                #ここで作業状況のデフォルト値「未完了」を入れておく
                db.execute('insert into operation_table (year,farmland_code,crop,operation,schedule_start,schedule_end,operation_schedule,operator_candidate,progress) values (?,?,?,?,?,?,?,?,?)',new_row)
                db.commit()

        db.close()
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()
        self.populate_sum_table()
        #レンダリングのルールを変えるわけではないから、下記は不要か？→必要！
        self.renderer_map()
    def create_renderer_rule_string(self):
        list_rule=[]
        #対象作物で、作業名がないレコードを設定
        crop=self.ui.cmbbox_crop_2.currentText()
        operation=self.ui.cmbbox_operate.currentText()

        row_count=self.ui.tableWidget_sum.rowCount()
        for i in xrange(row_count):
            term=self.ui.tableWidget_sum.item(i,0).text()
            operator=self.ui.tableWidget_sum.item(i,1).text()
            label_string=term+ ':'+operator
            query_string=""" "cropping_table_crop" ='%s' and "operation_table_operation" ='%s'
            and "operation_table_operation_schedule" = '%s' and "operation_table_operator_candidate" ='%s'"""  %(crop,operation,term,operator)
            list_rule.append([label_string,query_string])

        return list_rule

    #0928追加
    def create_renderer_rule_string_progress(self):
        list_rule=[]
        #対象作物で、作業名がないレコードを設定
        crop=self.ui.cmbbox_crop_2.currentText()
        operation=self.ui.cmbbox_operate.currentText()

        row_count=self.ui.tableWidget_sum.rowCount()
        for i in xrange(row_count):
            term=self.ui.tableWidget_sum.item(i,0).text()
            operator=self.ui.tableWidget_sum.item(i,1).text()
            label_string=term+ ':'+operator
            query_string=u""" "cropping_table_crop" ='%s' and "operation_table_operation" ='%s'
            and "operation_table_operation_schedule" = '%s' and "operation_table_operator_candidate" ='%s' and "operation_table_progress" ='未完了'"""  %(crop,operation,term,operator)
            list_rule.append([label_string,query_string])

        return list_rule

    def renderer_map(self):
        layer=self.farmland_table
        crop =self.ui.cmbbox_crop_2.currentText()
        #0928
        if self.ui.chkbox_progress.checkState()==Qt.Unchecked:
            list_rule=self.create_renderer_rule_string()
        else:
            list_rule=self.create_renderer_rule_string_progress()
        rule_count=len(list_rule)
        if rule_count>0:
            hsv_delta=240/rule_count
        else:
            hsv_delta=0
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u"未設定"
#         query_string= '\"cropping_table_crop\" ='+ '\''+ crop +'\''+' and ' '\"operation_table_operation\" is None'
        query_string=""" "cropping_table_crop" ='%s' and "operation_table_operation" is None""" %(crop)
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        i=0
        for rule_string in list_rule:
            rule=root_rule.children()[0].clone()
            rule.setLabel(rule_string[0])
            rule.setFilterExpression(rule_string[1])
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            rule.symbol().setColor(color)
            root_rule.appendChild(rule)
            i=i+1

        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def delete_row(self):
        db=pyqgis_processing.connect_db()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)
        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]
            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            delete_row=(self.year,farmland_code,feature[u'cropping_table_crop'],feature[u'operation_table_operation'])
            db.execute('delete from operation_table where year=? and farmland_code=? and crop = ? and operation=? and progress="未完了"',delete_row)
        db.commit()
        db.close()
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()
        self.populate_sum_table()
        self.renderer_map()

    def sum_selected_area(self):
        if self.ui.chkbox_progress.checkState()==Qt.Unchecked:
            sum_area=pyqgis_processing.sum_selected_features(self.farmland_table)
        else:
            sum_area=pyqgis_processing.sum_selected_features_progress(self.farmland_table)
        self.ui.lbl_area_selected_features.setText(str(round(sum_area,1))+u"m2選択中")

    def add_rule_variety(self):
        proc=pyqgis_processing
        crop=self.ui.cmbbox_crop_2.currentText()
        list_variety=[]
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select variety from crop_master where crop=? ",(crop,))
        rows=cursor.fetchall()
        for row in rows:
            list_variety.append(row[0])
        db.close()
        variety_count=len(list_variety)
        if variety_count>0:
            hsv_delta=240/variety_count
        else:
            hsv_delta=0
        renderer=self.farmland_table.rendererV2()
        root_rule=renderer.rootRule()
        children_rule=root_rule.children()
        model_rule=root_rule.children()[0].clone()
        for rule in children_rule:
            i=0
            for variety in list_variety:
                query_label=u"品種"+variety
                query_string=""" "cropping_table_variety" ='%s'""" %(variety)
                subrule=model_rule.clone()
                subrule.setLabel(query_label)
                subrule.setFilterExpression(query_string)
                color=QColor()
                color.setHsv(240-(i*hsv_delta),255,255)
                subrule.symbol().setColor(color)
                rule.appendChild(subrule)
                i=i+1
        self.farmland_table.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()
        iface.legendInterface().refreshLayerSymbology(self.farmland_table)

    def remove_variety(self):
        renderer=self.farmland_table.rendererV2()
        root_rule=renderer.rootRule()
        children_rule=root_rule.children()
        subrule_count=len(children_rule)
        for rule in children_rule:
            for i in range(subrule_count):
                rule.removeChildAt(i)
        self.farmland_table.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()
        iface.legendInterface().refreshLayerSymbology(self.farmland_table)

    def select_landfields(self):
        proc=pyqgis_processing
        try:
            query=""" "operation_table_operation"= '%s' and "operation_table_operation_schedule"= '%s' and "operation_table_operator_candidate" = '%s'"""  %(self.return_key_value())
            #print query
            selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query))
            self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        except:
            pass

    def return_key_value(self):
        row_count=self.ui.tableWidget_sum.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_sum.item(i,0).isSelected()==True:
                term=self.ui.tableWidget_sum.item(i,0).text()
                operator=self.ui.tableWidget_sum.item(i,1).text()

                break
        key_value=(self.ui.cmbbox_operate.currentText(),term,operator)

        return key_value

