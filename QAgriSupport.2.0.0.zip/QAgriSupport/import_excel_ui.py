# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'import_excel_ui.ui'
#
# Created: Wed Mar 04 11:50:59 2020
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(656, 614)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tablewidget_report = QtGui.QTableWidget(Dialog)
        self.tablewidget_report.setObjectName(_fromUtf8("tablewidget_report"))
        self.tablewidget_report.setColumnCount(0)
        self.tablewidget_report.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_report, 0, 0, 1, 1)
        self.btn_update = QtGui.QPushButton(Dialog)
        self.btn_update.setObjectName(_fromUtf8("btn_update"))
        self.gridLayout.addWidget(self.btn_update, 1, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "も～ばいるデータの取り込み", None))
        self.btn_update.setText(_translate("Dialog", "データの反映", None))

