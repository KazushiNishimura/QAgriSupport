# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from dockwidgetui import Ui_DockWidget
from qgis.core import *
from qgis.gui import *
import datetime
from PyQt4.QtWebKit import  *
import webbrowser
from time import sleep
from QAgriSupport import pyqgis_processing
from QAgriSupport import setup_db
import os,sys


# ダイアログクラス
class DockWidget(QDockWidget, Ui_DockWidget):



    # 初期化QDockWidget
    def __init__(self, iface):
        QDockWidget.__init__(self)
        self.iface = iface
        self.crs=0

        if sys.platform == "win32":
            if not os.path.exists("c:/gisdata/management_db.sqlite"):
                ret = QMessageBox.information(None, u"確認", u"必要なデータベースが見つかりません。セットアップしますか？", QMessageBox.Yes, QMessageBox.No)
                if ret == QMessageBox.Yes:
                    setup_db.select_crs(self)
                    setup_db.copy_from_resource(self.crs)
                    pyqgis_processing.show_msgbox(u"データベース準備完了。c:/gisdata/agrimanagement.qgsから起動し直してください。")
                return
        else:
            if not os.path.exists(os.path.expanduser('~/gisdata/management_db.sqlite')):
                ret = QMessageBox.information(None, u"確認", u"必要なデータベースが見つかりません。セットアップしますか？", QMessageBox.Yes, QMessageBox.No)
                if ret == QMessageBox.Yes:
                    setup_db.select_crs(self)
                    setup_db.copy_from_resource(self.crs)
                    pyqgis_processing.show_msgbox(u"データベース準備完了。c:/gisdata/agrimanagement.qgsから起動し直してください。")
                return

        #モーバイルとの連携に必要なカラム、テーブルの確認
        self.check_report_table()
        self.check_product_table()
        self.check_tables()
        self.check_shipment_inspection_table()
        proc=pyqgis_processing
        if not os.path.exists(proc.get_prj_path() +"/mapimage"):
            os.mkdir(proc.get_prj_path() +"/mapimage")



    # QT Designer で作った画面を設定
        self.ui = Ui_DockWidget()
        self.ui.setupUi(self)

        self.year=self.get_year()
        self.ui.spbox_year.setValue(self.year)
        self.ui.cmbbox_label.addItem(u"ラベルなし")
        self.ui.cmbbox_label.addItem(u"農地名称")
        self.ui.cmbbox_label.addItem(u"品種")
        self.ui.cmbbox_label.addItem(u"依頼者")
        QObject.connect(self.ui.btn_usage, SIGNAL("clicked()"), self.renderer_landusage)
        QObject.connect(self.ui.btn_crop_master, SIGNAL("clicked()"),self.open_master_edit_crop)
        QObject.connect(self.ui.btn_calrender_master,SIGNAL("clicked()"),self.open_master_edit_cultivation_calendar)
        QObject.connect(self.ui.btn_contract_master,SIGNAL("clicked()"),self.open_master_edit_contract)
        QObject.connect(self.ui.btn_operator_master,SIGNAL("clicked()"),self.open_master_edit_operator)
        QObject.connect(self.ui.btn_client_master,SIGNAL("clicked()"),self.open_master_edit_client)
        QObject.connect(self.ui.btn_material_master,SIGNAL("clicked()"),self.open_master_edit_material)
        QObject.connect(self.ui.btn_machine_master,SIGNAL("clicked()"),self.open_master_edit_machine)
        QObject.connect(self.ui.btn_cropping_plan,SIGNAL("clicked()"),self.open_cropping_plan)
        QObject.connect(self.ui.btn_operating_plan,SIGNAL("clicked()"),self.open_operating_plan)
        QObject.connect(self.ui.btn_open_register_report,SIGNAL("clicked()"),self.open_register_report)
        QObject.connect(self.ui.btn_view_report,SIGNAL("clicked()"),self.open_view_report)
        QObject.connect(self.ui.btn_print,SIGNAL("clicked()"),self.print_map)
        QObject.connect(self.ui.btn_open_print_operation_plan,SIGNAL("clicked()"),self.open_print_operation_plan)
        QObject.connect(self.ui.btn_op_schedule,SIGNAL("clicked()"),self.open_renderer_operation_plan)
        QObject.connect(self.ui.btn_update_area,SIGNAL("clicked()"),self.open_update_area)
        QObject.connect(self.ui.btn_cropping_plan_adjust,SIGNAL("clicked()"),self.open_cropping_plan_adjust)
        QObject.connect(self.ui.btn_op_progress,SIGNAL("clicked()"),self.open_renderer_progress)
        QObject.connect(self.ui.btn_crop,SIGNAL("clicked()"),self.open_renderer_cropping_plan)
        QObject.connect(self.ui.btn_import_mobile,SIGNAL("clicked()"),self.open_mobile_importer)
        QObject.connect(self.ui.btn_contract_plan,SIGNAL("clicked()"),self.open_contract_plan)
        QObject.connect(self.ui.btn_contract_operate_plan,SIGNAL("clicked()"),self.open_contract_operate_plan)
        QObject.connect(self.ui.btn_send_mail,SIGNAL("clicked()"),self.open_sendmail)
        QObject.connect(self.ui.btn_print_qr,SIGNAL("clicked()"),self.open_qrcode_print)
        QObject.connect(self.ui.btn_renderer_contract_plan,SIGNAL("clicked()"),self.open_renderer_contract_plan)
        QObject.connect(self.ui.btn_renderer_contract_operate_plan,SIGNAL("clicked()"),self.open_renderer_contract_operate_plan)
        QObject.connect(self.ui.btn_renderer_contract_operate_progress,SIGNAL("clicked()"),self.open_renderer_contract_operation_progress)
        QObject.connect(self.ui.btn_print_contract_operation_plan,SIGNAL("clicked()"),self.open_print_contract_operation_plan)
        QObject.connect(self.ui.btn_print_contract_fee,SIGNAL("clicked()"),self.show_print_contract_fee)
        QObject.connect(self.ui.btn_resource_operation_performance,SIGNAL("clicked()"),self.open_resource_operation_performance)
        QObject.connect(self.ui.btn_trace,SIGNAL("clicked()"),self.open_trace)
        QObject.connect(self.ui.btn_product_table_edit,SIGNAL("clicked()"),self.open_product_table_edit)
        QObject.connect(self.ui.btn_growth_master,SIGNAL("clicked()"),self.open_edit_growth_stage)
        QObject.connect(self.ui.btn_customor_master,SIGNAL("clicked()"),self.open_edit_customer)
        QObject.connect(self.ui.btn_stockyard_master,SIGNAL("clicked()"),self.open_edit_stock_yard)
        QObject.connect(self.ui.btn_shipping_plan,SIGNAL("clicked()"),self.open_shipping_plan)
        QObject.connect(self.ui.btn_import_excel,SIGNAL("clicked()"),self.open_import_excel)

        self.connect(self.ui.cmbbox_label, SIGNAL("currentIndexChanged(const QString&)"),self.set_label)
        try:
            pyqgis_processing.remove_join()
        except:
            pyqgis_processing.show_msgbox(u"c:/gisdata/agrimanagement.qgsから起動し直してください。")
            return
        pyqgis_processing.add_join_cropping_table()
        pyqgis_processing.add_join_operation_table()
        pyqgis_processing.add_join_contract_table()

        self.set_selection_color()

        #開発中のボタンを消す
        #保管場所の登録
#         self.ui.btn_stockyard_master.setVisible(False)
        #販売先の登録
#         self.ui.btn_customor_master.setVisible(False)
        #生育ステージ登録
#         self.ui.btn_growth_master.setVisible(False)
        #モバイルへのデータ送信
        self.ui.btn_send_mail.setVisible(False)
        #QRコードの作成
        #self.ui.btn_print_qr.setVisible(False)

        #最短経路探索
        self.ui.btn_search_path.setVisible(False)
#         QObject.connect(self.ui.btn_search_path,SIGNAL("clicked()"),self.search_path)
#         QObject.connect(self.ui.btn_search_path,SIGNAL("clicked()"),self.search_path_2step)
        QObject.connect(self.ui.btn_search_path,SIGNAL("clicked()"),self.open_tsp_make_route)
        #品種、播種、収穫
        QObject.connect(self.ui.btn_rm_plan,SIGNAL("clicked()"),self.open_rm_plan)

        #最初にラベルを消す
        pyqgis_processing.hidden_label(pyqgis_processing.get_farmland_table())

        #選択圃場の色を設定
        iface.mapCanvas().setSelectionColor( QColor("magenta") )


    def set_label(self):
        if self.ui.cmbbox_label.currentText()==u"ラベルなし":
            pyqgis_processing.hidden_label(pyqgis_processing.get_farmland_table())
        elif self.ui.cmbbox_label.currentText()==u"農地名称":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "farmland_code")
        elif self.ui.cmbbox_label.currentText()==u"品種":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "cropping_table_variety")
        elif self.ui.cmbbox_label.currentText()==u"依頼者":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "contract_table_client")

    #出荷検品台帳の構造チェック
    def check_shipment_inspection_table(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        #登録状況の存在確認
        cursor = db.execute("PRAGMA table_info('%s')" % "shipment_inspection_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "registered2": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s integer" % ("shipment_inspection_table","registered2"))
            db.commit()


        db.close()

    #作業日報の構造をチェック
    def check_report_table(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        #作業ユニットの存在確認
        cursor = db.execute("PRAGMA table_info('%s')" % "report_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "operation_unit": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s text" % ("report_table","operation_unit"))
            db.commit()

        #圃場状況の存在確認
        cursor = db.execute("PRAGMA table_info('%s')" % "report_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "land_condition": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s text" % ("report_table","land_condition"))
            db.commit()

        #コメントの存在確認
        cursor = db.execute("PRAGMA table_info('%s')" % "report_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "comment": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s text" % ("report_table","comment"))
            db.commit()
        #db.close()

        #デスクトップDBでの登録状況（20190624追加）
        cursor = db.execute("PRAGMA table_info('%s')" % "report_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "registered": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s integer" % ("report_table","registered"))
            db.commit()
            cursor.execute("update report_table set registered=1")
            db.commit()
        db.close()

    #製品品質台帳の構造チェック（20190624追加）
    def check_product_table(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        #対象作業の存在確認
        cursor = db.execute("PRAGMA table_info('%s')" % "product_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "operation": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s text" % ("product_table","operation"))
            db.commit()

        #登録状況の存在確認
        cursor = db.execute("PRAGMA table_info('%s')" % "product_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "registered": break
            i += 1
        if i == len(res): #存在してないので作る
            cursor = db.execute("ALTER TABLE %s ADD COLUMN %s integer" % ("product_table","registered"))
            db.commit()
            cursor.execute("update product_table set registered=1")
            db.commit()


        db.close()


    #テーブルの存在を確認、無ければ追加
    def check_tables(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        #ユニット台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "Unit")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          name TEXT)""" % "Unit")
            db.commit()

        #天候台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "Weather")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          name TEXT)""" % "Weather")
            db.commit()

        #圃場状態台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "HojyouState")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          name TEXT)""" % "HojyouState")
            db.commit()

        #勤怠台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "mobile_attendance_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          id_report_table integer,
                                          operator TEXT,
                                          cat_operator text,
                                          start_time text,
                                          end_time text,
                                          lunch_time text,
                                          private_material text)""" % "mobile_attendance_table")
            db.commit()

        #機材台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "mobile_machine_use_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          id_report_table integer,
                                          machine TEXT,
                                          remarks text,
                                          hour_meter integer)""" % "mobile_machine_use_table")
            db.commit()
        #資材台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "mobile_material_use_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          id_machine_table integer,
                                          material TEXT,
                                          amount integer)""" % "mobile_material_use_table")
            db.commit()

        #作業時間台帳
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "mobile_operation_time_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          id_report_table integer,
                                          farmland_code TEXT,
                                          start_time text,
                                          end_time text,
                                          progress text,
                                          role_count integer,
                                          remarks text)""" % "mobile_operation_time_table")
            db.commit()

        #製品個別台帳（20190624追加）
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "product_list_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          product_code text,
                                          year integer,
                                          crop text,
                                          farmland_code TEXT,
                                          operation text,
                                          registered integer)""" % "product_list_table")
            db.commit()

        #出荷予定台帳（20190624追加）
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "shipping_plan_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          year integer,
                                          crop text,
                                          operation text,
                                          customer text,
                                          shipments integer)""" % "shipping_plan_table")
            db.commit()

        #出荷・検品台帳（20190624追加）
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "shipment_inspection_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          year integer,
                                          crop text,
                                          operation text,
                                          product_code text,
                                          customer text,
                                          shipment_date text,
                                          inspection text,
                                          inspection_date text,
                                          registered integer,
                                          registered2 integer)""" % "shipment_inspection_table")
            db.commit()

        #QRコード生成テーブル（20190705追加）
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "qrcode_test2")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                                          farm_name text)""" % "qrcode_test2")
            db.commit()





        db.close()

    def open_import_excel(self):
        pyqgis_processing.clear_all_dialog()
        db_path = QFileDialog.getOpenFileName(None, u"データベースを選択してください", ".", "spatialiteDB (*.sqlite)")

        if db_path !="":
            from import_excel import Dialog
            self.dlg=Dialog(self.iface,db_path,self.ui.spbox_year.value())
            self.dlg.show()
            self.dlg.exec_()


    def open_shipping_plan(self):


        from shipping_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_edit_stock_yard(self):
        from master_edit_stock_yard import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_edit_customer(self):
        from master_edit_customer import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_edit_growth_stage(self):
        from master_edit_growth_stage import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()


    def open_product_table_edit(self):
        from product_table_edit import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_rm_plan(self):
        from rm_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_trace(self):
        from trace import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_resource_operation_performance(self):
        from resource_operation_performance import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def show_print_contract_fee(self):
        from print_contract_fee import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()




    def open_print_contract_operation_plan(self):
        pyqgis_processing.clear_all_dialog()
        from print_contract_operation_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_contract_operation_progress(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_contract_operation_progress import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()


    def open_renderer_contract_operate_plan(self):
        pyqgis_processing.clear_all_dialog()

        from renderer_contract_operate_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_contract_plan(self):
        pyqgis_processing.clear_all_dialog()

        from renderer_contract_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()


    def open_sendmail(self):
        pyqgis_processing.clear_all_dialog()
        from to_mobile import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_qrcode_print(self):
        pyqgis_processing.clear_all_dialog()
        from qrcode_print import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_crop(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_crop import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_cultivation_calendar(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_cultivation_calendar import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_contract(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_contract import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_operator(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_operator import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_client(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_client import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_material(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_material import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_machine(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_machine import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_cropping_plan(self):
        pyqgis_processing.clear_all_dialog()

        from cropping_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_contract_plan(self):
        pyqgis_processing.clear_all_dialog()

        from contract_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_operating_plan(self):
        pyqgis_processing.clear_all_dialog()
        from operating_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_register_report(self):
        pyqgis_processing.clear_all_dialog()
        from register_report import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def get_year(self):
        today=datetime.date.today()
        return today.year

    def open_view_report(self):
        pyqgis_processing.clear_all_dialog()
        from view_report import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_print_operation_plan(self):
        pyqgis_processing.clear_all_dialog()
        from print_operation_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_operation_plan(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_operation_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_update_area(self):
        pyqgis_processing.clear_all_dialog()
        from update_area import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_cropping_plan_adjust(self):
        pyqgis_processing.clear_all_dialog()

        from cropping_plan_adjust import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()
    def open_cropping_plan_adjust2(self):
        #フリーズ対策のテストコード
        pyqgis_processing.clear_all_dialog()
        pyqgis_processing.open_start_widget()
        pyqgis_processing.check_dialog()
        from cropping_plan_adjust import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_progress(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_operation_progress import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_cropping_plan(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_cropping_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_contract_operate_plan(self):
        pyqgis_processing.clear_all_dialog()
        from contract_operate_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def renderer_landusage(self):

        import pyqgis_processing
        proc=pyqgis_processing
        farmland_table=pyqgis_processing.get_farmland_table()
        proc.clear_query(farmland_table)

        list_rule=[]
        query_string= '\"kind\" ='+ u'\'経営耕地\''
        label_string=u"経営耕地"
        list_rule.append([label_string,query_string])
        query_string= '\"kind\" ='+ u'\'受託地\''
        label_string=u"受託地"
        list_rule.append([label_string,query_string])
        query_string= '\"kind\" ='+ u'\'その他\''
        label_string=u"その他"
        list_rule.append([label_string,query_string])

        proc.renderer_map1(farmland_table, list_rule)
        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()


    def print_map(self):

        import pyqgis_processing
        import os, sys, subprocess
        proc=pyqgis_processing
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'レイアウト作成中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)
        proc.save_map_image()
        html=u"""<html><head>

        <style>
            .cssHeaderCell {

                font-size: 16px;

            }
            .cssTableCell {
                font-size: 20px;

            }

        </style>
        </head>
         <body>
         <h1><img src="%s"  """  % ("map.png")
        html+=u"""width="95%" ></h1>
        </body></html>"""



        if not os.path.exists(proc.get_prj_path() +"/mapimage"):
            os.mkdir(proc.get_prj_path() +"/mapimage")
        f = open(proc.get_prj_path() +"/mapimage/directions.html", 'w') # 書き込みモードで開く
        f.write(html.encode('utf-8')) # 引数の文字列をファイルに書き込む
        f.close() # ファイルを閉じる
        pbar.setValue(1)
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"/mapimage/directions.html")
            #os.startfile(proc.get_prj_path() +"/mapimage/map.pdf")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"/mapimage/directions.html"])
            #subprocess.call([opener, proc.get_prj_path() +"/mapimage/out.pdf"])



    def open_mobile_importer(self):
        pyqgis_processing.clear_all_dialog()
        db_path = QFileDialog.getOpenFileName(None, u"データベースを選択してください", ".", "spatialiteDB (*.sqlite)")

        if db_path !="":
            from import_mobile import Dialog
            self.dlg=Dialog(self.iface,self.ui.spbox_year.value(),db_path)
            self.dlg.show()
            self.dlg.exec_()


    def set_selection_color(self):
        p_color=QColor()
        p_color.setHsv(300,255,255)
        self.iface.mapCanvas().setSelectionColor(p_color)

    def search_path(self):
        farmland_table=pyqgis_processing.get_farmland_table()
        from land_management_tsp1 import run_simple_tsp
        #land_list=[]
        #試験的に耕作者Aで実行
#         for feature in farmland_table.getFeatures():
#             if feature[feature.fieldNameIndex('farm_name')] ==u"法人A":
#                 land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
#         best_route=run_simple_tsp(land_list)

        #テーブルでチェックの入ってる耕作者を取得
#         list_farmers_area=[]
#         row_count=self.ui.tablewidget_farmers_area.rowCount()
#         for i in range(row_count):
#             list_farmers_area.append([self.ui.tablewidget_farmers_area.item(i,0).text(),self.ui.tablewidget_farmers_area.item(i,1).text()])

        #単一耕作者テスト用
#         qpoint=[]
#         for point in best_route:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))
#
#         line=QgsGeometry.fromPolyline(qpoint)
#         f=QgsFeature()
#         f.setGeometry(line)
#         #memlayer=QgsVectorLayer('LineString','Line_subdistrict','memory')
#         crs = farmland_table.crs().authid()#toWkt()
#         memlayer=QgsVectorLayer("LineString?crs=" + crs,'Line_test','memory')
#         #memlayer.setCrs(layer1.crs(),True)
#         mempr=memlayer.dataProvider()
#         mempr.addFeatures([f])
#         memlayer.updateExtents()
#         QgsMapLayerRegistry.instance().addMapLayers([memlayer])
#         geom = f.geometry()
#         print "Length:", geom.length()

        #リストの耕作者の経路を全て計算
        land_list=[]
        for feature in farmland_table.getFeatures():
            if feature[feature.fieldNameIndex('kind')] ==u"経営耕地":
                land_list.append([feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature.id()])
        best_route=run_simple_tsp(land_list)
        print best_route
        qpoint=[]

        for point in best_route:
            qpoint.append(QgsPoint(float(point[2]),float(point[3])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        crs = farmland_table.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,u'最短経路','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])
        geom = f.geometry()
        print "Length:", geom.length()

    def open_tsp_make_route(self):
        #pyqgis_processing.clear_all_dialog()
        from tsp_make_route import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()


    def search_path_2step(self):
        from land_management_tsp_subdistrict import City
        from land_management_tsp_subdistrict import district
        from land_management_tsp_subdistrict import TourManager
        from land_management_tsp_subdistrict import OPT_2
        from land_management_tsp_subdistrict import Run_Greedy
        from land_management_tsp_subdistrict import re_define_start

        #start = time.time()
        tourmanager=TourManager()
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="farmland_table":
                layer1=lyr
                break
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=="area":
                layer2=lyr
                break

        list_area=[]
        for feature in layer2.getFeatures():
            list_area.append([feature[feature.fieldNameIndex('area_name')],feature[feature.fieldNameIndex('route')]])
        list_area.sort(key=lambda x:x[1])
      #  print list_area

        for d in list_area:
            dist=district(d[0],d[1])
            tourmanager.adddistrict(dist)

        for feature in layer1.getFeatures():
            if feature[feature.fieldNameIndex('kind')] ==u"経営耕地":
                if feature[feature.fieldNameIndex('operation_table_crop')]:
    #                 print feature[feature.fieldNameIndex('centroid_X')]
    #                 print feature[feature.fieldNameIndex('centroid_Y')]
    #                 print feature[feature.fieldNameIndex('district')]
    #                 print feature.id()
                    city = City(feature[feature.fieldNameIndex('centroid_X')],feature[feature.fieldNameIndex('centroid_Y')],feature[feature.fieldNameIndex('district')],feature.id())
                    tourmanager.addCity(city)

        besttour =Run_Greedy(tourmanager)

        UpDate = False
        for i in range(0,50):
            op2=OPT_2(besttour)
            besttour,UpDate=op2.OperateOPT2()
            #print "update: " + str(i)+ ":"  #+ str(besttour.getDistance())
            if UpDate == False:
                break
        #print "Finished"
        #print "Final distance: " + str(pop.getFittest().getDistance())
       # print "Final distance: " #+ str(besttour.getDistance())
       # print "Solution:"

        #rds= re_define_start(besttour)
       # besttour=rds.OperateRDS()

#         path=pyqgis_processing.get_prj_path()
#         db=sqlite3.connect(path+"/"+"land_db.sqlite")
#         route_name=self.ui.lineedit_scenario.text()
#         sql=""" insert into route_table_sub (subdistrict_id,route,scenario) values(?,?,?)"""
#         for city in besttour:
#             insert_row=(city.getid(),city.getroute(),route_name)
#             db.execute(sql,insert_row)
#         db.commit()
        #print besttour

        result= str(besttour).strip('|')
        list_points=result.split('|')
        qpoint=[]
        for point in list_points:
            xy=point.split(',')
            qpoint.append(QgsPoint(float(xy[0]),float(xy[1])))


#         qpoint=[]
#
#         for point in besttour:
#             qpoint.append(QgsPoint(float(point[2]),float(point[3])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,u'最短経路','memory')
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])
        geom = f.geometry()
        #print "Length:", geom.length()


