# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
# from import_mobile_ui import Ui_Dialog
from import_mobile_extend_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime
import sys

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,year,db_path):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.year=year
        self.db_path=db_path


        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\' or "kind"=\'受託地\'')

        #proc.add_join_operation_table()

        proc.hide_all_columns(self.farmland_table)
        proc.set_column_visibility(self.farmland_table,'operation_table_operator',True)
        proc.set_column_visibility(self.farmland_table,'operation_table_operation_day',True)

        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        proc.renderer_simple(self.farmland_table)

        self.load_data()


        #self.ui.tableWidget_report.itemClicked.connect(self.populate_tablewidgets)
        self.ui.tableWidget_report.itemSelectionChanged.connect(self.populate_tablewidgets)
#         self.connect(self.ui.btn_import,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_import_product_list,SIGNAL("clicked()"),self.insert_row_product_list)
        self.connect(self.ui.btn_import_report,SIGNAL("clicked()"),self.insert_row_report)
        self.connect(self.ui.btn_import_product,SIGNAL("clicked()"),self.insert_row_product)
        self.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_import_shipment,SIGNAL("clicked()"),self.update_shipping_inspection)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_report)
#         self.connect(self.ui.btn_correct_date,SIGNAL("clicked()"),self.correct_date)
#         self.connect(self.ui.btn_correct_operator,SIGNAL("clicked()"),self.correct_operator)
#         self.connect(self.ui.btn_delete_suboperator,SIGNAL("clicked()"),self.delete_sub_operator)
#         self.connect(self.ui.btn_correct_suboperator,SIGNAL("clicked()"),self.correct_suboperator)
#         self.connect(self.ui.btn_correct_machine,SIGNAL("clicked()"),self.correct_machine)
#         self.connect(self.ui.btn_delete_machine,SIGNAL("clicked()"),self.delete_machine)
#         self.connect(self.ui.btn_correct_material,SIGNAL("clicked()"),self.correct_material)

    def show_attribute_table(self):
        try:
            self.return_key_value()
        except:
            pyqgis_processing.show_msgbox(u"対象日報を選択してください")
            return
        pyqgis_processing.clear_attributetable()
        iface.showAttributeTable(self.farmland_table)


    def load_data(self):
        self.populate_tablewidget_report()
        self.populate_tablewidget_product()
        self.populate_populate_tablewidget_product_list()
        self.populate_tablewidget_shipping_list()
        self.populate_tablewidget_inspection_list()
#         #PC側DBを読み込み
#         proc=pyqgis_processing
#         db=proc.connect_db()
# #         cursor=db.cursor()
# #         query="select id from report_table "
# #         cursor.execute(query)
# #         rows=cursor.fetchall()
# #         list_db_id=[]
# #         for row in rows:
# #             list_db_id.append(row[0])
#
#
#         #モバイルDBを読み込み
#         mobile_db=sqlite3.connect(self.db_path)
#         cursor=mobile_db.cursor()
#         #まずは日報データ
# #         query="select id,operation_day , crop, operation,operator from report_table "
#         query="select id,operation_day , crop, operation,operator from report_table where registered is null "
#         try:
#             cursor.execute(query)
#         except:
#             pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
#             return
#         rows=cursor.fetchall()
#         list_mobile_data=[]
#         for row in rows:
#             key=[row[1],row[2],row[3],row[4]]
#             cursor=db.cursor()
#             query="SELECT count(*)  FROM report_table WHERE operation_day=? and crop = ? and operation = ? and operator= ?"
#             cursor.execute(query,key)
#             count = cursor.fetchone()[0]
#             if count == 0:
#                 list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])
# #             list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])
#
#         self.ui.tableWidget_report.clear()
#         self.ui.tableWidget_report.setSortingEnabled(True)
#         self.ui.tableWidget_report.setRowCount(len(list_mobile_data))
#         headers=["id",u"作業実施日",u"作物",u"作業名",u"作業者名"]
#         self.ui.tableWidget_report.setColumnCount(len(headers))
#         self.ui.tableWidget_report.setHorizontalHeaderLabels(headers)
#         i=0
#         for row in list_mobile_data:
#             self.ui.tableWidget_report.setItem(i,0,QTableWidgetItem(str(row[0])))
#             self.ui.tableWidget_report.setItem(i,1,QTableWidgetItem(row[1]))
#             self.ui.tableWidget_report.setItem(i,2,QTableWidgetItem(row[2]))
#             self.ui.tableWidget_report.setItem(i,3,QTableWidgetItem(row[3]))
#             self.ui.tableWidget_report.setItem(i,4,QTableWidgetItem(row[4]))
#             i=i+1
#         self.ui.tableWidget_report.resizeColumnsToContents()
#         self.ui.tableWidget_report.setSelectionBehavior(QAbstractItemView.SelectRows)
#         self.ui.tableWidget_report.hideColumn(0)

    def populate_tablewidget_inspection_list(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""select year,crop,product_code,customer,shipment_date,inspection,
        inspection_date from shipment_inspection_table where registered2 is null and  inspection='%s'"""  %u"確認"
        try:
            cursor.execute(query)
        except:
            pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
            return
        rows=cursor.fetchall()

        self.ui.tablewidget_shipment_update.clear()
        self.ui.tablewidget_shipment_update.setSortingEnabled(True)
        self.ui.tablewidget_shipment_update.setRowCount(len(rows))
        headers=[u"年度",u"作物",u"製品コード",u"出荷先",u"出荷日",u"検品",u"検品日"]
        self.ui.tablewidget_shipment_update.setColumnCount(len(headers))
        self.ui.tablewidget_shipment_update.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            self.ui.tablewidget_shipment_update.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_shipment_update.setItem(i,1,QTableWidgetItem(str(row[1])))
            self.ui.tablewidget_shipment_update.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_shipment_update.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tablewidget_shipment_update.setItem(i,4,QTableWidgetItem(row[4]))
            self.ui.tablewidget_shipment_update.setItem(i,5,QTableWidgetItem(row[5]))
            self.ui.tablewidget_shipment_update.setItem(i,6,QTableWidgetItem(row[6]))
            i=i+1
        self.ui.tablewidget_shipment_update.resizeColumnsToContents()
        self.ui.tablewidget_shipment_update.setSelectionBehavior(QAbstractItemView.SelectRows)
#         self.ui.tablewidget_shipment_new.hideColumn(0)

    def populate_tablewidget_shipping_list(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""select year,crop,product_code,customer,shipment_date from shipment_inspection_table where registered is null """
        try:
            cursor.execute(query)
        except:
            pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
            return
        rows=cursor.fetchall()

        self.ui.tablewidget_shipment_new.clear()
        self.ui.tablewidget_shipment_new.setSortingEnabled(True)
        self.ui.tablewidget_shipment_new.setRowCount(len(rows))
        headers=[u"年度",u"作物",u"製品コード",u"出荷先",u"出荷日"]
        self.ui.tablewidget_shipment_new.setColumnCount(len(headers))
        self.ui.tablewidget_shipment_new.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            self.ui.tablewidget_shipment_new.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_shipment_new.setItem(i,1,QTableWidgetItem(str(row[1])))
            self.ui.tablewidget_shipment_new.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_shipment_new.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tablewidget_shipment_new.setItem(i,4,QTableWidgetItem(row[4]))
            i=i+1
        self.ui.tablewidget_shipment_new.resizeColumnsToContents()
        self.ui.tablewidget_shipment_new.setSelectionBehavior(QAbstractItemView.SelectRows)
#         self.ui.tablewidget_shipment_new.hideColumn(0)


    def populate_populate_tablewidget_product_list(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""select product_code,year,crop,operation,farmland_code,registered from product_list_table where registered is null """
        try:
            cursor.execute(query)
        except:
            pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
            return
        rows=cursor.fetchall()

        self.ui.tablewidget_product_list.clear()
        self.ui.tablewidget_product_list.setSortingEnabled(True)
        self.ui.tablewidget_product_list.setRowCount(len(rows))
        headers=[u"製品コード",u"年度",u"作物",u"作業名",u"圃場コード"]
        self.ui.tablewidget_product_list.setColumnCount(len(headers))
        self.ui.tablewidget_product_list.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            self.ui.tablewidget_product_list.setItem(i,0,QTableWidgetItem(row[0]))
            self.ui.tablewidget_product_list.setItem(i,1,QTableWidgetItem(str(row[1])))
            self.ui.tablewidget_product_list.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_product_list.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tablewidget_product_list.setItem(i,4,QTableWidgetItem(row[4]))
            i=i+1
        self.ui.tablewidget_product_list.resizeColumnsToContents()
        self.ui.tablewidget_product_list.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ui.tablewidget_product_list.hideColumn(0)

    def populate_tablewidget_report(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="select id,operation_day , crop, operation,operator from report_table where registered is null "
        try:
            cursor.execute(query)
        except:
            pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
            return
        rows=cursor.fetchall()
        list_mobile_data=[]
        for row in rows:
            key=[row[1],row[2],row[3],row[4]]
            cursor=db.cursor()
            query="SELECT count(*)  FROM report_table WHERE operation_day=? and crop = ? and operation = ? and operator= ?"
            cursor.execute(query,key)
            count = cursor.fetchone()[0]
            if count == 0:
                list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])
#             list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])

        self.ui.tableWidget_report.clear()
        self.ui.tableWidget_report.setSortingEnabled(True)
        self.ui.tableWidget_report.setRowCount(len(list_mobile_data))
        headers=["id",u"作業実施日",u"作物",u"作業名",u"作業者名"]
        self.ui.tableWidget_report.setColumnCount(len(headers))
        self.ui.tableWidget_report.setHorizontalHeaderLabels(headers)
        i=0
        for row in list_mobile_data:
            self.ui.tableWidget_report.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_report.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_report.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tableWidget_report.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tableWidget_report.setItem(i,4,QTableWidgetItem(row[4]))
            i=i+1
        self.ui.tableWidget_report.resizeColumnsToContents()
        self.ui.tableWidget_report.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ui.tableWidget_report.hideColumn(0)

    def populate_tablewidget_product(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""select id,year,farmland_code,crop,operation,yield,average_weight,
        average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
        stock_yard,customer_candidate,deliver_day from product_table where registered is null """
        try:
            cursor.execute(query)
        except:
            pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
            return
        rows=cursor.fetchall()
#         list_mobile_data=[]
#         for row in rows:
#             key=[row[1],row[2],row[3],row[4]]
#             cursor=db.cursor()
#             query="SELECT count(*)  FROM report_table WHERE operation_day=? and crop = ? and operation = ? and operator= ?"
#             cursor.execute(query,key)
#             count = cursor.fetchone()[0]
#             if count == 0:
#                 list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])
#             list_mobile_data.append([row[0],row[1],row[2],row[3],row[4]])

        self.ui.tablewidget_product.clear()
        self.ui.tablewidget_product.setSortingEnabled(True)
        self.ui.tablewidget_product.setRowCount(len(rows))
        headers=["id",u"年度",u"圃場名",u"作物",u"作業名",u"ロール個数",u"平均重量",u"平均水分率",u"生育ステージ",u"雑草",u"切断長"
                 ,u"破砕処理",u"ラップ巻き数",u"保管場所",u"販売先",u"出荷日"]
        self.ui.tablewidget_product.setColumnCount(len(headers))
        self.ui.tablewidget_product.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            self.ui.tablewidget_product.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_product.setItem(i,1,QTableWidgetItem(str(row[1])))
            self.ui.tablewidget_product.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_product.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tablewidget_product.setItem(i,4,QTableWidgetItem(row[4]))
            self.ui.tablewidget_product.setItem(i,5,QTableWidgetItem(str(row[5])))
            self.ui.tablewidget_product.setItem(i,6,QTableWidgetItem(str(row[6])))
            self.ui.tablewidget_product.setItem(i,7,QTableWidgetItem(str(row[7])))
            self.ui.tablewidget_product.setItem(i,8,QTableWidgetItem(row[8]))
            self.ui.tablewidget_product.setItem(i,9,QTableWidgetItem(row[9]))
            self.ui.tablewidget_product.setItem(i,10,QTableWidgetItem(str(row[10])))
            self.ui.tablewidget_product.setItem(i,11,QTableWidgetItem(row[11]))
            self.ui.tablewidget_product.setItem(i,12,QTableWidgetItem(str(row[12])))
            self.ui.tablewidget_product.setItem(i,13,QTableWidgetItem(row[13]))
            self.ui.tablewidget_product.setItem(i,14,QTableWidgetItem(row[14]))
            self.ui.tablewidget_product.setItem(i,15,QTableWidgetItem(row[15]))
            i=i+1
        self.ui.tablewidget_product.resizeColumnsToContents()
        self.ui.tablewidget_product.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ui.tablewidget_product.hideColumn(0)


    def populate_tablewidgets(self):
        try:
            key_value=self.return_key_value()
            self.populate_tablewidget_operator(key_value)
            self.populate_tablewidget_machine(key_value)
            self.populate_tablewidget_material(key_value)
            self.query_operation_table()
            self.select_landfields()
        except:
            pass

    def query_operation_table(self):
        key=self.return_key_value()
        query_string='\"year\" ='+str(self.year)+ ' and ('
        operation=key[2]
        crop=key[1]
        query_string=query_string+'\"crop\" =' + '\''+ crop + '\' and ' +'\"operation\" =' + '\''+ operation + '\'' + ')'

    def return_key_value(self):
        row_count=self.ui.tableWidget_report.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_report.item(i,0).isSelected()==True:
                operation_day=self.ui.tableWidget_report.item(i,1).text()
                crop=self.ui.tableWidget_report.item(i,2).text()
                operation=self.ui.tableWidget_report.item(i,3).text()
                operator=self.ui.tableWidget_report.item(i,4).text()
                break
        key_value=(operation_day,crop,operation,operator)
        #print operator
        return key_value


    def populate_tablewidget_operator(self,key_value):

        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        cursor.execute(""" select id ,operator,operator_class from operator_record_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tableWidget_operator.clear()
        self.ui.tableWidget_operator.setSortingEnabled(True)
        headers=["id",u"作業者名",u"区分"]
        self.ui.tableWidget_operator.setColumnCount(len(headers))
        self.ui.tableWidget_operator.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_operator.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_operator.setRowCount(row_count)
        i=0

        for row in rows:

            self.ui.tableWidget_operator.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_operator.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_operator.setItem(i,2,QTableWidgetItem(row[2]))
            i=i+1
        self.ui.tableWidget_operator.resizeColumnsToContents()
        self.ui.tableWidget_operator.hideColumn(0)

        cursor.close()
        mobile_db.close()

    def populate_tablewidget_machine(self,key_value):
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        cursor.execute(""" select id ,machine from machine_use_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tableWidget_machine.clear()
        self.ui.tableWidget_machine.setSortingEnabled(True)
        headers=["id",u"機械名"]
        self.ui.tableWidget_machine.setColumnCount(len(headers))
        self.ui.tableWidget_machine.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_machine.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_machine.setRowCount(row_count)
        i=0

        for row in rows:

            self.ui.tableWidget_machine.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_machine.setItem(i,1,QTableWidgetItem(row[1]))

            i=i+1
        self.ui.tableWidget_machine.resizeColumnsToContents()
        self.ui.tableWidget_machine.hideColumn(0)

        cursor.close()
        mobile_db.close()

    def populate_tablewidget_material(self,key_value):
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        cursor.execute(""" select id ,material,material_use_amount from material_use_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tableWidget_material.clear()
        self.ui.tableWidget_material.setSortingEnabled(True)
        headers=["id",u"資材名",u"使用量",u"使用単位"]
        self.ui.tableWidget_material.setColumnCount(len(headers))
        self.ui.tableWidget_material.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_material.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_material.setRowCount(row_count)
        i=0

        for row in rows:
            self.ui.tableWidget_material.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_material.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_material.setItem(i,2,QTableWidgetItem(str(row[2])))

            self.ui.tableWidget_material.setItem(i,3,QTableWidgetItem(pyqgis_processing.get_material_master(row[1],key_value[1])[1]))
            i=i+1
        self.ui.tableWidget_material.resizeColumnsToContents()
        self.ui.tableWidget_material.hideColumn(0)

        cursor.close()
        mobile_db.close()

    def select_landfields(self):
        proc=pyqgis_processing

        #
        mobile_db=sqlite3.connect(self.db_path)
        query="select farmland_code from operation_table where operation_day=? and crop=? and operation=? and operator=?"
        cursor=mobile_db.cursor()
        cursor.execute(query,self.return_key_value())
        rows=cursor.fetchall()

        list_id=[]
        for row in rows:
            query="select pkuid from farmland_table where farmland_code=?"
            cursor=mobile_db.cursor()
            cursor.execute(query,(row[0],))
            id=cursor.fetchone()[0]

            list_id.append(id)

        proc.select_features(self.farmland_table, list_id)


    def insert_row_report(self):

        row_count=self.ui.tableWidget_report.rowCount()
        selection=False
        for i in range(row_count):
            if self.ui.tableWidget_report.item(i,0).isSelected()==True:
                selection=True
                break
        if selection==False:
            pyqgis_processing.show_msgbox(u"インポート対象の日報を選択してください。")

            return

        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        key=self.return_key_value()
        year=self.year
        crop=key[1]
        operation=key[2]
        operator=key[3]
        operation_day=key[0]
        #入力すべき補助者リストを作成
        suboperator=[]
        row_count=self.ui.tableWidget_operator.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_operator.item(i,2).text()==u"補助者":
                suboperator.append(self.ui.tableWidget_operator.item(i,1).text())

        #入力すべき機械リストを作成
        machine=[]
        row_count=self.ui.tableWidget_machine.rowCount()
        for i in range(row_count):
            machine.append(self.ui.tableWidget_machine.item(i,1).text())

        #入力すべき資材・使用量リストを作成
        material=[]
        row_count=self.ui.tableWidget_material.rowCount()
        for i in range(row_count):
            name=self.ui.tableWidget_material.item(i,1).text()
            #print name
            amount=self.ui.tableWidget_material.item(i,2).text()
            #amount=str(self.ui.tableWidget_material.item(i,2).value())
            #print amount
            material.append([name,amount])
        #print material



        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]
            sql=u""" update operation_table set  operator=?,operation_day=?, progress = '完了'
            where year=? and crop = ? and operation =? and farmland_code=?"""
            update_row=(operator,operation_day,year,crop,operation,farmland_code)
            db.execute(sql,update_row)
        db.commit()


        #作業者実績台帳に作業者一覧を挿入
        #まずは既存レコードがあれば、全削除
        delete_row=(year,crop,operation,operator,operation_day)
        sql="""delete from operator_record_table where year=? and crop=? and operation=?  and operator_main=? and operation_day=?"""
        db.execute(sql,delete_row)
        #メイン作業者を登録
        insert_row=(year,crop,operation,operator,operator,operation_day)
        sql=u"""insert into operator_record_table (year,crop,operation,operator_main,operator,operator_class,operation_day) values(?,?,?,?,?,'オペレータ',?)"""
        db.execute(sql,insert_row)
        db.commit()
        #補助者を登録
        for sub in suboperator:
            insert_row=(year,crop,operation,operator,sub,operation_day)
            sql=u"""insert into operator_record_table (year,crop,operation,operator_main,operator,operator_class,operation_day) values(?,?,?,?,?,'補助者',?)"""
            db.execute(sql,insert_row)
        db.commit()
        #使用機材の登録
        #まずは既存レコードがあれば、全削除
        delete_row=(year,crop,operation,operator,operation_day)
        sql="""delete from machine_use_table where year=? and crop=? and operation=?  and operator_main=? and operation_day=?"""
        db.execute(sql,delete_row)
        db.commit()
        #機材の追加
        for item in machine:
            insert_row=(year,crop,operation,operator,item,operation_day)
            sql=u"""insert into machine_use_table (year,crop,operation,operator_main,machine,operation_day) values(?,?,?,?,?,?)"""
            db.execute(sql,insert_row)
        db.commit()

        #使用資材の登録
        #既存レコードの削除
        delete_row=(year,crop,operation,operator,operation_day)
        sql="""delete from material_use_table where year=? and crop=? and operation=?  and operator_main=? and operation_day=?"""
        db.execute(sql,delete_row)
        db.commit()
        #使用資材の登録
        for item in material:
            #print item[0]
            #print item[1]
            insert_row=(year,crop,operation,operator,item[0],item[1],operation_day)
            sql=u"""insert into material_use_table (year,crop,operation,operator_main,material,material_use_amount,operation_day) values(?,?,?,?,?,?,?)"""
            db.execute(sql,insert_row)
        db.commit()

        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

        #台帳テーブルへの登録
        #既存レコードの削除
        delete_row=(crop,operation,operator,operation_day)
        sql="""delete from report_table where crop=? and operation=?  and operator=? and operation_day=?"""
        db.execute(sql,delete_row)
        db.commit()
        #登録
        insert_row=(crop,operation,operator,operation_day,1)
        sql=u"""insert into report_table (crop,operation,operator,operation_day,registered) values(?,?,?,?,?)"""
        db.execute(sql,insert_row)
        db.commit()
        db.close()

        pyqgis_processing.show_msgbox(u"作業日："+key[0]+u"　作物："+key[1]+u"　作業："+key[2]+u"　作業者："+key[3]+u"を登録しました")

        self.ui.tableWidget_operator.clear()
        self.ui.tableWidget_machine.clear()
        self.ui.tableWidget_material.clear()
        self.populate_tablewidget_report()
#         self.load_data()

    def insert_row_product(self):
        #モバイルからパソコンにデータをコピー
        proc=pyqgis_processing
        db=proc.connect_db()
        sql= """ATTACH DATABASE '"""+ self.db_path + """' as mobile_db"""
#         print sql
        db.execute(sql)
        query="""INSERT INTO product_table(year,farmland_code,crop,operation,yield,average_weight,
        average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
        stock_yard,customer_candidate,deliver_day ) SELECT year,farmland_code,crop,operation,yield,average_weight,
        average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
        stock_yard,customer_candidate,deliver_day  FROM mobile_db.product_table as mbp_table  where mbp_table.registered is null """

#         try:
        db.execute(query)
#         except:
#             pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
#             return

        db.commit()
        query="""update product_table set registered=1 where registered is null """
        db.execute(query)
        db.commit()
        db.close()
        #モバイルのデータに登録マークをつける
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""update product_table set registered=1 where registered is null """
        cursor.execute(query)
        mobile_db.commit()
        mobile_db.close()

        self.populate_tablewidget_product()
#         self.load_data()

    def insert_row_product_list(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        sql= """ATTACH DATABASE '"""+ self.db_path + """' as mobile_db"""
#         print sql
        db.execute(sql)
        query="""INSERT INTO product_list_table(year,farmland_code,crop,operation,product_code) SELECT year,farmland_code,crop,operation,product_code
         FROM mobile_db.product_list_table as mbp_table  where mbp_table.registered is null """

#         try:
        db.execute(query)
#         except:
#             pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
#             return

        db.commit()
        query="""update product_list_table set registered=1 where registered is null """
        db.execute(query)
        db.commit()
        db.close()
        #モバイルのデータに登録マークをつける
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""update product_list_table set registered=1 where registered is null """
        cursor.execute(query)
        mobile_db.commit()
        mobile_db.close()

        self.populate_populate_tablewidget_product_list()

    def update_shipping_inspection(self):
        self.insert_row_shipping_list()
        self.populate_tablewidget_shipping_list()
        self.update_row_shipping_list()
        self.populate_tablewidget_inspection_list()

    def insert_row_shipping_list(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        sql= """ATTACH DATABASE '"""+ self.db_path + """' as mobile_db"""
#         print sql
        db.execute(sql)
        query="""INSERT INTO shipment_inspection_table(year,crop,operation,product_code,customer,shipment_date,inspection,inspection_date,registered,registered2)
         SELECT year,crop,operation,product_code,customer,shipment_date,inspection,inspection_date,registered,registered2
         FROM mobile_db.shipment_inspection_table as mbp_table  where mbp_table.registered is null """

#         try:
        db.execute(query)
#         except:
#             pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
#             return

        db.commit()
        query="""update shipment_inspection_table set registered=1 where registered is null """
        db.execute(query)
        db.commit()
        db.close()
        #モバイルのデータに登録マークをつける
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""update shipment_inspection_table set registered=1 where registered is null """
        cursor.execute(query)
        mobile_db.commit()
        mobile_db.close()

        self.populate_tablewidget_shipping_list()

    def update_row_shipping_list(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        sql= """ATTACH DATABASE '"""+ self.db_path + """' as mobile_db"""
#         print sql
        db.execute(sql)
#         query="""update shipment_inspection_table set inspection=?,inspection_date=mobile_db.shipment_inspection_table.inspection_date ,registered2=1
#          where production_code in (
#           select production_code ,inspection_date from mobile_db.shipment_inspection_table where mobile_db.shipment_inspection_table.registered2 is null
#          and mobile_db.shipment_inspection_table.inspection=?) """
#         query="""update shipment_inspection_table set inspection='%s',
#         inspection_date=
#         (select inspection_date from mobile_db.shipment_inspection_table
#          wherer shipment_inspection_table.product_code=mobile_db.shipment_inspection_table.product_code),
#         registered2=1
#          where product_code in (
#           select product_code
#           from mobile_db.shipment_inspection_table
#            where registered2 is null  and inspection='%s') """ %(u"確認",u"確認")
#         query="""update shipment_inspection_table set inspection = '%s',
#         inspection_date =
#         (select inspection_date from mobile_db.shipment_inspection_table
#          wherer shipment_inspection_table.production_code = mobile_db.shipment_inspection_table.production_code),
#         registered2 = 1
#          where exists (
#           select *
#           from mobile_db.shipment_inspection_table
#            where shipment_inspection_table.production_code=mobile_db.shipment_inspection_table.production_code and
#            registered2 is null  and inspection='%s') """ %(u"確認",u"確認")

        query="""update shipment_inspection_table set inspection = '%s',
        inspection_date =
        (select inspection_date from mobile_db.shipment_inspection_table
         where product_code=mobile_db.shipment_inspection_table.product_code),
         registered2 = 1
         where product_code in (
           select product_code
           from mobile_db.shipment_inspection_table
            where registered2 is null  and inspection='%s')"""  %(u"確認",u"確認")




#         try:
        db.execute(query)
#         except:
#             pyqgis_processing.show_msgbox(u"データベースの構造が不正です。")
#             return

        db.commit()
#         query="""update shipment_inspection_table set registered=1 where registered is null """
#         db.execute(query)
#         db.commit()
#         db.close()
        #モバイルのデータに登録マークをつける
#         return
        mobile_db=sqlite3.connect(self.db_path)
        cursor=mobile_db.cursor()
        query="""update shipment_inspection_table set registered2=1
        where registered2 is null and  inspection='%s'""" %(u"確認")
        cursor.execute(query)
        mobile_db.commit()
        mobile_db.close()

        self.populate_tablewidget_inspection_list()




#

