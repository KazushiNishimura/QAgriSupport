# -*- coding: utf-8 -*-
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from qgis.core import *
from qgis.utils import *
from PyQt4.QtGui import *
import random
import sqlite3
import datetime
from PyQt4.QtWebKit import  *
import webbrowser
from time import sleep





def renderer_category(layer,field):
    fni = layer.fieldNameIndex(field)
    unique_values = layer.dataProvider().uniqueValues(fni)
    categories = []
    for unique_value in unique_values:

        symbol = QgsSymbolV2.defaultSymbol(layer.geometryType())


        layer_style = {}
        layer_style['color'] = '%d, %d, %d' % (random.randrange(0,256), random.randrange(0,256), random.randrange(0,256))
        layer_style['outline'] = '#000000'
        symbol_layer = QgsSimpleFillSymbolLayerV2.create(layer_style)


        if symbol_layer is not None:
            symbol.changeSymbolLayer(0, symbol_layer)


        category = QgsRendererCategoryV2(unique_value, symbol, unique_value)

        categories.append(category)


    renderer = QgsCategorizedSymbolRendererV2(field, categories)


    if renderer is not None:
        layer.setRendererV2(renderer)

    layer.triggerRepaint()

def get_prj_path():
    prj_file = QFileInfo(QgsProject.instance().fileName())
    return prj_file.absolutePath()

def connect_db():
    path=get_prj_path()
    return sqlite3.connect(path+"/"+"management_db.sqlite")

def date_from_text(date_text):
    date_m=date_text.split("/")[0]

    date_d=date_text.split("/")[1]

    return QDate(datetime.date.today().year,int(date_m),int(date_d))

def get_farmland_table():
    for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
        if lyr.name()=='farmland_table':
            layer1=lyr
            return layer1
            break

def get_cropping_table():
    for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
        if lyr.name()=='cropping_table':
            layer1=lyr
            return layer1
            break

def get_operation_table():
    for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
        if lyr.name()=='operation_table':
            layer1=lyr
            return layer1
            break


def get_contract_table():
    for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
        if lyr.name()=='contract_table':
            layer1=lyr
            return layer1
            break
def get_gpx():
    for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
        if lyr.name()=='track_points':
            layer1=lyr
            return layer1
            break

def remove_join():
    farmland_table=get_farmland_table()
    cropping_table=get_cropping_table()
    operation_table=get_operation_table()
    contract_table=get_contract_table()
    farmland_table.removeJoin(cropping_table.id())
    farmland_table.removeJoin(operation_table.id())
    farmland_table.removeJoin(contract_table.id())

def add_join_cropping_table():
    farmland_table=get_farmland_table()
    cropping_table=get_cropping_table()
    joinObject = QgsVectorJoinInfo()
    joinObject.joinLayerId = cropping_table.id()
    joinObject.joinFieldName = "farmland_code"
    joinObject.targetFieldName = "farmland_code"
    joinObject.memoryCache=False
    farmland_table.addJoin(joinObject)

def add_join_operation_table():
    farmland_table=get_farmland_table()
    operation_table=get_operation_table()
    joinObject = QgsVectorJoinInfo()
    joinObject.joinLayerId = operation_table.id()
    joinObject.joinFieldName = "farmland_code"
    joinObject.targetFieldName = "farmland_code"
    joinObject.memoryCache=False
    farmland_table.addJoin(joinObject)

def add_join_contract_table():
    farmland_table=get_farmland_table()
    contract_table=get_contract_table()
    joinObject = QgsVectorJoinInfo()
    joinObject.joinLayerId = contract_table.id()
    joinObject.joinFieldName = "farmland_code"
    joinObject.targetFieldName = "farmland_code"
    joinObject.memoryCache=False
    farmland_table.addJoin(joinObject)

def clear_query(lyr):
    lyr.setSubsetString("")

def set_column_visibility(layer,col_name,visible):
    config=layer.attributeTableConfig()
    columns=config.columns()
    for column in columns:
        if column.name==col_name:
            column.hidden=not visible
            break
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def show_columns_farmland_table(layer):
    config =layer.attributeTableConfig()
    columns=config.columns()
    list_columns=["pkuid","district","subdistrict","farmland_code","land_area"]
    for column in columns:
        for col_name in list_columns:
            if column.name==col_name:
                column.hidden=False
                break
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def show_columns_cropping_table(layer):
    config=layer.attributeTableConfig()
    columns=config.columns()
    list_columns=["cropping_table_crop","cropping_table_variety","cropping_table_crop_area"]
    for column in columns:
        for col_name in list_columns:
            if column.name==col_name:
                column.hidden=False
                break
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def show_columns_operation_table(layer):
    config=layer.attributeTableConfig()
    columns=config.columns()
    list_columns=["operation_table_operation","operation_table_operator_candidate","operation_table_operation_schedule"]
    for column in columns:
        for col_name in list_columns:
            if column.name==col_name:
                column.hidden=False
                break
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def show_columns_contract_table(layer):
    config=layer.attributeTableConfig()
    columns=config.columns()
    list_columns=["contract_table_operation","contract_table_client","contract_table_operation_area"]
    for column in columns:
        for col_name in list_columns:
            if column.name==col_name:
                column.hidden=False
                break
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def show_columns_gpx(layer):
    config=layer.attributeTableConfig()
    columns=config.columns()
    list_columns=["time","speed"]
    for column in columns:
        for col_name in list_columns:
            if column.name==col_name:
                column.hidden=False
                break
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def hide_all_columns(layer):
    config=layer.attributeTableConfig()
    columns=config.columns()
    for column in columns:
        column.hidden=True
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def show_all_columns(layer):
    config=layer.attributeTableConfig()
    columns=config.columns()
    for column in columns:
        column.hidden=False
    config.setColumns(columns)
    layer.setAttributeTableConfig(config)

def set_query(lyr,query_string):
    lyr.setSubsetString(query_string)

def select_features(lyr,list_id):
    lyr.setSelectedFeatures(list_id)

def set_alias_farmland_table(layer):
    i=0
    for field in layer.fields():
        if field.name()=="district":

            layer.addAttributeAlias(i,u"地区名")
        elif field.name()=="subdistrict":

            layer.addAttributeAlias(i,u"圃区名")
        elif field.name()=="farmland_code" :

            layer.addAttributeAlias(i,u"圃場名")
        elif field.name()=="land_area":

            layer.addAttributeAlias(i,u"面積")
        i=i+1

def set_alias_cropping_table(layer):
    i=0
    for field in layer.fields():
        if field.name()=="cropping_table_crop":
            layer.addAttributeAlias(i,u"作物名")
        elif field.name()=="cropping_table_variety":
            layer.addAttributeAlias(i,u"品種名")
        elif field.name()=="cropping_table_crop_area":
            layer.addAttributeAlias(i,u"作付面積")
        i=i+1

def set_alias_contract_table(layer):
    i=0
    for field in layer.fields():
        if field.name()=="contract_table_operation":
            layer.addAttributeAlias(i,u"受託作業")
        elif field.name()=="contract_table_client":
            layer.addAttributeAlias(i,u"依頼人")
        elif field.name()=="contract_table_operation_area":
            layer.addAttributeAlias(i,u"作業面積")
        i=i+1


def set_alias_gpx(layer):
    i=0
    for field in layer.fields():
        if field.name()=="time":
            layer.addAttributeAlias(i,u"作業実施日")
        elif field.name()=="speed":
            layer.addAttributeAlias(i,u"速度")

        i=i+1

def set_alias_operation_table(layer):
    i=0
    for field in layer.fields():
        if field.name()=="operation_table_operation":
            layer.addAttributeAlias(i,u"作業名")
        elif field.name()=="operation_table_operator_candidate":
            layer.addAttributeAlias(i,u"作業予定者")
        elif field.name()=="operation_table_operation_schedule":
            layer.addAttributeAlias(i,u"作業予定期間")
        elif field.name()=="operation_table_operator":
            layer.addAttributeAlias(i,u"作業実施者")
        elif field.name()=="operation_table_operation_day":
            layer.addAttributeAlias(i,u"作業実施日")
        elif field.name()=="operation_table_progress":
            layer.addAttributeAlias(i,u"進捗状況")
        i=i+1

def renderer_map1(layer,list_rule):
    rule_count=len(list_rule)
    if rule_count>0:
        hsv_delta=240/rule_count
    else:
        hsv_delta=0
    symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
    renderer=QgsRuleBasedRendererV2(symbol)
    root_rule=renderer.rootRule()
    default_color=QColor()
    default_color.setHsv(0,255,255)
    root_rule.children()[0].symbol().setColor(default_color)
    i=0
    for rule_string in list_rule:
        rule=root_rule.children()[0].clone()
        rule.setLabel(rule_string[0])
        rule.setFilterExpression(rule_string[1])
        color=QColor()
        color.setHsv(240-(i*hsv_delta),255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)
        i=i+1
    layer.setRendererV2(renderer)

def renderer_simple(layer):
    symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
    renderer=QgsSingleSymbolRendererV2(symbol)

    default_color=QColor()
    default_color.setHsv(255,255,255)
    symbol.setColor(default_color)


    layer.setRendererV2(renderer)

def get_selected_features_farmland_code(layer):
    list_farmlandcode=[]
    for feature in layer.selectedFeatures():
        list_farmlandcode.append([feature.id(),feature['farmland_code']])
    return list_farmlandcode

def sum_selected_features(layer):
    sum_=0
    for feature in layer.selectedFeatures():
        sum_=sum_+feature['land_area']
    return sum_

#完了圃場の面積を除外
def sum_selected_features_progress(layer):
    sum_=0
    for feature in layer.selectedFeatures():
        if feature['operation_table_progress']==u"未完了":
            sum_=sum_+feature['land_area']
    return sum_

def get_material_master(name,crop):
    db=connect_db()
    cursor=db.cursor()
    material=(name,crop)
    cursor.execute(""" select material_unit ,package_unit,package_amount from material_master where material=? and crop=?""",material )
    rows=cursor.fetchall()
    for row in rows:
        return row
        break


def save_map_image_test():
    layer=get_farmland_table()
    reg=QgsMapLayerRegistry.instance()
    map_image=QImage(QSize(600,600),QImage.Format_ARGB32_Premultiplied)
    composition=QColor("white")
    map_image.fill(composition.rgb())
    painter=QPainter()
    painter.begin(map_image)
    print 1

    layers=reg.mapLayers().keys()

    maprenderer=iface.mapCanvas().mapRenderer()

    maprenderer.setLayerSet(layers)

    rect=QgsRectangle(layer.extent())

    rect.scale(1.2)

    maprenderer.setExtent(rect)

    composition=QgsComposition(maprenderer)

    composition.setPlotStyle(QgsComposition.Print)

    composition.setPaperSize(215.9,279.4)

    print 2

    width,height=composition.paperWidth() * .50 ,composition.paperHeight() * .50
    x=(composition.paperWidth() - width)/2
    y=((composition.paperHeight() -height))/2
    composermap=QgsComposerMap(composition,x,y,width,height)
    composermap.setNewExtent(rect)
    composermap.setFrameEnabled(True)
    composition.addItem(composermap)
    dpi=composition.printResolution()
    composition.setPrintResolution(dpi)

    mm_in_inch=25.4
    dpmm=dpi/ mm_in_inch
    width_mm=int(dpmm * composition.paperWidth())
    height_mm=int(dpmm*composition.paperHeight())

    print 3

    image=QImage(QSize(width_mm,height_mm),QImage.Format_ARGB32)
    image.setDotsPerMeterX(dpmm*1000)
    image.setDotsPerMeterY(dpmm*1000)
    image.fill(0)

    print 4

    imagePainter=QPainter(image)
    sourceArea=QRectF(0,0,composition.paperWidth(),composition.paperHeight())
    targetArea=QRectF(0,0,width_mm,height_mm)
    composition.render(imagePainter,targetArea,sourceArea)
    imagePainter.end()

    print 5

    image.save(get_prj_path()+"/mapimage/map.jpg","jpg")




def save_map_image():
    maprenderer = iface.mapCanvas().mapRenderer()
    composition = QgsComposition(maprenderer)
    composition.setPlotStyle(QgsComposition.Print)

    composition.setPaperSize(290,200)

    dpi = composition.printResolution()
    dpmm = (dpi / 25.4)
    width = int(dpmm * composition.paperWidth())
    height = int(dpmm * composition.paperHeight())
    # コンポーザーにマップを追加
    x=0
    y =  0
    map_width= composition.paperWidth()
    map_height=composition.paperHeight()
    composermap = QgsComposerMap(composition, x,y,map_width,map_height)
    composermap.setFrameEnabled(True)
    composition.addItem(composermap)

    #レジェンドの追加 特定レイヤの凡例表示がわからない
    legend = QgsComposerLegend(composition)
    layerGroup = QgsLayerTreeGroup()
    layerGroup.insertLayer(0, get_farmland_table())
    legend.modelV2().setRootGroup(layerGroup)

    newFont = QFont("MS UI Gothic", 10)
    legend.setStyleFont(QgsComposerLegendStyle.Title, newFont)
    legend.setStyleFont(QgsComposerLegendStyle.Subgroup, newFont)
    legend.setStyleFont(QgsComposerLegendStyle.SymbolLabel, newFont)
    legend.setBackgroundEnabled(False)


    composition.addItem(legend)





    image = QImage(QSize(width, height), QImage.Format_ARGB32)
    image.setDotsPerMeterX(dpmm * 1000)
    image.setDotsPerMeterY(dpmm * 1000)

    image.fill(0)

    printer = QPrinter()
    printer.setOutputFormat(QPrinter.PdfFormat)
    printer.setOutputFileName(get_prj_path()+"/mapimage/map.pdf")
    printer.setPaperSize(QSizeF(composition.paperWidth(), composition.paperHeight()), QPrinter.Millimeter)
    printer.setFullPage(True)
    printer.setColorMode(QPrinter.Color)
    printer.setResolution(composition.printResolution())

    pdfPainter = QPainter(printer)
    paperRectMM = printer.pageRect(QPrinter.Millimeter)
    paperRectPixel = printer.pageRect(QPrinter.DevicePixel)
    composition.render(pdfPainter, paperRectPixel, paperRectMM)
    pdfPainter.end()

    #コンポーザーの描画
    imagePainter = QPainter(image)
    sourceArea = QRectF(0, 0, composition.paperWidth(), composition.paperHeight())
    targetArea = QRectF(0, 0, width, height)
    composition.render(imagePainter, targetArea, sourceArea)
    imagePainter.end()

    image.save(get_prj_path()+"/mapimage/map.png","png")


def create_directions():
    save_map_image()
    sleep(10)

    html="""<html><head>
     <script type="text/javascript" src="https://www.google.com/jsapi"></script>
     <script type="text/javascript">
     google.load("visualization", "1", {packages:["table"]});
     google.setOnLoadCallback(drawChart);
     </script></head>
     <body>
     <h1><img src="%s"  width="100%" ></h1>""" % u"C:\gisdata\地域戦略プロ\中条デモ\mapimage\map.jpg"

    html+="""</body></html>"""

    f=open('%s','w') %"C:\gisdata\地域戦略プロ\中条デモ\mapimage\directions1.html"
    f.write(html)
    f.close()

    webbrowser.open("%s") %"C:\gisdata\地域戦略プロ\中条デモ\mapimage\directions1.html"

def clear_all_dialog():

    from PyQt4.QtGui import QApplication

    list = [d for d in QApplication.instance().allWidgets() if d.objectName() == u'QgsAttributeTableDialog' or d.objectName() == u'AttributeTable' or d.objectName() == u'Dialog']

    for d in list:
        check=d.close()

def clear_attributetable():

    from PyQt4.QtGui import QApplication

    list = [d for d in QApplication.instance().allWidgets() if d.objectName() == u'QgsAttributeTableDialog' or d.objectName() == u'AttributeTable']

    for d in list:
        check=d.close()

def clear_dialog():

    from PyQt4.QtGui import QApplication

    list = [d for d in QApplication.instance().allWidgets() if d.objectName() == u'Dialog']

    for d in list:
        check=d.close()


def check_dialog():

    from PyQt4.QtGui import QApplication
    list = [d for d in QApplication.instance().allWidgets() if d.objectName() == u'QgsAttributeTableDialog' or d.objectName() == u'AttributeTable' or d.objectName() == u'Dialog']

    for d in list:
        print d.objectName()


def open_start_widget():
    widget = QWidget()
    widget.setGeometry(100, 100, 250, 100)
    widget.setWindowTitle(u'ウィジェット起動')
    pbar = QProgressBar(widget)
    pbar.setGeometry(25, 40, 200, 25)
    pbar.setRange(0, 1)

    widget.show()
    widget.raise_()
    i=0
    pbar.setValue(i)
    i=1
def add_rule_variety(crop):
    farmland_table=get_farmland_table()
    list_variety=[]
    db=connect_db()
    cursor=db.cursor()
    cursor.execute("select variety from crop_master where crop=? ",(crop,))
    rows=cursor.fetchall()
    for row in rows:
        list_variety.append(row[0])
    db.close()
    variety_count=len(list_variety)
    if variety_count>0:
        hsv_delta=240/variety_count
    else:
        hsv_delta=0
    renderer=farmland_table.rendererV2()
    root_rule=renderer.rootRule()
    children_rule=root_rule.children()
    model_rule=root_rule.children()[0].clone()
    for rule in children_rule:
        i=0
        for variety in list_variety:
            query_label=u"品種"+variety
            query_string= '\"cropping_table_variety\" ='+ '\''+ variety + '\''
            subrule=model_rule.clone()
            subrule.setLabel(query_label)
            subrule.setFilterExpression(query_string)
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            subrule.symbol().setColor(color)
            rule.appendChild(subrule)
            i=i+1
    farmland_table.setRendererV2(renderer)
    farmland_table.dataProvider().forceReload()
    farmland_table.triggerRepaint()
    iface.legendInterface().refreshLayerSymbology(farmland_table)

def show_msgbox(message):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setText(message)
    msg.setWindowFlags(Qt.WindowStaysOnTopHint)
    msg.exec_()

def print_list(list_):
    for item in list_:
        for sub_item in item:
            print sub_item

def show_label(layer,field_name):

    layer.setCustomProperty("labeling", "pal")
    layer.setCustomProperty("labeling/enabled", "true")
    layer.setCustomProperty("labeling/fontFamily", "Arial")
    layer.setCustomProperty("labeling/fontSize", "10")
    layer.setCustomProperty("labeling/fieldName", field_name)
    layer.setCustomProperty("labeling/textTransp", "0")
    layer.setCustomProperty("labeling/bufferDraw", "true")
    iface.mapCanvas().refresh()
def hidden_label(layer):

    layer.setCustomProperty("labeling/enabled", "false")
    iface.mapCanvas().refresh()

def get_string(resource):
    if resource:
        return resource
    else:
        return u"未設定"

def return_crop():
    db=connect_db()
    cursor=db.cursor()
    sql_string="select crop from crop_master group by crop"
    cursor.execute(sql_string)
    rows=cursor.fetchall()
    return(rows)

def create_sql_string_plan():
    query_string="""select operation_table.operation_schedule,operation_table.operator_candidate, total(cropping_table.crop_area)
                        from operation_table inner join cropping_table on operation_table.farmland_code = cropping_table.farmland_code
                        where operation_table.year=? and operation_table.crop=? and operation_table.operation=?
                            and cropping_table.year=? and cropping_table.crop=?
                        group by operation_table.operation_schedule,operation_table.operator_candidate"""
    return query_string

#以下は作業計画の集計で、完了圃場を除外して面積集計する
def create_sql_string_plan2():
    query_string="""select operation_table.operation_schedule,operation_table.operator_candidate, total(cropping_table.crop_area)
                        from operation_table inner join cropping_table on operation_table.farmland_code = cropping_table.farmland_code
                        where operation_table.year=? and operation_table.crop=? and operation_table.operation=? and operation_table.progress="未完了"
                            and cropping_table.year=? and cropping_table.crop=?
                        group by operation_table.operation_schedule,operation_table.operator_candidate"""
    return query_string

def create_sql_string_plan_progress():
    query_string="""select operation_table.operation_schedule,operation_table.operator_candidate, total(cropping_table.crop_area),
                        sum(case when operation_table.progress="完了" then cropping_table.crop_area else 0 end)/total(cropping_table.crop_area),
                        case when
                        (julianday(date('now'))-julianday(replace(schedule_start,'/','-'))+1)/(julianday(replace(schedule_end,'/','-'))-julianday(replace(schedule_start,'/','-'))+1)>1
                        then 1
                        when
                        (julianday(date('now'))-julianday(replace(schedule_start,'/','-'))+1)/(julianday(replace(schedule_end,'/','-'))-julianday(replace(schedule_start,'/','-'))+1)<0
                        then 0
                        else
                        (julianday(date('now'))-julianday(replace(schedule_start,'/','-'))+1)/(julianday(replace(schedule_end,'/','-'))-julianday(replace(schedule_start,'/','-'))+1)
                        end
                        from operation_table inner join cropping_table on operation_table.farmland_code = cropping_table.farmland_code
                        where operation_table.year=? and operation_table.crop=? and operation_table.operation=?
                            and cropping_table.year=? and cropping_table.crop=?
                        group by operation_table.operation_schedule,operation_table.operator_candidate"""
    return query_string

def create_sql_string_plan_contract():
    query_string="""select operation_table.operation_schedule,operation_table.operator_candidate, total(contract_table.operation_area)
                        from operation_table inner join contract_table on operation_table.farmland_code = contract_table.farmland_code
                        where operation_table.year=? and operation_table.crop=? and operation_table.operation=?
                            and contract_table.year=? and contract_table.operation=?
                        group by operation_table.operation_schedule,operation_table.operator_candidate"""
    return query_string

#以下は作業計画の集計で、完了圃場を除外して面積集計する
def create_sql_string_plan_contract2():
    query_string="""select operation_table.operation_schedule,operation_table.operator_candidate, total(contract_table.operation_area)
                        from operation_table inner join contract_table on operation_table.farmland_code = contract_table.farmland_code
                        where operation_table.year=? and operation_table.crop=? and operation_table.operation=? and  operation_table.progress="未完了"
                            and contract_table.year=? and contract_table.operation=?
                        group by operation_table.operation_schedule,operation_table.operator_candidate"""
    return query_string
def create_sql_string_contract_progress():
    query_string="""select operation_table.operation_schedule,operation_table.operator_candidate, total(contract_table.operation_area),
                        sum(case when operation_table.progress="完了" then contract_table.operation_area else 0 end)/total(contract_table.operation_area),
                        case when
                        (julianday(date('now'))-julianday(replace(schedule_start,'/','-'))+1)/(julianday(replace(schedule_end,'/','-'))-julianday(replace(schedule_start,'/','-'))+1)>1
                        then 1
                        when
                        (julianday(date('now'))-julianday(replace(schedule_start,'/','-'))+1)/(julianday(replace(schedule_end,'/','-'))-julianday(replace(schedule_start,'/','-'))+1)<0
                        then 0
                        else
                        (julianday(date('now'))-julianday(replace(schedule_start,'/','-'))+1)/(julianday(replace(schedule_end,'/','-'))-julianday(replace(schedule_start,'/','-'))+1)
                        end
                        from operation_table inner join contract_table on operation_table.farmland_code = contract_table.farmland_code
                        where operation_table.year=? and operation_table.crop=? and operation_table.operation=?
                            and contract_table.year=? and contract_table.operation=?
                        group by operation_table.operation_schedule,operation_table.operator_candidate"""
    return query_string



