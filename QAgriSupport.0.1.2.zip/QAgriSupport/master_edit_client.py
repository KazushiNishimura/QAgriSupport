# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from master_edit_client_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_table()

        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)

    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")

        cursor=db.cursor()
        cursor.execute("select id , client from client_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tableWidget_client.clear()
        self.ui.tableWidget_client.setSortingEnabled(True)
        self.ui.tableWidget_client.setRowCount(row_count)
        headers=["id",u"委託者名"]
        self.ui.tableWidget_client.setColumnCount(len(headers))
        self.ui.tableWidget_client.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_client.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_client.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tableWidget_client.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_client.setItem(i,1,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tableWidget_client.resizeColumnsToContents()
        cursor.close()
        db.close()

    def insert_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        client=self.ui.lineEdit.text()
        new_row=(client,)
        db.execute('insert into client_master (client) values (?)',new_row)
        db.commit()
        db.close()
        self.ui.lineEdit.clear()
        self.populate_table()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        rows=[]
        for index in self.ui.tableWidget_client.selectedIndexes():
            if index.column()==0:
                rows.append(index.row())
        for row in rows:
            db.execute('delete from client_master where id=?',(int(self.ui.tableWidget_client.item(row,0).text()),))

        db.commit()
        db.close()

        self.populate_table()




