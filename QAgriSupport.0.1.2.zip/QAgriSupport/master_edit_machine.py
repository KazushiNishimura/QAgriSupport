# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from master_edit_machine_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_table()

        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)

    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path +"/" +"management_db.sqlite")
        cursor=db.cursor()
        cursor.execute("select id ,machine from machine_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tableWidget_machine.clear()
        self.ui.tableWidget_machine.setSortingEnabled(True)
        self.ui.tableWidget_machine.setRowCount(row_count)
        headers=["id",u"機械名"]
        self.ui.tableWidget_machine.setColumnCount(len(headers))
        self.ui.tableWidget_machine.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_machine.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_machine.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tableWidget_machine.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_machine.setItem(i,1,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tableWidget_machine.resizeColumnsToContents()
        self.ui.tableWidget_machine.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.lineEdit_machine.text()=="":
            pyqgis_processing.show_msgbox(u"機械名を入力してください")
            return
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        machine=self.ui.lineEdit_machine.text()
        new_row=(machine,)
        db.execute('insert into machine_master (machine) values (?)',new_row)
        db.commit()
        db.close()
        self.ui.lineEdit_machine.clear()
        self.populate_table()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        rows=[]
        for index in self.ui.tableWidget_machine.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            db.execute('delete from machine_master where id = ?',(int(self.ui.tableWidget_machine.item(row,0).text()),))

        db.commit()
        db.close()

        self.populate_table()





