# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from view_report_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,year):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.year=year
        #日報の日付修正用変数
        self.date="1999"
        #日報の日付修正用変数
        self.operator="作業者"
        #日報の補助者修正用リスト
        self.list_suboperator=[]
        #日報の機械修正用リスト
        self.list_machine=[]
        #日報の資材修正用リスト
        self.list_material=[]


        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\' or "kind"=\'受託地\'')

        #proc.add_join_operation_table()

        proc.hide_all_columns(self.farmland_table)
        proc.set_column_visibility(self.farmland_table,'operation_table_operator',True)
        proc.set_column_visibility(self.farmland_table,'operation_table_operation_day',True)

        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        proc.renderer_simple(self.farmland_table)

        self.ui.spbox_year.setValue(datetime.date.today().year)

        self.connect(self.ui.btn_query,SIGNAL("clicked()"),self.populate_tablewidget_report)
        #self.ui.tableWidget_report.itemClicked.connect(self.populate_tablewidgets)
        self.ui.tableWidget_report.itemSelectionChanged.connect(self.populate_tablewidgets)
        self.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_report)
        self.connect(self.ui.btn_correct_date,SIGNAL("clicked()"),self.correct_date)
        self.connect(self.ui.btn_correct_operator,SIGNAL("clicked()"),self.correct_operator)
        self.connect(self.ui.btn_delete_suboperator,SIGNAL("clicked()"),self.delete_sub_operator)
        self.connect(self.ui.btn_correct_suboperator,SIGNAL("clicked()"),self.correct_suboperator)
        self.connect(self.ui.btn_correct_machine,SIGNAL("clicked()"),self.correct_machine)
        self.connect(self.ui.btn_delete_machine,SIGNAL("clicked()"),self.delete_machine)
        self.connect(self.ui.btn_correct_material,SIGNAL("clicked()"),self.correct_material)
        self.connect(self.ui.btn_delete_material, SIGNAL("clicked()"),self.delete_material)
        self.connect(self.ui.btn_add_landfield, SIGNAL("clicked()"),self.add_row)
        self.connect(self.ui.btn_delete_landfield, SIGNAL("clicked()"),self.delete_row)

    def correct_operator(self):

       # print self.date
        from correct_report_operator import Dialog
        #自分ごと引数として渡す
        self.dlg=Dialog(self)
        self.dlg.exec_()
        #print self.date
        #ここで修正すべき作業者がself.operatorに格納されている
        if self.operator !="cancel":
            key=self.return_key_value()
            #対象テーブルは、作業日報テーブル、作業者実績テーブル、機材使用テーブル、資材使用テーブル、作業台帳の4つ
            proc=pyqgis_processing
            db=proc.connect_db()
            query1="""update operation_table set operator=? where operation_day=? and crop=? and operation=? and operator=?"""
            query2=""" update report_table set operator=? where operation_day=? and crop=? and operation=? and operator=?"""
            #まずは、operatorを修正
            query3=u""" update operator_record_table set operator=? where operation_day=? and crop=? and operation=? and operator_main=? and operator_class= 'オペレータ' """
            #それからoperator_mainを修正
            query4=""" update operator_record_table set operator_main=? where operation_day=? and crop=? and operation=? and operator_main=?"""
            query5=""" update machine_use_table set operator_main=? where operation_day=? and crop=? and operation=? and operator_main=?"""
            query6=""" update material_use_table set operator_main=? where operation_day=? and crop=? and operation=? and operator_main=?"""



            parm=[]
            parm.append(self.operator)
            parm.extend(key)

            db.execute(query1,parm)
            db.execute(query2,parm)
            db.execute(query3,parm)
            db.execute(query4,parm)
            db.execute(query5,parm)
            db.execute(query6,parm)
            db.commit()
            db.close()

            self.populate_tablewidget_report()
            #print self.date

        #print self.date

    def correct_date(self):

       # print self.date
        from correct_report_date import Dialog
        #自分ごと引数として渡す
        self.dlg=Dialog(self)
        self.dlg.exec_()
        #print self.date
        #ここで修正すべき日付がself.dateに格納されている
        if self.date !="cancel":
            key=self.return_key_value()
            #対象テーブルは、作業日報テーブル、作業者実績テーブル、機材使用テーブル、資材使用テーブル、作業台帳の4つ
            proc=pyqgis_processing
            db=proc.connect_db()
            query1="""update operation_table set operation_day=? where operation_day=? and crop=? and operation=? and operator=?"""
            query2=""" update report_table set operation_day=? where operation_day=? and crop=? and operation=? and operator=?"""
            query3=""" update operator_record_table set operation_day=? where operation_day=? and crop=? and operation=? and operator_main=?"""
            query4=""" update machine_use_table set operation_day=? where operation_day=? and crop=? and operation=? and operator_main=?"""
            query5=""" update material_use_table set operation_day=? where operation_day=? and crop=? and operation=? and operator_main=?"""

            parm=[]
            parm.append(self.date)
            parm.extend(key)

            db.execute(query1,parm)
            db.execute(query2,parm)
            db.execute(query3,parm)
            db.execute(query4,parm)
            db.execute(query5,parm)
            db.commit()
            db.close()

            self.populate_tablewidget_report()
            #print self.date

        #print self.date



    def populate_tablewidget_report(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        query="select id,operation_day , crop, operation,operator from report_table where operation_day like '%" +str(self.ui.spbox_year.value())+ "%'"
        #query="""select id,operation_day , crop, operation,operator from report_table where operation_day like ?"""
        cursor=db.cursor()
        year=str(self.ui.spbox_year.value())
        cursor.execute(query)
        #cursor.execute(query,("'%"+year+"%'",))
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.tableWidget_report.clear()
        self.ui.tableWidget_report.setSortingEnabled(True)
        self.ui.tableWidget_report.setRowCount(row_count)
        headers=["id",u"作業実施日",u"作物",u"作業名",u"作業者名"]
        self.ui.tableWidget_report.setColumnCount(len(headers))
        self.ui.tableWidget_report.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            self.ui.tableWidget_report.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_report.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_report.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tableWidget_report.setItem(i,3,QTableWidgetItem(row[3]))
            self.ui.tableWidget_report.setItem(i,4,QTableWidgetItem(row[4]))
            i=i+1
        self.ui.tableWidget_report.resizeColumnsToContents()
        self.ui.tableWidget_report.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ui.tableWidget_report.hideColumn(0)

        db.close()

    def return_key_value(self):
        row_count=self.ui.tableWidget_report.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_report.item(i,0).isSelected()==True:
                operation_day=self.ui.tableWidget_report.item(i,1).text()
                crop=self.ui.tableWidget_report.item(i,2).text()
                operation=self.ui.tableWidget_report.item(i,3).text()
                operator=self.ui.tableWidget_report.item(i,4).text()
                break
        key_value=(operation_day,crop,operation,operator)
        #print operator
        return key_value

    def get_year(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select year from operation_table where operation_day=? and crop=? and operation=? and operator=?""",key_value)
        year=cursor.fetchmany(1)[0][0]
        return year

    def populate_tablewidgets(self):
        pyqgis_processing.clear_attributetable()
        key_value=self.return_key_value()
        self.populate_tablewidget_operator(key_value)
        self.populate_tablewidget_machine(key_value)
        self.populate_tablewidget_material(key_value)
        #self.select_landfields()
        self.renderer_map()
        self.get_year(key_value)



    def populate_tablewidget_operator(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select id ,operator,operator_class from operator_record_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tableWidget_operator.clear()
        self.ui.tableWidget_operator.setSortingEnabled(True)
        headers=["id",u"作業者名",u"区分"]
        self.ui.tableWidget_operator.setColumnCount(len(headers))
        self.ui.tableWidget_operator.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_operator.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_operator.setRowCount(row_count)
        i=0

        for row in rows:

            self.ui.tableWidget_operator.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_operator.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_operator.setItem(i,2,QTableWidgetItem(row[2]))
            i=i+1
        self.ui.tableWidget_operator.resizeColumnsToContents()
        self.ui.tableWidget_operator.hideColumn(0)

        cursor.close()
        db.close()

    def populate_tablewidget_machine(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select id ,machine from machine_use_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tableWidget_machine.clear()
        self.ui.tableWidget_machine.setSortingEnabled(True)
        headers=["id",u"機械名"]
        self.ui.tableWidget_machine.setColumnCount(len(headers))
        self.ui.tableWidget_machine.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_machine.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_machine.setRowCount(row_count)
        i=0

        for row in rows:

            self.ui.tableWidget_machine.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_machine.setItem(i,1,QTableWidgetItem(row[1]))

            i=i+1
        self.ui.tableWidget_machine.resizeColumnsToContents()
        self.ui.tableWidget_machine.hideColumn(0)

        cursor.close()
        db.close()

    def populate_tablewidget_material(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select id ,material,material_use_amount from material_use_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tableWidget_material.clear()
        self.ui.tableWidget_material.setSortingEnabled(True)
        headers=["id",u"資材名",u"使用量",u"使用単位"]
        self.ui.tableWidget_material.setColumnCount(len(headers))
        self.ui.tableWidget_material.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_material.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_material.setRowCount(row_count)
        i=0

        for row in rows:
            self.ui.tableWidget_material.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_material.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_material.setItem(i,2,QTableWidgetItem(str(row[2])))

            self.ui.tableWidget_material.setItem(i,3,QTableWidgetItem(proc.get_material_master(row[1],key_value[1])[1]))
            i=i+1
        self.ui.tableWidget_material.resizeColumnsToContents()
        self.ui.tableWidget_material.hideColumn(0)

        cursor.close()
        db.close()

    def show_attribute_table(self):
#
        try:
            self.return_key_value()
        except:
            pyqgis_processing.show_msgbox(u"対象日報を選択してください")
            return

        pyqgis_processing.clear_attributetable()


        iface.showAttributeTable(self.farmland_table)



    def select_landfields(self):
        proc=pyqgis_processing
#
        query=""" "operation_day"= '%s' and "crop" = '%s' and "operation" = '%s' and "operator"='%s' """  %(self.return_key_value())
        proc.set_query(self.operation_table,query)
        query2=""" "operation_table_operation_day"= '%s' and "operation_table_crop" = '%s' and "operation_table_operation" = '%s' and "operation_table_operator"='%s' """  %(self.return_key_value())
        selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query2))
        self.farmland_table.setSelectedFeatures([s.id() for s in selection])

    def renderer_map(self):
        proc=pyqgis_processing
#
        query=""" "operation_day"= '%s' and "crop" = '%s' and "operation" = '%s' and "operator"='%s' """  %(self.return_key_value())
        proc.set_query(self.operation_table,query)
        query2=""" "operation_table_operation_day"= '%s' and "operation_table_crop" = '%s' and "operation_table_operation" = '%s' and "operation_table_operator"='%s' """  %(self.return_key_value())

        layer=self.farmland_table
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
#         root_rule.children()[0].setLabel(label_string)
#         root_rule.children()[0].setFilterExpression(query_string)

        rule=root_rule.children()[0].clone()
        rule.setLabel(u"日報対象圃場")
        rule.setFilterExpression(query2)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)

        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()



#         selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query2))
#         self.farmland_table.setSelectedFeatures([s.id() for s in selection])

    def delete_report(self):
        try:
            key=self.return_key_value()
        except:
            pyqgis_processing.show_msgbox(u"対象となる日報を選択してください")
            return
        #対象テーブルは、作業日報テーブル、作業者実績テーブル、機材使用テーブル、資材使用テーブル、作業台帳の4つ
        proc=pyqgis_processing
        db=proc.connect_db()
        query1=u"""update operation_table set operator=null,operation_day=null,progress='未完了' where operation_day=? and crop=? and operation=? and operator=?"""
        query2=""" delete from report_table where operation_day=? and crop=? and operation=? and operator=?"""
        query3=""" delete from operator_record_table where operation_day=? and crop=? and operation=? and operator_main=?"""
        query4=""" delete from machine_use_table where operation_day=? and crop=? and operation=? and operator_main=?"""
        query5=""" delete from material_use_table where operation_day=? and crop=? and operation=? and operator_main=?"""

        db.execute(query1,key)
        db.execute(query2,key)
        db.execute(query3,key)
        db.execute(query4,key)
        db.execute(query5,key)
        db.commit()
        db.close()

        self.populate_tablewidget_report()

    def delete_sub_operator(self):
        proc=pyqgis_processing
        row_count=self.ui.tableWidget_operator.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_operator.item(i,1).isSelected()==True:
                if self.ui.tableWidget_operator.item(i,2).text()==u"オペレータ":
                    proc.show_msgbox(u"オペレータは削除できません")
                    break
                else:
                    id=int(self.ui.tableWidget_operator.item(i,0).text())
                    #print id
                    query=""" delete from operator_record_table where id=? """
                    db=proc.connect_db()
                    db.execute(query,(id,))
                    db.commit()
                    db.close()
                    key_value=self.return_key_value()
                    self.populate_tablewidget_operator(key_value)
                    break

    def correct_suboperator(self):
        from correct_report_suboperator import Dialog
#         key=self.return_key_value()
#         list_insert_row=[]
#         list_insert_row.append(self.year)
#         list_insert_row.extend(key)
        #自分ごと引数として渡す
        self.dlg=Dialog(self)
        self.dlg.exec_()
        #既に登録のある補助者一覧を取得
        list_check=[]
        row_count=self.ui.tableWidget_operator.rowCount()
        for i in range(row_count):
            list_check.append(self.ui.tableWidget_operator.item(i,1).text())

        if len(self.list_suboperator) !=0:
            db=pyqgis_processing.connect_db()
            for item in self.list_suboperator:
                if item not in list_check:
                    key=self.return_key_value()
                    list_insert_row=[]
                    list_insert_row.append(self.year)
                    list_insert_row.extend(key)
                    list_insert_row.append(item)
                    sql=u"""insert into operator_record_table (year,operation_day,crop,operation,operator_main,operator,operator_class) values(?,?,?,?,?,?,'補助者')"""
                    db.execute(sql,list_insert_row)
                db.commit()
            db.close()
        self.populate_tablewidget_operator(self.return_key_value())

    def correct_machine(self):
        from correct_report_machine import Dialog
#         key=self.return_key_value()
#         list_insert_row=[]
#         list_insert_row.append(self.year)
#         list_insert_row.extend(key)
        #自分ごと引数として渡す
        self.dlg=Dialog(self)
        self.dlg.exec_()
        #既に登録のある機械一覧を取得
        list_check=[]
        row_count=self.ui.tableWidget_machine.rowCount()
        for i in range(row_count):
            list_check.append(self.ui.tableWidget_machine.item(i,1).text())

        if len(self.list_machine) !=0:
            db=pyqgis_processing.connect_db()
            for item in self.list_machine:
                if item not in list_check:
                    key=self.return_key_value()
                    list_insert_row=[]
                    list_insert_row.append(self.year)
                    list_insert_row.extend(key)
                    list_insert_row.append(item)
                    sql=u"""insert into machine_use_table (year,operation_day,crop,operation,operator_main,machine) values(?,?,?,?,?,?)"""
                    db.execute(sql,list_insert_row)
                db.commit()
            db.close()
        self.populate_tablewidget_machine(self.return_key_value())

    def delete_machine(self):
        proc=pyqgis_processing
        row_count=self.ui.tableWidget_machine.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_machine.item(i,1).isSelected()==True:

                id=int(self.ui.tableWidget_machine.item(i,0).text())
                #print id
                query=""" delete from machine_use_table where id=? """
                db=proc.connect_db()
                db.execute(query,(id,))
                db.commit()
                db.close()
                key_value=self.return_key_value()
                self.populate_tablewidget_machine(key_value)
                break

    def correct_material(self):
        from correct_report_material import Dialog
#         key=self.return_key_value()
#         list_insert_row=[]
#         list_insert_row.append(self.year)
#         list_insert_row.extend(key)
        #自分ごと引数として渡す
        self.dlg=Dialog(self)
        self.dlg.exec_()
        #既に登録のある資材一覧を取得
        list_check=[]
        row_count=self.ui.tableWidget_material.rowCount()
        for i in range(row_count):
            list_check.append(self.ui.tableWidget_material.item(i,1).text())

        if len(self.list_material) !=0:
            db=pyqgis_processing.connect_db()
            for item in self.list_material:
                if item[0] not in list_check:
                    key=self.return_key_value()
                    list_insert_row=[]
                    list_insert_row.append(self.year)
                    list_insert_row.extend(key)
                    list_insert_row.append(item[0])
                    list_insert_row.append(item[1])
                    sql=u"""insert into material_use_table (year,operation_day,crop,operation,operator_main,material,material_use_amount) values(?,?,?,?,?,?,?)"""
                    db.execute(sql,list_insert_row)
                db.commit()
            db.close()
        self.populate_tablewidget_material(self.return_key_value())

    def delete_material(self):
        proc=pyqgis_processing
        row_count=self.ui.tableWidget_material.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_material.item(i,1).isSelected()==True:

                id=int(self.ui.tableWidget_material.item(i,0).text())
                #print id
                query=""" delete from material_use_table where id=? """
                db=proc.connect_db()
                db.execute(query,(id,))
                db.commit()
                db.close()
                key_value=self.return_key_value()
                self.populate_tablewidget_material(key_value)
                break


    def add_row(self):
        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        try:
            key=self.return_key_value()
        except:
            proc.show_msgbox(u"作業日報を選択してください")
            return
        year=self.get_year(key)

        crop=key[1]
        operation=key[2]
        operator=key[3]
        operation_day=key[0]

        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]

            sql=u""" select operation_day operator from operation_table
                where year=? and crop = ? and operation =? and farmland_code=? and  progress = '完了'"""
            search_row=(year,crop,operation,farmland_code)
            cursor=db.cursor()
            cursor.execute(sql,search_row)
            rows=cursor.fetchall()
            if len(rows)!=0:
                proc.show_msgbox(u"選択圃場には既に作業完了値が登録されています")
                continue

            sql=u""" select id from operation_table
                where year=? and crop = ? and operation =? and farmland_code=?"""
            search_row=(year,crop,operation,farmland_code)
            cursor=db.cursor()
            cursor.execute(sql,search_row)
            rows=cursor.fetchall()
            if len(rows)==0:
                proc.show_msgbox(u"選択圃場には対象年度・作物・作業の計画が策定されていません")
                continue


            try:
                sql=u""" update operation_table set  operator=?,operation_day=?, progress = '完了'
                where year=? and crop = ? and operation =? and farmland_code=?"""
                update_row=(operator,operation_day,year,crop,operation,farmland_code)
                db.execute(sql,update_row)
            except:
                proc.show_msgbox(u"%sには対象年度・作物・作業の計画が策定されていません。") %(farmland_code)
        db.commit()
        db.close()

        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def delete_row(self):
        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        try:
            key=self.return_key_value()
        except:
            proc.show_msgbox(u"作業日報を選択してください")
            return
        year=self.get_year(key)

        crop=key[1]
        operation=key[2]
        operator=key[3]
        operation_day=key[0]

        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]
            try:
                sql=u""" update operation_table set  operator=?,operation_day=?, progress = '未完了'
                where year=? and crop = ? and operation =? and farmland_code=?"""
                update_row=(None,None,year,crop,operation,farmland_code)
            except:
                proc.show_msgbox(u"%sには対象日報の実績が策定されていません。") %(farmland_code)
            db.execute(sql,update_row)
        db.commit()
        db.close()

        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()








