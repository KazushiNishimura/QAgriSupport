# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from cropping_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y
        self.attribute_table=None

        #チェックボックステスト用リスト
        self._list=[]
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.cropping_table=pyqgis_processing.get_cropping_table()
        self.ui.tableWidget_sum.setVisible(False)

        proc=pyqgis_processing

        #テーブル結合削除コード↓
        #proc.remove_join()

        proc.clear_query(self.farmland_table)
        proc.clear_query(self.cropping_table)
        proc.set_query(self.farmland_table, u'"kind"=\'経営耕地\'')
        proc.set_query(self.cropping_table, '"year"='+ str(self.year) )

        #テーブル結合コード↓
        #proc.add_join_cropping_table()

        self.setWindowFlags(Qt.WindowStaysOnTopHint)



        self.populate_crop_table()


        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_cropping_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_cropping_table(self.farmland_table)


        self.ui.tableWidget_crop.itemClicked.connect(self.populate_cmbbox_crop)
        self.ui.tableWidget_crop.itemClicked.connect(self.populate_sum_table)
        self.ui.tableWidget_crop.itemClicked.connect(self.set_query_cropping_table)
        self.ui.tableWidget_crop.itemClicked.connect(self.render_farmland)
        self.ui.gbox_sum.clicked.connect(self.gbox_sum_expand)
        self.ui.gbox_crop.clicked.connect(self.gbox_crop_expand)

        self.connect(self.ui.cmbbox_crop, SIGNAL("currentIndexChanged(const QString&)"),self.populate_cmbbox_variety)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row_cropping_table)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
        self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.farmland_table.selectionChanged.connect(self.sum_selected_area)

    def populate_crop_table(self):
        proc=pyqgis_processing



        self.ui.tableWidget_crop.clear()
        self.ui.tableWidget_crop.setSortingEnabled(True)

        headers=[u"表示",u"作物名"]
        self.ui.tableWidget_crop.setColumnCount(len(headers))
        self.ui.tableWidget_crop.setHorizontalHeaderLabels(headers)


        i=0
        for row in proc.return_crop():

            chk =QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tableWidget_crop.insertRow(i)
            self.ui.tableWidget_crop.setItem(i,0,chk)
            self.ui.tableWidget_crop.setItem(i,1,QTableWidgetItem(row[0]))
            i=i+1

        self.ui.tableWidget_crop.resizeColumnsToContents()




    def crop_table_ItemClicked(self, item):

        if item.column()==0:
            if item.checkState() == Qt.Checked:

                self._list.append(item.row())

            else:
                self._list.remove(item.row())


    def farmland_table_ItemClicked(self):
        if self.ui.cmbbox_selection.currentText()==u"全圃場を表示":
            rows=[]
            list_id=[]
            for index in self.ui.tableWidget_farmland.selectedIndexes():
                if index.column()==0:
                    rows.append(index.row())
            for row in rows:
                list_id.append(int(self.ui.tableWidget_farmland.item(row,0).text()))

            pyqgis_processing.select_features(self.farmland_table, list_id)



    def populate_farmland_table(self,):
        row_count=self.farmland_table.featureCount()
        self.ui.tableWidget_farmland.clear()
        self.ui.tableWidget_farmland.setSortingEnabled(True)
        self.ui.tableWidget_farmland.setRowCount(row_count)
        headers=["id",u"地区",u"圃場名",u"作物名",u"品種名"]
        self.ui.tableWidget_farmland.setColumnCount(len(headers))
        self.ui.tableWidget_farmland.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_farmland.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_farmland.setSelectionBehavior(QAbstractItemView.SelectRows)

        i=0
        for feature in self.farmland_table.getFeatures():
            self.ui.tableWidget_farmland.setItem(i,0,QTableWidgetItem(str(feature.id())))
            self.ui.tableWidget_farmland.setItem(i,1,QTableWidgetItem(feature['district']))
            self.ui.tableWidget_farmland.setItem(i,2,QTableWidgetItem(feature['farmland_code']))
            self.ui.tableWidget_farmland.setItem(i,3,QTableWidgetItem(feature['cropping_table_crop']))
            self.ui.tableWidget_farmland.setItem(i,3,QTableWidgetItem(feature['cropping_table_variety']))
            i=i+1
        self.ui.tableWidget_farmland.resizeColumnsToContents()

    def select_farmland_table(self):
        self.ui.tableWidget_farmland.clearSelection()
        row_count=self.ui.tableWidget_farmland.rowCount()
        features=self.farmland_table.selectedFeatures()
        for feature in features:
            _id=feature.id()
            for i in xrange(row_count):
                if self.ui.tableWidget_farmland.item(i,0).text()==int(_id):
                    self.ui.tableWidget_farmland.item(i,0).setSelected(True)
                    break

    def populate_sum_table(self):
        self.ui.tableWidget_sum.clear()
        self.ui.tableWidget_sum.setSortingEnabled(True)
        headers=[u"作物名",u"品種名",u"作付面積"]
        self.ui.tableWidget_sum.setColumnCount(len(headers))
        self.ui.tableWidget_sum.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_sum.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_sum.setRowCount(0)
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        #まずは作物名と品種名を入力
        row_count=self.ui.tableWidget_crop.rowCount()
        j=0
        for i in range(row_count):

            if self.ui.tableWidget_crop.item(i,0).checkState() == Qt.Checked:
                crop=self.ui.tableWidget_crop.item(i,1).text()
                cursor=db.cursor()
                cursor.execute('select crop,variety,total (crop_area) from cropping_table where  year=? and crop=? group by crop,variety ',(self.year,crop,))
                rows=cursor.fetchall()
                for row in rows:
                    self.ui.tableWidget_sum.insertRow(j)
                    self.ui.tableWidget_sum.setItem(j,0,QTableWidgetItem(row[0]))
                    self.ui.tableWidget_sum.setItem(j,1,QTableWidgetItem(row[1]))

                    self.ui.tableWidget_sum.setItem(j,2,QTableWidgetItem(str(round(row[2],1))))
                    j=j+1




    def create_query_string_crop(self):
        query_string= '\"year\" ='+ str(self.year) +' and ( '
        row_count=self.ui.tableWidget_crop.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_crop.item(i,0).checkState() == Qt.Checked:
                crop=self.ui.tableWidget_crop.item(i,1).text()
                query_string=query_string+ '\"crop\" ='+ '\''+ crop +'\''+' or '
        query_string=query_string.rstrip(" or")
        query_string=query_string+')'

        return query_string

    def set_query_cropping_table(self):
        pyqgis_processing.set_query(self.cropping_table, self.create_query_string_crop())

    def create_renderer_rule(self):
        list_rule=[]
        row_count=self.ui.tableWidget_sum.rowCount()
        for i in range(row_count):
            crop=self.ui.tableWidget_sum.item(i,0).text()
            variety=self.ui.tableWidget_sum.item(i,1).text()
            label_string=  crop + ':' + variety

            query_string= """ "cropping_table_crop" ='%s' and  "cropping_table_variety"='%s'""" %(crop,variety)
            list_rule.append([label_string,query_string])
        return list_rule

    def render_farmland(self):
        pyqgis_processing.renderer_map1(self.farmland_table, self.create_renderer_rule())
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def populate_cmbbox_crop(self):
        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        row_count=self.ui.tableWidget_crop.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_crop.item(i,0).checkState() == Qt.Checked:
                self.ui.cmbbox_crop.addItem(self.ui.tableWidget_crop.item(i,1).text())




    def populate_cmbbox_variety(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        crop=self.ui.cmbbox_crop.currentText()
        cursor=db.cursor()
        cursor.execute("select variety from crop_master where crop=?",(crop,))
        rows=cursor.fetchall()
        self.ui.cmbbox_variety.clear()
        for row in rows:
            self.ui.cmbbox_variety.addItem(row[0])

    def insert_row_cropping_table(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_variety.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象品種を選択してください")
            return

        db=pyqgis_processing.connect_db()
        crop=self.ui.cmbbox_crop.currentText()
        variety=self.ui.cmbbox_variety.currentText()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)

        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return

        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]
            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            #既存作付値の有無をチェック
            if feature[u'cropping_table_crop'] is not None:
                exist_row=(self.year,farmland_code,feature[u'cropping_table_crop'])
                #作業台帳に既に計画が入っている場合は削除しない
                cursor=db.cursor()
                cursor.execute('select count(*) from operation_table where year = ? and farmland_code = ? and crop = ?',exist_row)
                rows=cursor.fetchall()
                if rows[0][0]==0:
                    db.execute('delete from cropping_table where year = ? and farmland_code = ? and crop = ?',exist_row)
                    db.commit()
                    crop_area=feature['land_area']
                    new_row=(self.year,farmland_code,crop,variety,crop_area)
                    db.execute('insert into cropping_table (year,farmland_code,crop,variety,crop_area) values (?,?,?,?,?)',new_row)
                    db.commit()
            else:
                crop_area=feature['land_area']
                new_row=(self.year,farmland_code,crop,variety,crop_area)
                db.execute('insert into cropping_table (year,farmland_code,crop,variety,crop_area) values (?,?,?,?,?)',new_row)
                db.commit()

        db.close()
        self.populate_sum_table()
        self.render_farmland()
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()


    def delete_row(self):
        db=pyqgis_processing.connect_db()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]
            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            delete_row=(self.year,farmland_code,feature[u'cropping_table_crop'])
            #作業台帳に計画が入っている圃場は削除しない
            cursor=db.cursor()
            cursor.execute('select count(*) from operation_table where year = ? and farmland_code = ? and crop = ?',delete_row)
            rows=cursor.fetchall()
            if rows[0][0]==0:
                db.execute('delete from cropping_table where year = ? and farmland_code = ? and crop = ?',delete_row)
                db.commit()
#             db.execute('delete from cropping_table where year=? and farmland_code=? and crop=?',delete_row)
#         db.commit()
        db.close()
        self.populate_sum_table()
        self.render_farmland()
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()


    def show_attribute_table(self):
        pyqgis_processing.clear_attributetable()
        lyr=self.farmland_table

        self.attribute_table=iface.showAttributeTable(lyr)



    def gbox_sum_expand(self):
        if self.ui.gbox_sum.isChecked()==True:
            self.ui.tableWidget_sum.setVisible(True)
        else:
            self.ui.tableWidget_sum.setVisible(False)

    def gbox_crop_expand(self):
        if self.ui.gbox_crop.isChecked()==True:
            self.ui.tableWidget_crop.setVisible(True)
        else:
            self.ui.tableWidget_crop.setVisible(False)

    def sum_selected_area(self):
        sum_area=pyqgis_processing.sum_selected_features(self.farmland_table)
        self.ui.lbl_area.setText(str(round(sum_area,1))+u"m2選択中")