# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from renderer_contract_operate_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y


        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.contract_table=pyqgis_processing.get_contract_table()
        self.operation_table=pyqgis_processing.get_operation_table()




        proc=pyqgis_processing



        proc.clear_query(self.farmland_table)
        proc.clear_query(self.contract_table)
        proc.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        proc.set_query(self.contract_table, '"year"='+ str(self.year) )

        proc.hide_all_columns(self.farmland_table)
        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_contract_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_contract_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)



        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_operate()

        self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
        self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_export_csv,SIGNAL("clicked()"),self.export_csv)
        self.connect(self.ui.rbtn_plan,SIGNAL("clicked()"),self.renderer_map)
        self.connect(self.ui.rbtn_client,SIGNAL("clicked()"),self.renderer_map)
        #self.ui.tablewidget_contract.itemClicked.connect(self.select_landfields_client)
        #self.ui.tablewidget_plan.itemClicked.connect(self.select_landfields_plan)
        self.ui.tablewidget_contract.itemSelectionChanged.connect(self.select_landfields_client)
        self.ui.tablewidget_plan.itemSelectionChanged.connect(self.select_landfields_plan)

    def populate_cmbbox_operate(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        self.ui.cmbbox_operate.clear()
        self.ui.cmbbox_operate.addItem("")

        cursor=db.cursor()
        cursor.execute("select operation from contract_operation_master")
        rows=cursor.fetchall()
        list_operation=[]
        for row in rows:
            if row[0] not in list_operation:
                list_operation.append(row[0])
                self.ui.cmbbox_operate.addItem(row[0])
        db.close()

    def cmbbox_operate_change(self):
        self.set_query_contract_table()
        self.set_query_operation_table()
        operation=self.ui.cmbbox_operate.currentText()
        list_client=self.make_list_clietnt()
        list_client_area=self.sum_contract_area(operation,list_client)
        self.populate_tablewidget_contract(list_client_area)
        self.populate_sum_table()
        self.renderer_map()

    def renderer_map(self):
        if self.return_render_mode()=="plan":
            self.renderer_map_plan()
        else:
            self.renderer_map_client()


    def create_query_string_operate(self):

        operate=self.ui.cmbbox_operate.currentText()

        query_string=""" "year"=%d and "operation"='%s' """ %(self.year,operate)
        return query_string

    def create_query_string_operation(self):

        operation=self.ui.cmbbox_operate.currentText()
        query_string=""" "year"=%d and "crop"='%s' and "operation"='%s'""" %(self.year,u"受託",operation)
        return query_string

    def set_query_contract_table(self):
        pyqgis_processing.set_query(self.contract_table,self.create_query_string_operate())

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table, self.create_query_string_operation())

    def make_list_clietnt(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select client from contract_table where operation=?",(self.ui.cmbbox_operate.currentText(),))
        rows=cursor.fetchall()
        list_client=[]
        for row in rows:
            if row[0] not in list_client:
                list_client.append(row[0])
        db.close()

        return list_client

    def sum_contract_area(self,operation,list_client):
        proc=pyqgis_processing
        db=proc.connect_db()
        list_client_area=[]
        area=0
        for client in list_client:
            key=(self.year,operation,client)
            query=""" select total (operation_area) from contract_table where year=? and operation=? and client=?"""
            cursor=db.cursor()
            cursor.execute(query,key)
            area=str(round(cursor.fetchmany(1)[0][0],1))
            list_client_area.append((client,area))
        db.close()
        return list_client_area

    def populate_tablewidget_contract(self,list_client_area):
        self.ui.tablewidget_contract.clear()
        self.ui.tablewidget_contract.setSortingEnabled(True)
        headers=[u"依頼者",u"面積"]
        self.ui.tablewidget_contract.setColumnCount(len(headers))
        self.ui.tablewidget_contract.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_contract.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_contract.setRowCount(0)
        row=0
        for item in list_client_area:
            self.ui.tablewidget_contract.insertRow(row)
            self.ui.tablewidget_contract.setItem(row,0,QTableWidgetItem(item[0]))
            self.ui.tablewidget_contract.setItem(row,1,QTableWidgetItem(item[1]))
            row=row+1

    def populate_sum_table(self):
        self.ui.tablewidget_plan.clear()
        self.ui.tablewidget_plan.setSortingEnabled(True)
        headers=[u"作業予定期間",u"作業予定者",u"面積"]
        self.ui.tablewidget_plan.setColumnCount(len(headers))
        self.ui.tablewidget_plan.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_plan.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_plan.setRowCount(0)
        proc=pyqgis_processing
        year=self.year

        operation=self.ui.cmbbox_operate.currentText()
        crop=u"受託"

        sql_string=proc.create_sql_string_plan_contract()
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(sql_string,(year,crop,operation,year,operation))
        rows=cursor.fetchall()

        row=0
        for result in rows:
            self.ui.tablewidget_plan.insertRow(row)
            self.ui.tablewidget_plan.setItem(row,0,QTableWidgetItem(result[0]))
            self.ui.tablewidget_plan.setItem(row,1,QTableWidgetItem(result[1]))
            self.ui.tablewidget_plan.setItem(row,2,QTableWidgetItem(str(round(result[2],1))))
            row=row+1
        db.close()

    def renderer_map_plan(self):
        layer=self.farmland_table

        list_rule=self.create_renderer_rule_string_plan()
        rule_count=len(list_rule)
        if rule_count>0:
            hsv_delta=240/rule_count
        else:
            hsv_delta=0
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u"未設定"
        query_string= '\"contract_table_operation\" ='+ '\''+ self.ui.cmbbox_operate.currentText() +'\''+' and ' '\"operation_table_operation\" is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        i=0
        for rule_string in list_rule:
            rule=root_rule.children()[0].clone()
            rule.setLabel(rule_string[0])
            rule.setFilterExpression(rule_string[1])
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            rule.symbol().setColor(color)
            root_rule.appendChild(rule)
            i=i+1

        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def create_renderer_rule_string_plan(self):
        list_rule=[]
        operation=self.ui.cmbbox_operate.currentText()
        row_count=self.ui.tablewidget_plan.rowCount()
        for i in xrange(row_count):
            term=self.ui.tablewidget_plan.item(i,0).text()
            operator=self.ui.tablewidget_plan.item(i,1).text()
            label_string=term+ ':'+operator
            query_string='\"contract_table_operation\" ='+ '\''+ operation +'\''+' and ' +'\"operation_table_operation\" ='+'\''+operation+'\' and '+ '\"operation_table_operation_schedule\" = ' +'\'' + term + '\' and' '\"operation_table_operator_candidate\" ='+ '\'' +operator+ '\''
            list_rule.append([label_string,query_string])

        return list_rule

    def select_landfields_client(self):
        proc=pyqgis_processing
        try:
            query=""" "contract_table_operation"= '%s' and "contract_table_client" = '%s'"""  %(self.return_key_value_contract())
            selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query))
            self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        except:
            pass

    def return_key_value_contract(self):
        row_count=self.ui.tablewidget_contract.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_contract.item(i,0).isSelected()==True:
                client=self.ui.tablewidget_contract.item(i,0).text()

                break
        key_value=(self.ui.cmbbox_operate.currentText(),client)
        #print operator
        return key_value

    def tablewidget_contract_clicked(self):
        self.select_landfields_client()
        self.ui.tablewidget_plan.clearSelection()

    def tablewidget_plan_clicked(self):
        self.select_landfields_plan()
        self.ui.tablewidget_contract.clearSelection()

    def select_landfields_plan(self):
        proc=pyqgis_processing
        try:
            query=""" "operation_table_operation_schedule"= '%s' and "operation_table_operator_candidate" = '%s' and "operation_table_operation" = '%s' """  %(self.return_key_value_plan())
            selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query))
            self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        except:
            pass

    def return_key_value_plan(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_plan.item(i,0).isSelected()==True:
                plan_=[self.ui.tablewidget_plan.item(i,0).text(),self.ui.tablewidget_plan.item(i,1).text()]

                break
        operate=self.ui.cmbbox_operate.currentText()
        plan=(plan_[0],plan_[1],operate)



        return plan

    def create_renderer_rule_string_client(self):
        list_rule=[]
        operation=self.ui.cmbbox_operate.currentText()
        row_count=self.ui.tablewidget_contract.rowCount()
        for i in xrange(row_count):
            client=self.ui.tablewidget_contract.item(i,0).text()

            label_string=u'依頼者:'+client
            query_string='\"contract_table_operation\" ='+ '\''+ operation +'\''+' and ' +'\"contract_table_client\" ='+'\''+client+'\''
            list_rule.append([label_string,query_string])

        return list_rule

    def renderer_map_client(self):
        layer=self.farmland_table

        list_rule=self.create_renderer_rule_string_client()
        rule_count=len(list_rule)
        if rule_count>0:
            hsv_delta=240/rule_count
        else:
            hsv_delta=0
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u"未設定"
        query_string= '\"contract_table_operation\" ='+ '\''+ self.ui.cmbbox_operate.currentText() +'\''+' and ' '\"contract_table_client\" is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        i=0
        for rule_string in list_rule:
            rule=root_rule.children()[0].clone()
            rule.setLabel(rule_string[0])
            rule.setFilterExpression(rule_string[1])
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            rule.symbol().setColor(color)
            root_rule.appendChild(rule)
            i=i+1

        root_rule.removeChildAt(0)
        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def return_render_mode(self):
        if self.ui.rbtn_client.isChecked()==True:
            return "client"
        else:
            return "plan"

    def show_attribute_table(self):
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        pyqgis_processing.clear_attributetable()

        layer=self.farmland_table


        iface.showAttributeTable(layer)

    def export_csv(self):
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return



        year=self.year
        operation=self.ui.cmbbox_operate.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/作業計画（受託作業）"):
            os.mkdir(path+u"/作業計画（受託作業）")
        path+=u"/作業計画（受託作業）"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+operation+u'_作業計画（作業受託）')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1="pkuid"
        field_name2=u"地区名"
        field_name3=u"圃場名"
        field_name4=u"依頼人"
        field_name5=u"作業予定者"
        field_name6=u"作業予定期間"
        field_name7=u"作業状況"
        field_name8=u"作業面積"
        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),field_name7.encode('"cp932"'),field_name8.encode('"cp932"')])

        features=self.farmland_table.getFeatures()
        msg=True
        for feature in features:
            field1=feature["pkuid"]
            field2=pyqgis_processing.get_string(feature["district"])
            field3=feature["farmland_code"]
            field4=feature["contract_table_client"]
            field5=pyqgis_processing.get_string(feature["operation_table_operator_candidate"])
            field6=pyqgis_processing.get_string(feature["operation_table_operation_schedule"])
            field7=pyqgis_processing.get_string(feature["operation_table_progress"])
            field8=feature["contract_table_operation_area"]

            if feature["contract_table_operation"]==operation:
                list_csv.append([field1,field2.encode('"cp932"'),field3.encode('"cp932"'),
                             field4.encode('"cp932"'),field5.encode('"cp932"'),field6.encode('"cp932"'),field7.encode('"cp932"'),field8])


                msg=False

        import types

        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])


