# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_contract_ui.ui'
#
# Created: Fri May 12 11:38:37 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(441, 654)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.tableWidget_contract = QtGui.QTableWidget(Dialog)
        self.tableWidget_contract.setObjectName(_fromUtf8("tableWidget_contract"))
        self.tableWidget_contract.setColumnCount(0)
        self.tableWidget_contract.setRowCount(0)
        self.verticalLayout.addWidget(self.tableWidget_contract)
        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_6 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_6.setObjectName(_fromUtf8("gridLayout_6"))
        self.lineEdit_contract2 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_contract2.setObjectName(_fromUtf8("lineEdit_contract2"))
        self.gridLayout_6.addWidget(self.lineEdit_contract2, 0, 1, 1, 1)
        self.dateEdit_start_2 = QtGui.QDateEdit(self.groupBox_2)
        self.dateEdit_start_2.setCalendarPopup(True)
        self.dateEdit_start_2.setObjectName(_fromUtf8("dateEdit_start_2"))
        self.gridLayout_6.addWidget(self.dateEdit_start_2, 2, 1, 1, 1)
        self.dateEdit_end_2 = QtGui.QDateEdit(self.groupBox_2)
        self.dateEdit_end_2.setCalendarPopup(True)
        self.dateEdit_end_2.setObjectName(_fromUtf8("dateEdit_end_2"))
        self.gridLayout_6.addWidget(self.dateEdit_end_2, 3, 1, 1, 1)
        self.label_6 = QtGui.QLabel(self.groupBox_2)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout_6.addWidget(self.label_6, 0, 0, 1, 1)
        self.label_5 = QtGui.QLabel(self.groupBox_2)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout_6.addWidget(self.label_5, 3, 0, 1, 1)
        self.label_4 = QtGui.QLabel(self.groupBox_2)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout_6.addWidget(self.label_4, 2, 0, 1, 1)
        self.btn_edit = QtGui.QPushButton(self.groupBox_2)
        self.btn_edit.setObjectName(_fromUtf8("btn_edit"))
        self.gridLayout_6.addWidget(self.btn_edit, 4, 1, 1, 1)
        self.gridLayout.addWidget(self.groupBox_2, 2, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_5.addWidget(self.label_2, 3, 0, 1, 1)
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_5.addWidget(self.label, 2, 0, 1, 1)
        self.lineEdit_contract = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_contract.setObjectName(_fromUtf8("lineEdit_contract"))
        self.gridLayout_5.addWidget(self.lineEdit_contract, 0, 1, 1, 1)
        self.dateEdit_start = QtGui.QDateEdit(self.groupBox)
        self.dateEdit_start.setCalendarPopup(True)
        self.dateEdit_start.setObjectName(_fromUtf8("dateEdit_start"))
        self.gridLayout_5.addWidget(self.dateEdit_start, 2, 1, 1, 1)
        self.dateEdit_end = QtGui.QDateEdit(self.groupBox)
        self.dateEdit_end.setCalendarPopup(True)
        self.dateEdit_end.setObjectName(_fromUtf8("dateEdit_end"))
        self.gridLayout_5.addWidget(self.dateEdit_end, 3, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_5.addWidget(self.btn_insert, 4, 1, 1, 1)
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_5.addWidget(self.label_3, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox, 1, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_7 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_7.setObjectName(_fromUtf8("gridLayout_7"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_3)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_7.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_3, 3, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "受託作業マスタ", None))
        self.groupBox_2.setTitle(_translate("Dialog", "選択行の編集", None))
        self.dateEdit_start_2.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.dateEdit_end_2.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.label_6.setText(_translate("Dialog", "受託作業名", None))
        self.label_5.setText(_translate("Dialog", "作業完了日", None))
        self.label_4.setText(_translate("Dialog", "作業開始日", None))
        self.btn_edit.setText(_translate("Dialog", "変更", None))
        self.groupBox.setTitle(_translate("Dialog", "受託作業登録", None))
        self.label_2.setText(_translate("Dialog", "作業完了日", None))
        self.label.setText(_translate("Dialog", "作業開始日", None))
        self.dateEdit_start.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.dateEdit_end.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.label_3.setText(_translate("Dialog", "受託作業名", None))
        self.groupBox_3.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

