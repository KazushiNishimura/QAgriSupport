# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from print_contract_fee_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y



        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_operation()
        self.connect(self.ui.btn_export_csv,SIGNAL("clicked()"),self.sum_area)

    def populate_cmbbox_operation(self):
        year=self.year
        self.ui.cmbbox_operation.clear()
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        sql_string="""select operation from contract_operation_master """
        cursor.execute(sql_string)
        rows=cursor.fetchall()
        for row in rows:
            self.ui.cmbbox_operation.addItem(row[0])
        db.close()

    def sum_area(self):
        year=self.year
        crop=u"受託"
        operation=self.ui.cmbbox_operation.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/作業料金集計"):
            os.mkdir(path+u"/作業料金集計")
        path+=u"/作業料金集計"

        filename_main= path + "/"+"%s.csv"  % (str(year)+'_'+operation+  u'_作業料金集計')
        table_csv=open(filename_main, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1=u"依頼者"
        field_name2=u"依頼作業面積"
        field_name3=u"作業実施面積"
        field_name4=u"依頼圃場数"
        field_name5=u"作業実施圃場数"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),field_name4.encode('"cp932"'),field_name5.encode('"cp932"')])

        year=self.year
        operation=self.ui.cmbbox_operation.currentText()
        sql_string="""select client,
                             total(contract_table.operation_area),
                             sum(case when operation_table.progress="完了" then contract_table.operation_area else 0 end),
                             count(*),
                             sum(case when operation_table.progress="完了" then 1 else 0 end)
                    from contract_table
                     left join operation_table on contract_table.farmland_code=operation_table.farmland_code
                      where contract_table.year=? and
                      contract_table.operation=? and
                      (operation_table.year=? or operation_table.year is null) and
                      (operation_table.crop=? or operation_table.crop is null) and
                      (operation_table.operation=? or operation_table.operation is null)
                    group by client"""
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(sql_string,(year,operation,year,u"受託",operation))
        rows=cursor.fetchall()
        list_client=[]
        for row in rows:
            field1=row[0].encode('"cp932"')
            field2=row[1]
            if row[2] is None:
                field3=0
            else:
                field3=row[2]
            field4=row[3]
            if row[4] is None:
                field5=0
            else:
                field5=row[4]
            list_csv.append([field1,field2,field3,field4,field5])
            list_client.append(row[0])

        dataWriter.writerows(list_csv)
        table_csv.close()

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'個票出力中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, len(list_client))
        widget.show()
        widget.raise_()
        i=1
        for client in list_client:
            pbar.setValue(i)

            filename_sub= path + "/"+"%s.csv"  % (str(year)+'_'+operation+  u'_作業料金個票_'+client)
            table_csv=open(filename_sub, 'w')
            dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
            list_csv=[]
            field_name1=u"圃場名"
            field_name2=u"作業面積"
            field_name3=u"作業日"
            field_name4=u"作業担当者"
            list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),field_name4.encode('"cp932"')])

            sql_string="""select contract_table.farmland_code,
                        contract_table.operation_area,
                        operation_table.operation_day,
                        operation_table.operator
                        from contract_table
                     left  join operation_table on contract_table.farmland_code=operation_table.farmland_code
                      where contract_table.year=? and
                      contract_table.operation=? and
                      (operation_table.year=? or operation_table.year is null) and
                      (operation_table.crop=? or operation_table.crop is null) and
                      (operation_table.operation=? or operation_table.operation is null) and
                      contract_table.client=?"""
            proc=pyqgis_processing
            db=proc.connect_db()
            cursor=db.cursor()
            cursor.execute(sql_string,(year,operation,year,u"受託",operation,client))
            rows=cursor.fetchall()
            for row in rows:
                if str.isdigit(row[0]):
                    field1=pyqgis_processing.get_string(row[0])
                else:
                    field1=pyqgis_processing.get_string(row[0]).encode('"cp932"')
                field2=row[1]
                field3=pyqgis_processing.get_string(row[2]).encode('"cp932"')
                field4=pyqgis_processing.get_string(row[3]).encode('"cp932"')
                list_csv.append([field1,field2,field3,field4])

            dataWriter.writerows(list_csv)
            table_csv.close()
            i=i+1

        msg=u"""集計結果及び個票を%sに出力しました """ %(path)
        pyqgis_processing.show_msgbox(msg)


