# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'operating_plan_ui.ui'
#
# Created: Wed Jan 18 16:16:55 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(399, 464)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gbox_target = QtGui.QGroupBox(Dialog)
        self.gbox_target.setObjectName(_fromUtf8("gbox_target"))
        self.gridLayout_3 = QtGui.QGridLayout(self.gbox_target)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.label = QtGui.QLabel(self.gbox_target)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_3.addWidget(self.label, 0, 0, 1, 1)
        self.cmbbox_crop_2 = QtGui.QComboBox(self.gbox_target)
        self.cmbbox_crop_2.setObjectName(_fromUtf8("cmbbox_crop_2"))
        self.gridLayout_3.addWidget(self.cmbbox_crop_2, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.gbox_target)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_3.addWidget(self.label_2, 1, 0, 1, 1)
        self.cmbbox_operate = QtGui.QComboBox(self.gbox_target)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout_3.addWidget(self.cmbbox_operate, 1, 1, 1, 1)
        self.verticalLayout.addWidget(self.gbox_target)
        self.gbox_sum = QtGui.QGroupBox(Dialog)
        self.gbox_sum.setFlat(True)
        self.gbox_sum.setCheckable(True)
        self.gbox_sum.setChecked(False)
        self.gbox_sum.setObjectName(_fromUtf8("gbox_sum"))
        self.gridLayout_4 = QtGui.QGridLayout(self.gbox_sum)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tableWidget_sum = QtGui.QTableWidget(self.gbox_sum)
        self.tableWidget_sum.setObjectName(_fromUtf8("tableWidget_sum"))
        self.tableWidget_sum.setColumnCount(0)
        self.tableWidget_sum.setRowCount(0)
        self.gridLayout_4.addWidget(self.tableWidget_sum, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.gbox_sum)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.btn_show_table = QtGui.QPushButton(self.groupBox_3)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout_5.addWidget(self.btn_show_table, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_6 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_6.setObjectName(_fromUtf8("gridLayout_6"))
        self.label_5 = QtGui.QLabel(self.groupBox_4)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout_6.addWidget(self.label_5, 0, 0, 1, 2)
        self.dateEdit_start = QtGui.QDateEdit(self.groupBox_4)
        self.dateEdit_start.setCalendarPopup(True)
        self.dateEdit_start.setObjectName(_fromUtf8("dateEdit_start"))
        self.gridLayout_6.addWidget(self.dateEdit_start, 0, 2, 1, 1)
        self.label_6 = QtGui.QLabel(self.groupBox_4)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout_6.addWidget(self.label_6, 1, 0, 1, 1)
        self.dateEdit_end = QtGui.QDateEdit(self.groupBox_4)
        self.dateEdit_end.setCalendarPopup(True)
        self.dateEdit_end.setObjectName(_fromUtf8("dateEdit_end"))
        self.gridLayout_6.addWidget(self.dateEdit_end, 1, 2, 1, 1)
        self.label_7 = QtGui.QLabel(self.groupBox_4)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout_6.addWidget(self.label_7, 2, 0, 1, 1)
        self.btn_insert_2 = QtGui.QPushButton(self.groupBox_4)
        self.btn_insert_2.setObjectName(_fromUtf8("btn_insert_2"))
        self.gridLayout_6.addWidget(self.btn_insert_2, 3, 1, 1, 2)
        self.cmbbox_operator = QtGui.QComboBox(self.groupBox_4)
        self.cmbbox_operator.setObjectName(_fromUtf8("cmbbox_operator"))
        self.gridLayout_6.addWidget(self.cmbbox_operator, 2, 2, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_4)
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_5)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_5)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_2.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_5)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.gbox_target.setTitle(_translate("Dialog", "対象作物・作業", None))
        self.label.setText(_translate("Dialog", "対象作物", None))
        self.label_2.setText(_translate("Dialog", "対象作業", None))
        self.gbox_sum.setTitle(_translate("Dialog", "日程・作業者別面積", None))
        self.groupBox_3.setTitle(_translate("Dialog", "テーブルの表示", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブルの表示", None))
        self.groupBox_4.setTitle(_translate("Dialog", "選択行への作業計画登録", None))
        self.label_5.setText(_translate("Dialog", "作業開始予定日", None))
        self.label_6.setText(_translate("Dialog", "作業完了予定日", None))
        self.label_7.setText(_translate("Dialog", "作業予定者", None))
        self.btn_insert_2.setText(_translate("Dialog", "登録", None))
        self.groupBox_5.setTitle(_translate("Dialog", "選択行の作付削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

