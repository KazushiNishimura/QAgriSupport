# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'trace_ui.ui'
#
# Created: Mon Dec 04 17:46:25 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(355, 651)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.spbox_year = QtGui.QSpinBox(self.groupBox)
        self.spbox_year.setMaximum(3000)
        self.spbox_year.setObjectName(_fromUtf8("spbox_year"))
        self.horizontalLayout.addWidget(self.spbox_year)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox_2)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.cmbbox_crop = QtGui.QComboBox(self.groupBox_2)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.horizontalLayout_2.addWidget(self.cmbbox_crop)
        self.gridLayout.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tablewidget_record = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_record.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_record.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_record.setObjectName(_fromUtf8("tablewidget_record"))
        self.tablewidget_record.setColumnCount(0)
        self.tablewidget_record.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_record, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_3, 2, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.tablewidget_operator = QtGui.QTableWidget(self.groupBox_4)
        self.tablewidget_operator.setObjectName(_fromUtf8("tablewidget_operator"))
        self.tablewidget_operator.setColumnCount(0)
        self.tablewidget_operator.setRowCount(0)
        self.gridLayout_3.addWidget(self.tablewidget_operator, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_4, 3, 0, 1, 1)
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_5)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tablewidget_machine = QtGui.QTableWidget(self.groupBox_5)
        self.tablewidget_machine.setObjectName(_fromUtf8("tablewidget_machine"))
        self.tablewidget_machine.setColumnCount(0)
        self.tablewidget_machine.setRowCount(0)
        self.gridLayout_4.addWidget(self.tablewidget_machine, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_5, 4, 0, 1, 1)
        self.btn_show_table = QtGui.QPushButton(Dialog)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout.addWidget(self.btn_show_table, 6, 0, 1, 1)
        self.btn_show_simple_record = QtGui.QPushButton(Dialog)
        self.btn_show_simple_record.setObjectName(_fromUtf8("btn_show_simple_record"))
        self.gridLayout.addWidget(self.btn_show_simple_record, 7, 0, 1, 1)
        self.btn_show_list = QtGui.QPushButton(Dialog)
        self.btn_show_list.setObjectName(_fromUtf8("btn_show_list"))
        self.gridLayout.addWidget(self.btn_show_list, 8, 0, 1, 1)
        self.groupBox_6 = QtGui.QGroupBox(Dialog)
        self.groupBox_6.setObjectName(_fromUtf8("groupBox_6"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox_6)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.tablewidget_material = QtGui.QTableWidget(self.groupBox_6)
        self.tablewidget_material.setObjectName(_fromUtf8("tablewidget_material"))
        self.tablewidget_material.setColumnCount(0)
        self.tablewidget_material.setRowCount(0)
        self.gridLayout_5.addWidget(self.tablewidget_material, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_6, 5, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "トレーサビリティ", None))
        self.groupBox.setTitle(_translate("Dialog", "対象年度", None))
        self.groupBox_2.setTitle(_translate("Dialog", "対象作物", None))
        self.groupBox_3.setTitle(_translate("Dialog", "作業履歴-日報", None))
        self.groupBox_4.setTitle(_translate("Dialog", "作業者一覧", None))
        self.groupBox_5.setTitle(_translate("Dialog", "使用機械一覧", None))
        self.btn_show_table.setText(_translate("Dialog", "圃場テーブルの表示", None))
        self.btn_show_simple_record.setText(_translate("Dialog", "選択圃場の履歴出力", None))
        self.btn_show_list.setText(_translate("Dialog", "対象作物の全履歴出力", None))
        self.groupBox_6.setTitle(_translate("Dialog", "使用資材一覧", None))

