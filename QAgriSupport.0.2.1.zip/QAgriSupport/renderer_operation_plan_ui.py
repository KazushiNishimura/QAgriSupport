# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'renderer_operation_plan_ui.ui'
#
# Created: Tue Jun 20 10:43:29 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(330, 464)
        self.gridLayout_4 = QtGui.QGridLayout(Dialog)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn_show_table = QtGui.QPushButton(self.groupBox_2)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout_3.addWidget(self.btn_show_table, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_2, 3, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tableWidget_plan = QtGui.QTableWidget(self.groupBox_3)
        self.tableWidget_plan.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_plan.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_plan.setObjectName(_fromUtf8("tableWidget_plan"))
        self.tableWidget_plan.setColumnCount(0)
        self.tableWidget_plan.setRowCount(0)
        self.gridLayout_2.addWidget(self.tableWidget_plan, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_3, 2, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.cmbbox_crop = QtGui.QComboBox(self.groupBox)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.gridLayout.addWidget(self.cmbbox_crop, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.cmbbox_operation = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operation.setObjectName(_fromUtf8("cmbbox_operation"))
        self.gridLayout.addWidget(self.cmbbox_operation, 1, 1, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.btn_print_report = QtGui.QPushButton(self.groupBox_4)
        self.btn_print_report.setObjectName(_fromUtf8("btn_print_report"))
        self.gridLayout_5.addWidget(self.btn_print_report, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_4, 4, 0, 1, 1)
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox_5)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.chkbox_variety = QtGui.QCheckBox(self.groupBox_5)
        self.chkbox_variety.setObjectName(_fromUtf8("chkbox_variety"))
        self.horizontalLayout.addWidget(self.chkbox_variety)
        self.gridLayout_4.addWidget(self.groupBox_5, 1, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業計画のマップ表示", None))
        self.groupBox_2.setTitle(_translate("Dialog", "テーブルの表示", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブルの表示", None))
        self.groupBox_3.setTitle(_translate("Dialog", "日程別・作業者別面積", None))
        self.groupBox.setTitle(_translate("Dialog", "対象作物・作業", None))
        self.label.setText(_translate("Dialog", "対象作物", None))
        self.label_2.setText(_translate("Dialog", "対象作業", None))
        self.groupBox_4.setTitle(_translate("Dialog", "計画の出力", None))
        self.btn_print_report.setText(_translate("Dialog", "計画の出力", None))
        self.groupBox_5.setTitle(_translate("Dialog", "品種情報", None))
        self.chkbox_variety.setText(_translate("Dialog", "品種で色分け表示する", None))

