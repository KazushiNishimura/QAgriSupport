# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from gpx_renderer_ui  import Ui_Dialog
from QAgriSupport import pyqgis_processing
import datetime


class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.gpx=pyqgis_processing.get_gpx()
        self.connect(self.ui.btn_renderer,SIGNAL("clicked()"),self.renderer_gpx)
        self.connect(self.ui.cmbbox_operation_day,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_change)
        self.ui.slider_analisys.valueChanged[int].connect(self.slider_changed)
        self.connect(self.ui.btn_clear_query2,SIGNAL("clicked()"),self.clear_query2)



    def populate_cmbbox_operation_day(self,list):
        self.ui.cmbbox_operation_day.clear()
        self.ui.cmbbox_operation_day.addItem("")
        for operation_day in list:
            self.ui.cmbbox_operation_day.addItem(operation_day)

    def cmbbox_change(self):
        operation_day=self.ui.cmbbox_operation_day.currentText()
        print operation_day
        if operation_day==u"全データ表示":
            query_string=""

        elif operation_day=="":
            query_string=""

        else:
            query_string=""
            pyqgis_processing.set_query(self.gpx, query_string)
            query_string=""" "track_seg_point_id"  >= %s and   "track_seg_point_id"  <= %s""" %(self.query_day(operation_day))

        print query_string

        pyqgis_processing.set_query(self.gpx, query_string)

    def query_day(self,operation_day):
        query_string=u""" to_date(  "time")= to_date( '%s' )""" %(operation_day)
        selection=self.gpx.getFeatures(QgsFeatureRequest().setFilterExpression(query_string))
        list_=[s['track_seg_point_id'] for s in selection]
#         id_min=min(s['track_seg_point_id'] for s in selection)
#         id_max=max(s['track_seg_point_id'] for s in selection)
        id_min=min(list_)
        id_max=max(list_)

        self.ui.slider_analisys.setRange(id_min,id_max)

        return (id_min,id_max)

    def create_list(self):
        #layer=iface.activeLayer()
        layer=self.gpx
        list_operate_day=[]
        for feature in layer.getFeatures():
            operation_day=feature['time'].toString('yyyy-MM-dd')
            if operation_day not in list_operate_day:
                list_operate_day.append(operation_day)

        self.populate_cmbbox_operation_day(list_operate_day)



        return list_operate_day

    def renderer_gpx(self):
        operation_day_list=self.create_list()

        #layer=iface.activeLayer()
        layer=self.gpx
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
#         default_color=QColor()
#         default_color.setHsv(0,255,255)
#         root_rule.children()[0].symbol().setColor(default_color)
#         query_label=operation_day_list[0]
#         query_string=""" to_date(  "time" )= %s""" %(operation_day_list[0])
#         root_rule.children()[0].setLabel(query_label)
#         root_rule.children()[0].setFilterExpression(query_string)
        if len(operation_day_list)>0:
            hsv_delta=240/len(operation_day_list)
        else:
            hsv_delta=0
        i=0
        for operation_day in operation_day_list:
            rule=root_rule.children()[0].clone()
            rule.setLabel(operation_day)
            query_string=u""" to_date(  "time")= to_date( '%s' )""" %(operation_day)
            #print
            #print query_string
            rule.setFilterExpression(query_string)
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            rule.symbol().setColor(color)
            root_rule.appendChild(rule)
            i=i+1
        root_rule.removeChildAt(0)

        pyqgis_processing.hide_all_columns(layer)
        pyqgis_processing.show_columns_gpx(layer)
        pyqgis_processing.set_alias_gpx(layer)

        layer.setRendererV2(renderer)
        layer.triggerRepaint()

        self.populate_cmbbox_operation_day(operation_day_list)

    def slider_changed(self):
        id_=self.ui.slider_analisys.sliderPosition()
#         query_string=""
#         pyqgis_processing.set_query(self.gpx, query_string)
        query_string=""" "track_seg_point_id"  = %s """ %(id_)
        #selection=self.gpx.getFeatures(QgsFeatureRequest().setFilterExpression(query_string))
        #self.gpx.setSelectedFeatures([s.id() for s in selection])

        pyqgis_processing.set_query(self.gpx, query_string)

    def clear_query2(self):
        operation_day=self.ui.cmbbox_operation_day.currentText()
        if operation_day==u"全データ表示":
            query_string=""
        elif operation_day=="":
            query_string=""
        else:
            query_string=""
            pyqgis_processing.set_query(self.gpx, query_string)
            query_string=""" "track_seg_point_id"  >= %s and   "track_seg_point_id"  <= %s""" %(self.query_day(operation_day))



        pyqgis_processing.set_query(self.gpx, query_string)




