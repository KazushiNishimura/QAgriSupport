# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from master_edit_operator_ui import  Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_table()

        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)


    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")

        cursor=db.cursor()
        cursor.execute("select id ,operator from operator_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tableWidget_operator.clear()
        self.ui.tableWidget_operator.setSortingEnabled(True)
        self.ui.tableWidget_operator.setRowCount(row_count)
        headers=["id",u"作業者名"]
        self.ui.tableWidget_operator.setColumnCount(len(headers))
        self.ui.tableWidget_operator.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_operator.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_operator.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tableWidget_operator.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_operator.setItem(i,1,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tableWidget_operator.resizeColumnsToContents()
        self.ui.tableWidget_operator.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.lineEdit_operator.text()=="":
            pyqgis_processing.show_msgbox(u"作業者名を入力してください")
            return
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        operator=self.ui.lineEdit_operator.text()
        new_row=(operator,)
        db.execute('insert into operator_master (operator) values (?)',new_row)
        db.commit()
        db.close()
        self.ui.lineEdit_operator.clear()
        self.populate_table()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        for i in range(0,self.ui.tableWidget_operator.rowCount()):
            if self.ui.tableWidget_operator.item(i,0).isSelected()==True:
                db.execute('delete from operator_master where id = ?',(int(self.ui.tableWidget_operator.item(i,0).text()),))


        db.commit()
        db.close()

        self.populate_table()


