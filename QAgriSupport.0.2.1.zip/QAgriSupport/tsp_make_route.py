# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from tsp_make_route_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.cropping_table=proc.get_cropping_table()



#
#
#         self.populate_cmbbox_crop()
#         self.populate_cmbbox_operator()
#         self.ui.dateEdit_start.setDate(datetime.date.today())
#         self.ui.dateEdit_end.setDate(datetime.date.today())
#         self.connect(self.ui.cmbbox_crop_2,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
#         self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
#
#         self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
#         self.connect(self.ui.btn_insert_2,SIGNAL("clicked()"),self.insert_row)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
#         self.ui.gbox_sum.clicked.connect(self.gbox_sum_expand)
#         self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
#         self.connect(self.ui.chkbox_progress,SIGNAL("stateChanged (int)"),self.check_progress)
# #         self.connect(self.ui.chkbox_progress,SIGNAL("stateChanged (int)"),self.populate_sum_table)
# #         self.connect(self.ui.chkbox_progress,SIGNAL("stateChanged (int)"),self.renderer_map)
#         #self.ui.tableWidget_sum.itemClicked.connect(self.select_landfields)
#         self.ui.tableWidget_sum.itemSelectionChanged.connect(self.select_landfields)
#
#
#         self.farmland_table.selectionChanged.connect(self.sum_selected_area)