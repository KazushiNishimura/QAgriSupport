# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'cropping_plan_adjust_ui.ui'
#
# Created: Wed Apr 12 16:30:21 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(345, 434)
        self.gridLayout_4 = QtGui.QGridLayout(Dialog)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.cmbbox_crop = QtGui.QComboBox(self.groupBox)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.gridLayout.addWidget(self.cmbbox_crop, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.tablewidget_area = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_area.setObjectName(_fromUtf8("tablewidget_area"))
        self.tablewidget_area.setColumnCount(0)
        self.tablewidget_area.setRowCount(0)
        self.gridLayout_3.addWidget(self.tablewidget_area, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox_3)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.tablewidget_landfield = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_landfield.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_landfield.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_landfield.setObjectName(_fromUtf8("tablewidget_landfield"))
        self.tablewidget_landfield.setColumnCount(0)
        self.tablewidget_landfield.setRowCount(0)
        self.verticalLayout.addWidget(self.tablewidget_landfield)
        self.groupBox_4 = QtGui.QGroupBox(self.groupBox_3)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.label = QtGui.QLabel(self.groupBox_4)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.lineEdit = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.gridLayout_2.addWidget(self.lineEdit, 0, 1, 1, 1)
        self.btn_update = QtGui.QPushButton(self.groupBox_4)
        self.btn_update.setObjectName(_fromUtf8("btn_update"))
        self.gridLayout_2.addWidget(self.btn_update, 1, 1, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_4)
        self.btn_CSV = QtGui.QPushButton(self.groupBox_3)
        self.btn_CSV.setObjectName(_fromUtf8("btn_CSV"))
        self.verticalLayout.addWidget(self.btn_CSV)
        self.gridLayout_4.addWidget(self.groupBox_3, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作付計画-面積調整", None))
        self.groupBox.setTitle(_translate("Dialog", "対象作物", None))
        self.groupBox_2.setTitle(_translate("Dialog", "品種別面積集計", None))
        self.groupBox_3.setTitle(_translate("Dialog", "圃場一覧", None))
        self.groupBox_4.setTitle(_translate("Dialog", "選択圃場の作付面積修正", None))
        self.label.setText(_translate("Dialog", "面積", None))
        self.btn_update.setText(_translate("Dialog", "入力", None))
        self.btn_CSV.setText(_translate("Dialog", "圃場一覧のCSV出力", None))

