# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'print_operation_plan_ui.ui'
#
# Created: Wed Apr 12 15:53:16 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(316, 260)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gbox_query = QtGui.QGroupBox(Dialog)
        self.gbox_query.setObjectName(_fromUtf8("gbox_query"))
        self.gridLayout = QtGui.QGridLayout(self.gbox_query)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.cmbbox_crop = QtGui.QComboBox(self.gbox_query)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cmbbox_crop.sizePolicy().hasHeightForWidth())
        self.cmbbox_crop.setSizePolicy(sizePolicy)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.gridLayout.addWidget(self.cmbbox_crop, 0, 1, 1, 1)
        self.cmbbox_operator_candidate = QtGui.QComboBox(self.gbox_query)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cmbbox_operator_candidate.sizePolicy().hasHeightForWidth())
        self.cmbbox_operator_candidate.setSizePolicy(sizePolicy)
        self.cmbbox_operator_candidate.setObjectName(_fromUtf8("cmbbox_operator_candidate"))
        self.gridLayout.addWidget(self.cmbbox_operator_candidate, 5, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.gbox_query)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.cmbbox_operation = QtGui.QComboBox(self.gbox_query)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cmbbox_operation.sizePolicy().hasHeightForWidth())
        self.cmbbox_operation.setSizePolicy(sizePolicy)
        self.cmbbox_operation.setObjectName(_fromUtf8("cmbbox_operation"))
        self.gridLayout.addWidget(self.cmbbox_operation, 1, 1, 1, 1)
        self.label = QtGui.QLabel(self.gbox_query)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.cmbbox_operation_term = QtGui.QComboBox(self.gbox_query)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cmbbox_operation_term.sizePolicy().hasHeightForWidth())
        self.cmbbox_operation_term.setSizePolicy(sizePolicy)
        self.cmbbox_operation_term.setObjectName(_fromUtf8("cmbbox_operation_term"))
        self.gridLayout.addWidget(self.cmbbox_operation_term, 3, 1, 1, 1)
        self.label_4 = QtGui.QLabel(self.gbox_query)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 5, 0, 1, 1)
        self.label_3 = QtGui.QLabel(self.gbox_query)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)
        self.verticalLayout.addWidget(self.gbox_query)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setFlat(False)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.chkbox_variety = QtGui.QCheckBox(self.groupBox)
        self.chkbox_variety.setObjectName(_fromUtf8("chkbox_variety"))
        self.gridLayout_2.addWidget(self.chkbox_variety, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.btn_print = QtGui.QPushButton(Dialog)
        self.btn_print.setObjectName(_fromUtf8("btn_print"))
        self.verticalLayout.addWidget(self.btn_print)
        self.btn_csv = QtGui.QPushButton(Dialog)
        self.btn_csv.setObjectName(_fromUtf8("btn_csv"))
        self.verticalLayout.addWidget(self.btn_csv)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業指示図作成", None))
        self.gbox_query.setTitle(_translate("Dialog", "対象計画の検索", None))
        self.label_2.setText(_translate("Dialog", "作業", None))
        self.label.setText(_translate("Dialog", "作物", None))
        self.label_4.setText(_translate("Dialog", "作業予定者", None))
        self.label_3.setText(_translate("Dialog", "作業予定期間", None))
        self.groupBox.setTitle(_translate("Dialog", "品種情報", None))
        self.chkbox_variety.setText(_translate("Dialog", "品種で色分け表示する", None))
        self.btn_print.setText(_translate("Dialog", "指示図作成", None))
        self.btn_csv.setText(_translate("Dialog", "CSV出力する", None))

