# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from contract_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y


        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.contract_table=pyqgis_processing.get_contract_table()


        proc=pyqgis_processing



        proc.clear_query(self.farmland_table)
        proc.clear_query(self.contract_table)
        proc.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        proc.set_query(self.contract_table, '"year"='+ str(self.year) )



        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_operate()
        self.populate_cmbbox_client()



        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_contract_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_contract_table(self.farmland_table)

        self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
        self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
        self.farmland_table.selectionChanged.connect(self.sum_selected_area)
        #self.ui.tablewidget_contract.itemClicked.connect(self.select_landfields)
        self.ui.tablewidget_contract.itemSelectionChanged.connect(self.select_landfields)


    def populate_cmbbox_operate(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation from contract_operation_master")
        rows=cursor.fetchall()


        self.ui.cmbbox_operate.clear()
        self.ui.cmbbox_operate.addItem("")

        for row in rows:

            self.ui.cmbbox_operate.addItem(row[0])
        db.close()

    def populate_cmbbox_client(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select client from client_master")
        rows=cursor.fetchall()


        self.ui.cmbbox_client.clear()
        self.ui.cmbbox_client.addItem("")

        for row in rows:

            self.ui.cmbbox_client.addItem(row[0])
        db.close()


    def cmbbox_operate_change(self):
        operation=self.ui.cmbbox_operate.currentText()
        list_client=self.make_list_clietnt()
        list_client_area=self.sum_contract_area(operation,list_client)
        self.set_query_contract_table()
        self.populate_tablewidget(list_client_area)
        self.renderer_map()


    def make_list_clietnt(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select client from contract_table where operation=? and year=?",(self.ui.cmbbox_operate.currentText(),self.year))
        rows=cursor.fetchall()
        list_client=[]
        for row in rows:
            if row[0] not in list_client:
                list_client.append(row[0])
        db.close()

        return list_client

    def sum_contract_area(self,operation,list_client):
        proc=pyqgis_processing
        db=proc.connect_db()
        list_client_area=[]
        area=0
        for client in list_client:
            key=(self.year,operation,client)
            query=""" select total (operation_area) from contract_table where year=? and operation=? and client=?"""
            cursor=db.cursor()
            cursor.execute(query,key)
            area=str(round(cursor.fetchmany(1)[0][0],1))
            list_client_area.append((client,area))
        db.close()
        return list_client_area

    def populate_tablewidget(self,list_client_area):
        self.ui.tablewidget_contract.clear()
        self.ui.tablewidget_contract.setSortingEnabled(True)
        headers=[u"依頼者",u"面積"]
        self.ui.tablewidget_contract.setColumnCount(len(headers))
        self.ui.tablewidget_contract.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_contract.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_contract.setRowCount(0)
        row=0
        for item in list_client_area:
            self.ui.tablewidget_contract.insertRow(row)
            self.ui.tablewidget_contract.setItem(row,0,QTableWidgetItem(item[0]))
            self.ui.tablewidget_contract.setItem(row,1,QTableWidgetItem(item[1],1))
            row=row+1

    def set_query_contract_table(self):
        pyqgis_processing.set_query(self.contract_table, self.create_query_string_contract())

    def create_query_string_contract(self):
        query_string= '\"year\" ='+ str(self.year) +' and ( '
        operation=self.ui.cmbbox_operate.currentText()
        query_string=query_string+ '\"operation\" ='+ '\''+ operation +'\''+')'
        #print query_string
        return query_string

    def renderer_map(self):
        layer=self.farmland_table
        operation =self.ui.cmbbox_operate.currentText()
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u"未設定"
        query_string= '\"contract_table_client\"  is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        rule=root_rule.children()[0].clone()
        rule.setLabel(u"設定済み")
        query_string= '\"contract_table_client\"  is not None'
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)


        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def show_attribute_table(self):
        pyqgis_processing.clear_attributetable()
        lyr=self.farmland_table
        self.attribute_table=iface.showAttributeTable(lyr)

    def sum_selected_area(self):
        sum_area=pyqgis_processing.sum_selected_features(self.farmland_table)
        print sum_area
        self.ui.label_2.setText(str(round(sum_area,1))+u"m2選択中")

    def insert_row(self):
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        if self.ui.cmbbox_client.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象委託者を選択してください")
            return

        db=pyqgis_processing.connect_db()
        operation=self.ui.cmbbox_operate.currentText()
        client=self.ui.cmbbox_client.currentText()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)

        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return

        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]
            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            #既存作付値の有無をチェック
            if feature[u'contract_table_operation'] is not None:
                exist_row=(self.year,farmland_code,feature[u'contract_table_operation'])
                db.execute('delete from contract_table where year = ? and farmland_code = ? and operation = ?',exist_row)
            db.commit()
            operation_area=feature['land_area']
            new_row=(self.year,farmland_code,operation,client,operation_area)
            db.execute('insert into contract_table (year,farmland_code,operation,client,operation_area) values (?,?,?,?,?)',new_row)
        db.commit()
        #self.farmland_table.reload()
        #self.farmland_table.updateFields()
        db.close()
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

        list_client=self.make_list_clietnt()
        list_client_area=self.sum_contract_area(operation,list_client)
        self.populate_tablewidget(list_client_area)


    def delete_row(self):
        db=pyqgis_processing.connect_db()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]
            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            delete_row=(self.year,farmland_code,feature[u'contract_table_operation'])
            db.execute('delete from contract_table where year=? and farmland_code=? and operation=?',delete_row)
        db.commit()
        db.close()
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

        list_client=self.make_list_clietnt()
        list_client_area=self.sum_contract_area(self.ui.cmbbox_operate.currentText(),list_client)
        self.populate_tablewidget(list_client_area)

    def select_landfields(self):
        proc=pyqgis_processing
        try:
            query=""" "contract_table_operation"= '%s' and "contract_table_client" = '%s'"""  %(self.return_key_value())
            selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query))
            self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        except:
            pass


    def return_key_value(self):
        row_count=self.ui.tablewidget_contract.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_contract.item(i,0).isSelected()==True:
                client=self.ui.tablewidget_contract.item(i,0).text()

                break
        key_value=(self.ui.cmbbox_operate.currentText(),client)

        return key_value

