# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_ui.ui'
#
# Created: Fri May 12 11:37:56 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

