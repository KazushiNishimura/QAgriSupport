# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from renderer_operation_progress_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime
import csv
import os, sys, subprocess


class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.year=y
        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.cropping_table=proc.get_cropping_table()

        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.clear_query(self.cropping_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\'')
        proc.set_query(self.cropping_table,'"year"='+str(self.year))
        proc.set_query(self.operation_table,'"year"='+str(self.year))

        #proc.add_join_cropping_table()
        #proc.add_join_operation_table()

        proc.hide_all_columns(self.farmland_table)
        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_cropping_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_column_visibility(self.farmland_table, "operation_table_progress", True)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_cropping_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        #self.ui.tablewidget_sum.setVisible(False)

        self.populate_cmbbox_crop()


        self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
        self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
        self.connect(self.ui.btn_show_attributetable,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_export_csv,SIGNAL("clicked()"),self.export_csv)
        self.connect(self.ui.btn_export_all_csv,SIGNAL("clicked()"),self.export_all_csv)
        #self.ui.tablewidget_sum.itemClicked.connect(self.select_landfields)
        self.ui.tablewidget_sum.itemSelectionChanged.connect(self.select_landfields)

    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        self.ui.cmbbox_crop.clear()

        self.ui.cmbbox_crop.addItem("")

        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmbbox_crop.addItem(row[0])

        db.close()

    def cmbbox_crop_change(self):
        self.populate_cmbbox_operate()
        self.set_query_cropping_table()

    def populate_cmbbox_operate(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        crop=self.ui.cmbbox_crop.currentText()
        cursor=db.cursor()
        cursor.execute("select operation from cultivation_calendar_master where crop=?",(crop,))
        rows=cursor.fetchall()
        self.ui.cmbbox_operate.clear()
        for row in rows:
            self.ui.cmbbox_operate.addItem(row[0])

        db.close()

    def set_query_cropping_table(self):
        pyqgis_processing.set_query(self.cropping_table,self.create_query_string_crop())
        #self.farmland_table.dataProvider().forceReload()

    def create_query_string_crop(self):
        query_string= '\"year\" ='+ str(self.year) +' and ( '
        crop=self.ui.cmbbox_crop.currentText()
        query_string=query_string+ '\"crop\" ='+ '\''+ crop +'\''+')'
        #print query_string
        return query_string

    def cmbbox_operate_change(self):
        self.set_query_operation_table()
        self.populate_sum_table()
        self.renderer_map()

    def create_query_string_operation(self):
        query_string='\"year\" ='+str(self.year)+ ' and ('
        operation=self.ui.cmbbox_operate.currentText()
        crop=self.ui.cmbbox_crop.currentText()
        query_string=query_string+'\"crop\" =' + '\''+ crop + '\' and ' +'\"operation\" =' + '\''+ operation + '\'' + ')'
        return query_string

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table, self.create_query_string_operation())

    def populate_sum_table(self):
        proc=pyqgis_processing
        self.ui.tablewidget_sum.clear()
        self.ui.tablewidget_sum.setSortingEnabled(True)
        headers=[u"作業予定期間",u"作業予定者",u"面積",u"進捗率",u"日程消化率"]
        self.ui.tablewidget_sum.setColumnCount(len(headers))
        self.ui.tablewidget_sum.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_sum.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_sum.setRowCount(0)
        proc=pyqgis_processing
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operate.currentText()
        sql_string=proc.create_sql_string_plan_progress()
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(sql_string,(year,crop,operation,year,crop))
        rows=cursor.fetchall()

        #結果のリストをテーブルに挿入
        row=0
        for result in rows:
            self.ui.tablewidget_sum.insertRow(row)
            self.ui.tablewidget_sum.setItem(row,0,QTableWidgetItem(result[0]))
            self.ui.tablewidget_sum.setItem(row,1,QTableWidgetItem(result[1]))
            self.ui.tablewidget_sum.setItem(row,2,QTableWidgetItem(str(round(result[2],1))))
            self.ui.tablewidget_sum.setItem(row,3,QTableWidgetItem(str(round(result[3]*100,0))+"%"))
            self.ui.tablewidget_sum.setItem(row,4,QTableWidgetItem(str(round(result[4]*100,0))+"%"))
            #self.ui.tablewidget_sum.setItem(row,4,QTableWidgetItem(str(result[4]*100)))
            row=row+1
        db.close()

    def renderer_map(self):
        layer=self.farmland_table
        crop =self.ui.cmbbox_crop.currentText()
        list_rule=self.create_renderer_rule_string()
        rule_count=len(list_rule)
        if rule_count>0:
            hsv_delta=240/rule_count
        else:
            hsv_delta=0
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u"未設定"
        query_string= '\"cropping_table_crop\" ='+ '\''+ crop +'\''+' and ' '\"operation_table_operation\" is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        i=0
        for rule_string in list_rule:
            rule=root_rule.children()[0].clone()
            rule.setLabel(rule_string[0])
            rule.setFilterExpression(rule_string[1])
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            rule.symbol().setColor(color)
            self.create_subrule(rule)
            root_rule.appendChild(rule)
            i=i+1
        root_rule.removeChildAt(0)

        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()


    def create_renderer_rule_string(self):
        list_rule=[]

        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operate.currentText()
        row_count=self.ui.tablewidget_sum.rowCount()
        for i in xrange(row_count):
            term=self.ui.tablewidget_sum.item(i,0).text()
            operator=self.ui.tablewidget_sum.item(i,1).text()
            label_string=term+ ':'+operator
            query_string='\"cropping_table_crop\" ='+ '\''+ crop +'\''+' and ' +'\"operation_table_operation\" ='+'\''+operation+'\' and '+ '\"operation_table_operation_schedule\" = ' +'\'' + term + '\' and' '\"operation_table_operator_candidate\" ='+ '\'' +operator+ '\''
            list_rule.append([label_string,query_string])

        return list_rule

    def create_subrule(self,rule):
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operate.currentText()
        label_string=u":未完了"
        query_string= u'\"operation_table_progress\" =  \'未完了\''
        default_color=QColor()
        default_color.setHsv(0,255,255)
        subrule1=rule.clone()
        subrule1.symbol().setColor(default_color)
        subrule1.setLabel(label_string)
        subrule1.setFilterExpression(query_string)
        rule.appendChild(subrule1)

        label_string=u":完了"
        query_string= u'\"operation_table_progress\" =  \'完了\''
        subrule=rule.children()[0].clone()
        subrule.setLabel(label_string)
        subrule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        subrule.symbol().setColor(color)
        rule.appendChild(subrule)

    def show_attribute_table(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        pyqgis_processing.clear_attributetable()
        layer=self.farmland_table
        iface.showAttributeTable(layer)

    def export_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        crop=self.ui.cmbbox_crop.currentText()
        year=self.year
        operation=self.ui.cmbbox_operate.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        #ディレクトリの有無をチェック
        if not os.path.exists(path+u"/作業状況"):
            os.mkdir(path+u"/作業状況")
        path+=u"/作業状況"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+'_'+operation+u'_作業状況')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1="pkuid"
        field_name2=u"地区名"
        field_name3=u"圃場名"
        field_name4=u"品種"
        field_name5=u"作業予定者"
        field_name6=u"作業予定期間"
        field_name7=u"作業状況"
        field_name8=u"作付面積"
        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),field_name7.encode('"cp932"'),field_name8.encode('"cp932"')])

        features=self.farmland_table.getFeatures()
        for feature in features:
            field1=feature["pkuid"]
            field2=pyqgis_processing.get_string(feature["district"])
            field3=feature["farmland_code"]
            field4=pyqgis_processing.get_string(feature["cropping_table_variety"])
            field5=pyqgis_processing.get_string(feature["operation_table_operator_candidate"])
            field6=pyqgis_processing.get_string(feature["operation_table_operation_schedule"])
            field7=pyqgis_processing.get_string(feature["operation_table_progress"])
            field8=feature["cropping_table_crop_area"]
            if feature["cropping_table_crop"]==crop:
                list_csv.append([field1,field2.encode('"cp932"'),field3.encode('"cp932"'),
                             field4.encode('"cp932"'),field5.encode('"cp932"'),field6.encode('"cp932"'),field7.encode('"cp932"'),field8])


        import types
        #print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])

    def export_all_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        crop=self.ui.cmbbox_crop.currentText()
        year=self.year
        operation=self.ui.cmbbox_operate.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/作業状況"):
            os.mkdir(path+u"/作業状況")
        path+=u"/作業状況"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+u'_全作業進捗状況')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation from cultivation_calendar_master where  crop= ?  ",(crop,))
        rows=cursor.fetchall()
        list_operation=[]
        for row in rows:
            list_operation.append(row[0])


        list_csv=[]
        title1="pkuid"
        title2=u"地区名"
        title3=u"圃場名"
        title4=u"品種"
        title5=u"作付面積"

        #list_title=[title1,title2,title3,title4,title5]
        list_title=[title1.encode('"cp932"'),title2.encode('"cp932"'),title3.encode('"cp932"'),title4.encode('"cp932"'),title5.encode('"cp932"')]
        sjis_list_operation = [s.encode("sjis") for s in list_operation]
        list_title.extend(sjis_list_operation)
        #sjis_list_title = [unicode(s, "utf8").encode("sjis") for s in list_title]
        list_csv.append(list_title)
        #対象作物の作付圃場を抽出
        query_string='select farmland_table.pkuid,farmland_table.district,farmland_table.farmland_code,cropping_table.variety,cropping_table.crop_area \
            from farmland_table inner join cropping_table on farmland_table.farmland_code = cropping_table.farmland_code \
            where cropping_table.year=? and cropping_table.crop=? '
        cursor=db.cursor()
        cursor.execute(query_string,(self.year,crop))
        rows=cursor.fetchall()
        #圃場毎に作業の進捗状況を検索→リスト化
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'進捗状況')
        max = len(rows)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(1, max)
        widget.show()
        widget.raise_()
        i=1
        pbar.setValue(i)
        for row in rows:
            i=i+1
            pbar.setValue(i)
            csv_row=[]
            field1=row[0]
            field2=row[1]
            field3=row[2]
            field4=row[3]
            field5=row[4]
            csv_row.append(field1)
            csv_row.append(field2.encode('"cp932"'))
            csv_row.append(field3.encode('"cp932"'))
            csv_row.append(field4.encode('"cp932"'))

            csv_row.append(field5)

            for operation in list_operation:
                #progress=self.get_progress(self.year, crop, operation, row[2])
                try:
                    progress=self.get_progress(self.year, crop, operation, row[2])
                    #print progress
                except:
                    progress=u"未計画"
                    #print "false"


               # csv_row.append(progress)
                csv_row.append(progress.encode('"cp932"'))

            #print csv_row
            #sjis_csv_row = [unicode(s, "utf8").encode("sjis") for s in csv_row]
            list_csv.append(csv_row)

        import types
        #print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])


    def get_progress(self,year,crop,operation,farmland_code):
        query_string='select progress from operation_table  \
            where year=? and crop=?  and operation=? and farmland_code=?'
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(query_string,(year,crop,operation,farmland_code))
        rows=cursor.fetchall()

        for row in rows:
            progress=row[0]

        return progress

    def select_landfields(self):
        proc=pyqgis_processing
        try:
            query=""" "operation_table_operation_schedule"= '%s' and "operation_table_operator_candidate" = '%s'"""  %(self.return_key_value())
            #print query
            selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query))
            self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        except:
            pass

    def return_key_value(self):
        row_count=self.ui.tablewidget_sum.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_sum.item(i,0).isSelected()==True:
                term=self.ui.tablewidget_sum.item(i,0).text()
                operator=self.ui.tablewidget_sum.item(i,1).text()

                break
        key_value=(term,operator)
        #print operator
        return key_value


