# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from correct_report_material_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,dlg):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.dlg=dlg
        self.populate_tablewidget_material()

        self.connect(self.ui.btn_ok,SIGNAL("clicked()"),self.ok)
        self.connect(self.ui.btn_cancel,SIGNAL("clicked()"),self.cancel)

    def populate_tablewidget_material(self):
        crop=self.dlg.return_key_value()[1]
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select material ,package_unit from material_master where crop= ?",(crop,))
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.tablewidget_material.clear()
        self.ui.tablewidget_material.setSortingEnabled(True)
        self.ui.tablewidget_material.setRowCount(row_count)
        headers=[u"選択",u"資材名",u"使用量",u"単位"]
        self.ui.tablewidget_material.setColumnCount(len(headers))
        self.ui.tablewidget_material.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            spbox=QDoubleSpinBox()
            spbox.setSingleStep(0.5)
            chk=QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tablewidget_material.setItem(i,0,chk)
            self.ui.tablewidget_material.setItem(i,1,QTableWidgetItem(row[0]))
            self.ui.tablewidget_material.setCellWidget(i,2,spbox)
            self.ui.tablewidget_material.setItem(i,3,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tablewidget_material.resizeColumnsToContents()
        db.close()

    def ok(self):

        self.dlg.list_material=[]
        row_count=self.ui.tablewidget_material.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_material.item(i,0).checkState()==Qt.Checked:
                self.dlg.list_material.append([self.ui.tablewidget_material.item(i,1).text(),self.ui.tablewidget_material.cellWidget(i,2).value()])

        self.close()

    def cancel(self):
        self.dlg.list_material=[]
        self.close()