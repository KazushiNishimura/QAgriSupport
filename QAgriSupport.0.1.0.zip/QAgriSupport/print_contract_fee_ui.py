# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'print_contract_fee_ui.ui'
#
# Created: Thu May 25 17:48:34 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(350, 78)
        self.formLayout = QtGui.QFormLayout(Dialog)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label)
        self.cmbbox_operation = QtGui.QComboBox(Dialog)
        self.cmbbox_operation.setObjectName(_fromUtf8("cmbbox_operation"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.cmbbox_operation)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.btn_export_csv)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業受託料金集計", None))
        self.label.setText(_translate("Dialog", "対象作業", None))
        self.btn_export_csv.setText(_translate("Dialog", "出力", None))

