# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from selection_crs_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,dlg):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.dlg=dlg

        self.connect(self.ui.btn_ok,SIGNAL("clicked()"),self.ok)
        self.connect(self.ui.btn_cancel,SIGNAL("clicked()"),self.cancel)

    def ok(self):
        if self.ui.rbtn1.isChecked()==True:
            self.dlg.crs=1
        elif self.ui.rbtn2.isChecked()==True:
            self.dlg.crs= 2
        elif self.ui.rbtn3.isChecked()==True:
            self.dlg.crs= 3
        elif self.ui.rbtn4.isChecked()==True:
            self.dlg.crs= 4
        elif self.ui.rbtn5.isChecked()==True:
            self.dlg.crs= 5
        elif self.ui.rbtn6.isChecked()==True:
            self.dlg.crs= 6
        elif self.ui.rbtn7.isChecked()==True:
            self.dlg.crs= 7
        elif self.ui.rbtn8.isChecked()==True:
            self.dlg.crs= 8
        elif self.ui.rbtn9.isChecked()==True:
            self.dlg.crs= 9
        elif self.ui.rbtn10.isChecked()==True:
            self.dlg.crs= 10
        elif self.ui.rbtn11.isChecked()==True:
            self.dlg.crs= 11
        elif self.ui.rbtn12.isChecked()==True:
            self.dlg.crs= 12
        elif self.ui.rbtn13.isChecked()==True:
            self.dlg.crs= 13
        elif self.ui.rbtn14.isChecked()==True:
            self.dlg.crs= 14
        elif self.ui.rbtn15.isChecked()==True:
            self.dlg.crs= 15
        elif self.ui.rbtn16.isChecked()==True:
            self.dlg.crs= 16
        elif self.ui.rbtn17.isChecked()==True:
            self.dlg.crs= 17
        elif self.ui.rbtn18.isChecked()==True:
            self.dlg.crs= 18
        elif self.ui.rbtn19.isChecked()==True:
            self.dlg.crs= 19
        self.close()
    def cancel(self):
        self.dlg.crs= 0
        self.close()


