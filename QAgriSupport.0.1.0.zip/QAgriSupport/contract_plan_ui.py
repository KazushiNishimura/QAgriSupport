# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'contract_plan_ui.ui'
#
# Created: Fri Jun 16 14:45:07 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(489, 583)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.cmbbox_operate = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout_3.addWidget(self.cmbbox_operate, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tablewidget_contract = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_contract.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_contract.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_contract.setObjectName(_fromUtf8("tablewidget_contract"))
        self.tablewidget_contract.setColumnCount(0)
        self.tablewidget_contract.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_contract, 0, 0, 1, 1)
        self.btn_show_table = QtGui.QPushButton(self.groupBox_2)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout_2.addWidget(self.btn_show_table, 1, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_2)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.label_3 = QtGui.QLabel(self.groupBox_3)
        self.label_3.setLayoutDirection(QtCore.Qt.RightToLeft)
        self.label_3.setAutoFillBackground(False)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_4.addWidget(self.label_3, 0, 1, 1, 1)
        self.cmbbox_client = QtGui.QComboBox(self.groupBox_3)
        self.cmbbox_client.setObjectName(_fromUtf8("cmbbox_client"))
        self.gridLayout_4.addWidget(self.cmbbox_client, 0, 2, 1, 1)
        self.label = QtGui.QLabel(self.groupBox_3)
        self.label.setLayoutDirection(QtCore.Qt.RightToLeft)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_4.addWidget(self.label, 1, 0, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox_3)
        self.label_2.setText(_fromUtf8(""))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_4.addWidget(self.label_2, 1, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox_3)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_4.addWidget(self.btn_insert, 1, 2, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_4)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_4)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "受託登録", None))
        self.groupBox.setTitle(_translate("Dialog", "対象作業", None))
        self.groupBox_2.setTitle(_translate("Dialog", "対象作業受託計画一覧", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブルを開く", None))
        self.groupBox_3.setTitle(_translate("Dialog", "選択圃場への作業受託登録", None))
        self.label_3.setText(_translate("Dialog", "依頼者", None))
        self.label.setText(_translate("Dialog", "選択中面積（m2）", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox_4.setTitle(_translate("Dialog", "選択圃場の作業受託解除", None))
        self.btn_delete.setText(_translate("Dialog", "選択圃場の作業受託を解除", None))

