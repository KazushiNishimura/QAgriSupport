# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'gpx_renderer_ui.ui'
#
# Created: Fri Feb 03 13:56:05 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(411, 302)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.btn_renderer = QtGui.QPushButton(self.groupBox)
        self.btn_renderer.setObjectName(_fromUtf8("btn_renderer"))
        self.gridLayout.addWidget(self.btn_renderer, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.cmbbox_operation_day = QtGui.QComboBox(self.groupBox_2)
        self.cmbbox_operation_day.setObjectName(_fromUtf8("cmbbox_operation_day"))
        self.gridLayout_2.addWidget(self.cmbbox_operation_day, 0, 0, 1, 1)
        self.btn_clear_query = QtGui.QPushButton(self.groupBox_2)
        self.btn_clear_query.setObjectName(_fromUtf8("btn_clear_query"))
        self.gridLayout_2.addWidget(self.btn_clear_query, 1, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_2)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.slider_analisys = QtGui.QSlider(self.groupBox_3)
        self.slider_analisys.setMouseTracking(False)
        self.slider_analisys.setPageStep(1)
        self.slider_analisys.setOrientation(QtCore.Qt.Horizontal)
        self.slider_analisys.setObjectName(_fromUtf8("slider_analisys"))
        self.gridLayout_3.addWidget(self.slider_analisys, 0, 0, 1, 1)
        self.btn_clear_query2 = QtGui.QPushButton(self.groupBox_3)
        self.btn_clear_query2.setObjectName(_fromUtf8("btn_clear_query2"))
        self.gridLayout_3.addWidget(self.btn_clear_query2, 1, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_3)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.groupBox.setTitle(_translate("Dialog", "GPXをレンダリングする", None))
        self.btn_renderer.setText(_translate("Dialog", "レンダリング", None))
        self.groupBox_2.setTitle(_translate("Dialog", "データの絞込み", None))
        self.btn_clear_query.setText(_translate("Dialog", "絞込みの解除", None))
        self.groupBox_3.setTitle(_translate("Dialog", "解析", None))
        self.btn_clear_query2.setText(_translate("Dialog", "絞込みの解除", None))

