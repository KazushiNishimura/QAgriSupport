# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from dockwidgetui import Ui_DockWidget
from qgis.core import *
from qgis.gui import *
import datetime
from PyQt4.QtWebKit import  *
import webbrowser
from time import sleep
from QAgriSupport import pyqgis_processing
from QAgriSupport import setup_db
import os,sys


# ダイアログクラス
class DockWidget(QDockWidget, Ui_DockWidget):



    # 初期化QDockWidget
    def __init__(self, iface):
        QDockWidget.__init__(self)
        self.iface = iface
        self.crs=0

        if sys.platform == "win32":
            if not os.path.exists("c:/gisdata/management_db.sqlite"):
                ret = QMessageBox.information(None, u"確認", u"必要なデータベースが見つかりません。セットアップしますか？", QMessageBox.Yes, QMessageBox.No)
                if ret == QMessageBox.Yes:
                    setup_db.select_crs(self)
                    setup_db.copy_from_resource(self.crs)
                    pyqgis_processing.show_msgbox(u"データベース準備完了。c:/gisdata/agrimanagement.qgsから起動し直してください。")
                return
        else:
            if not os.path.exists(os.path.expanduser('~/gisdata/management_db.sqlite')):
                ret = QMessageBox.information(None, u"確認", u"必要なデータベースが見つかりません。セットアップしますか？", QMessageBox.Yes, QMessageBox.No)
                if ret == QMessageBox.Yes:
                    setup_db.select_crs(self)
                    setup_db.copy_from_resource(self.crs)
                    pyqgis_processing.show_msgbox(u"データベース準備完了。c:/gisdata/agrimanagement.qgsから起動し直してください。")
                return


    # QT Designer で作った画面を設定
        self.ui = Ui_DockWidget()
        self.ui.setupUi(self)

        self.year=self.get_year()
        self.ui.spbox_year.setValue(self.year)
        self.ui.cmbbox_label.addItem(u"ラベルなし")
        self.ui.cmbbox_label.addItem(u"農地名称")
        self.ui.cmbbox_label.addItem(u"品種")
        self.ui.cmbbox_label.addItem(u"依頼者")
        QObject.connect(self.ui.btn_usage, SIGNAL("clicked()"), self.renderer_landusage)
        QObject.connect(self.ui.btn_crop_master, SIGNAL("clicked()"),self.open_master_edit_crop)
        QObject.connect(self.ui.btn_calrender_master,SIGNAL("clicked()"),self.open_master_edit_cultivation_calendar)
        QObject.connect(self.ui.btn_contract_master,SIGNAL("clicked()"),self.open_master_edit_contract)
        QObject.connect(self.ui.btn_operator_master,SIGNAL("clicked()"),self.open_master_edit_operator)
        QObject.connect(self.ui.btn_client_master,SIGNAL("clicked()"),self.open_master_edit_client)
        QObject.connect(self.ui.btn_material_master,SIGNAL("clicked()"),self.open_master_edit_material)
        QObject.connect(self.ui.btn_machine_master,SIGNAL("clicked()"),self.open_master_edit_machine)
        QObject.connect(self.ui.btn_cropping_plan,SIGNAL("clicked()"),self.open_cropping_plan)
        QObject.connect(self.ui.btn_operating_plan,SIGNAL("clicked()"),self.open_operating_plan)
        QObject.connect(self.ui.btn_open_register_report,SIGNAL("clicked()"),self.open_register_report)
        QObject.connect(self.ui.btn_view_report,SIGNAL("clicked()"),self.open_view_report)
        QObject.connect(self.ui.btn_print,SIGNAL("clicked()"),self.print_map)
        QObject.connect(self.ui.btn_open_print_operation_plan,SIGNAL("clicked()"),self.open_print_operation_plan)
        QObject.connect(self.ui.btn_op_schedule,SIGNAL("clicked()"),self.open_renderer_operation_plan)
        QObject.connect(self.ui.btn_update_area,SIGNAL("clicked()"),self.open_update_area)
        QObject.connect(self.ui.btn_cropping_plan_adjust,SIGNAL("clicked()"),self.open_cropping_plan_adjust)
        QObject.connect(self.ui.btn_op_progress,SIGNAL("clicked()"),self.open_renderer_progress)
        QObject.connect(self.ui.btn_crop,SIGNAL("clicked()"),self.open_renderer_cropping_plan)
        QObject.connect(self.ui.btn_import_mobile,SIGNAL("clicked()"),self.open_mobile_importer)
        QObject.connect(self.ui.btn_contract_plan,SIGNAL("clicked()"),self.open_contract_plan)
        QObject.connect(self.ui.btn_contract_operate_plan,SIGNAL("clicked()"),self.open_contract_operate_plan)
        QObject.connect(self.ui.btn_send_mail,SIGNAL("clicked()"),self.open_sendmail)
        QObject.connect(self.ui.btn_print_qr,SIGNAL("clicked()"),self.open_qrcode_print)
        QObject.connect(self.ui.btn_renderer_contract_plan,SIGNAL("clicked()"),self.open_renderer_contract_plan)
        QObject.connect(self.ui.btn_renderer_contract_operate_plan,SIGNAL("clicked()"),self.open_renderer_contract_operate_plan)
        QObject.connect(self.ui.btn_renderer_contract_operate_progress,SIGNAL("clicked()"),self.open_renderer_contract_operation_progress)
        QObject.connect(self.ui.btn_print_contract_operation_plan,SIGNAL("clicked()"),self.open_print_contract_operation_plan)
        QObject.connect(self.ui.btn_print_contract_fee,SIGNAL("clicked()"),self.show_print_contract_fee)
        QObject.connect(self.ui.btn_resource_operation_performance,SIGNAL("clicked()"),self.open_resource_operation_performance)
        self.connect(self.ui.cmbbox_label, SIGNAL("currentIndexChanged(const QString&)"),self.set_label)
        try:
            pyqgis_processing.remove_join()
        except:
            pyqgis_processing.show_msgbox(u"c:/gisdata/agrimanagement.qgsから起動し直してください。")
            return
        pyqgis_processing.add_join_cropping_table()
        pyqgis_processing.add_join_operation_table()
        pyqgis_processing.add_join_contract_table()

        self.set_selection_color()

    def set_label(self):
        if self.ui.cmbbox_label.currentText()==u"ラベルなし":
            pyqgis_processing.hidden_label(pyqgis_processing.get_farmland_table())
        elif self.ui.cmbbox_label.currentText()==u"農地名称":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "farmland_code")
        elif self.ui.cmbbox_label.currentText()==u"品種":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "cropping_table_variety")
        elif self.ui.cmbbox_label.currentText()==u"依頼者":
            pyqgis_processing.show_label(pyqgis_processing.get_farmland_table(), "contract_table_client")



    def open_resource_operation_performance(self):
        from resource_operation_performance import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def show_print_contract_fee(self):
        from print_contract_fee import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()




    def open_print_contract_operation_plan(self):
        pyqgis_processing.clear_all_dialog()
        from print_contract_operation_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_contract_operation_progress(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_contract_operation_progress import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()


    def open_renderer_contract_operate_plan(self):
        pyqgis_processing.clear_all_dialog()

        from renderer_contract_operate_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_contract_plan(self):
        pyqgis_processing.clear_all_dialog()

        from renderer_contract_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()


    def open_sendmail(self):
        pyqgis_processing.clear_all_dialog()
        from to_mobile import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_qrcode_print(self):
        pyqgis_processing.clear_all_dialog()
        from qrcode_print import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_crop(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_crop import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_cultivation_calendar(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_cultivation_calendar import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_contract(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_contract import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_operator(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_operator import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_client(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_client import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_material(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_material import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_master_edit_machine(self):
        pyqgis_processing.clear_all_dialog()
        from master_edit_machine import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_cropping_plan(self):
        pyqgis_processing.clear_all_dialog()

        from cropping_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_contract_plan(self):
        pyqgis_processing.clear_all_dialog()

        from contract_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_operating_plan(self):
        pyqgis_processing.clear_all_dialog()
        from operating_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_register_report(self):
        pyqgis_processing.clear_all_dialog()
        from register_report import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def get_year(self):
        today=datetime.date.today()
        return today.year

    def open_view_report(self):
        pyqgis_processing.clear_all_dialog()
        from view_report import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_print_operation_plan(self):
        pyqgis_processing.clear_all_dialog()
        from print_operation_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_operation_plan(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_operation_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_update_area(self):
        pyqgis_processing.clear_all_dialog()
        from update_area import Dialog
        self.dlg=Dialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()

    def open_cropping_plan_adjust(self):
        pyqgis_processing.clear_all_dialog()

        from cropping_plan_adjust import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()
    def open_cropping_plan_adjust2(self):
        #フリーズ対策のテストコード
        pyqgis_processing.clear_all_dialog()
        pyqgis_processing.open_start_widget()
        pyqgis_processing.check_dialog()
        from cropping_plan_adjust import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_progress(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_operation_progress import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_renderer_cropping_plan(self):
        pyqgis_processing.clear_all_dialog()
        from renderer_cropping_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def open_contract_operate_plan(self):
        pyqgis_processing.clear_all_dialog()
        from contract_operate_plan import Dialog
        self.dlg=Dialog(self.iface,self.ui.spbox_year.value())
        self.dlg.show()
        self.dlg.exec_()

    def renderer_landusage(self):

        import pyqgis_processing
        proc=pyqgis_processing
        farmland_table=pyqgis_processing.get_farmland_table()
        proc.clear_query(farmland_table)

        list_rule=[]
        query_string= '\"kind\" ='+ u'\'経営耕地\''
        label_string=u"経営耕地"
        list_rule.append([label_string,query_string])
        query_string= '\"kind\" ='+ u'\'受託地\''
        label_string=u"受託地"
        list_rule.append([label_string,query_string])
        query_string= '\"kind\" ='+ u'\'その他\''
        label_string=u"その他"
        list_rule.append([label_string,query_string])

        proc.renderer_map1(farmland_table, list_rule)
        farmland_table.dataProvider().forceReload()
        farmland_table.triggerRepaint()


    def print_map(self):

        import pyqgis_processing
        import os, sys, subprocess
        proc=pyqgis_processing
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'レイアウト作成中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)
        proc.save_map_image()
        html=u"""<html><head>

        <style>
            .cssHeaderCell {

                font-size: 16px;

            }
            .cssTableCell {
                font-size: 20px;

            }

        </style>
        </head>
         <body>
         <h1><img src="%s"  """  % ("map.png")
        html+=u"""width="95%" ></h1>
        </body></html>"""




        f = open(proc.get_prj_path() +"/mapimage/directions.html", 'w') # 書き込みモードで開く
        f.write(html.encode('utf-8')) # 引数の文字列をファイルに書き込む
        f.close() # ファイルを閉じる
        pbar.setValue(1)
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"/mapimage/directions.html")
            #os.startfile(proc.get_prj_path() +"/mapimage/map.pdf")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"/mapimage/directions.html"])
            #subprocess.call([opener, proc.get_prj_path() +"/mapimage/out.pdf"])



    def open_mobile_importer(self):
        pyqgis_processing.clear_all_dialog()
        db_path = QFileDialog.getOpenFileName(None, u"データベースを選択してください", ".", "spatialiteDB (*.sqlite)")

        if db_path !="":
            from import_mobile import Dialog
            self.dlg=Dialog(self.iface,self.ui.spbox_year.value(),db_path)
            self.dlg.show()
            self.dlg.exec_()


    def set_selection_color(self):
        p_color=QColor()
        p_color.setHsv(300,255,255)
        self.iface.mapCanvas().setSelectionColor(p_color)

