# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from cropping_plan_adjust_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import csv
import os, sys, subprocess

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y

        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.cropping_table=pyqgis_processing.get_cropping_table()


        proc=pyqgis_processing
        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.cropping_table)
        proc.set_query(self.farmland_table, u'"kind"=\'経営耕地\'')
        proc.set_query(self.cropping_table, '"year"='+ str(self.year) )

        #proc.add_join_cropping_table()

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_cropping_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_cropping_table(self.farmland_table)

        self.populate_cmbbox_crop()

        self.connect(self.ui.cmbbox_crop, SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_change)
        self.ui.tablewidget_landfield.itemClicked.connect(self.select_feature)
        self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_area)
        self.connect(self.ui.btn_CSV,SIGNAL("clicked()"),self.export_csv)


    def cmbbox_change(self):
        self.set_query_cropping_table()
        self.render_farmland()
        self.populate_tablewidget_landfield()
        self.populate_tablewidget_area()

    def populate_cmbbox_crop(self):
        proc=pyqgis_processing

        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")

        for row in proc.return_crop():
            self.ui.cmbbox_crop.addItem(row[0])

    def set_query_cropping_table(self):
        pyqgis_processing.set_query(self.cropping_table, self.create_query_string_crop())

    def create_query_string_crop(self):
        crop=self.ui.cmbbox_crop.currentText()

        query_string=""" "year" =%s and  "crop" ='%s'"""  %(str(self.year),crop)
        return query_string

    def render_farmland(self):
        pyqgis_processing.renderer_map1(self.farmland_table, self.create_renderer_rule())
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def create_renderer_rule(self):
        crop=self.ui.cmbbox_crop.currentText()
        list_rule=[]
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        sql_string="""select crop ,variety from cropping_table where year=%s and crop='%s' group by crop,variety """ %(str(self.year),crop)
        cursor.execute(sql_string)
        rows=cursor.fetchall()
        for row in rows:
            render_label=row[0] + ':' + row[1]
            renderer_string=""" "cropping_table_crop" ='%s' and "cropping_table_variety" ='%s'""" %(row[0],row[1])
            list_rule.append([render_label,renderer_string])


        return list_rule

    def populate_tablewidget_landfield(self):
        crop=self.ui.cmbbox_crop.currentText()
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select id,farmland_code,variety,crop_area from cropping_table where year= ? and crop= ?  ",(self.year,crop))
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.tablewidget_landfield.clear()
        self.ui.tablewidget_landfield.setSortingEnabled(True)
        self.ui.tablewidget_landfield.setRowCount(row_count)
        headers=[u"id",u"圃場名",u"品種",u"作付面積"]
        self.ui.tablewidget_landfield.setColumnCount(len(headers))
        self.ui.tablewidget_landfield.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_landfield.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_landfield.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tablewidget_landfield.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_landfield.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tablewidget_landfield.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_landfield.setItem(i,3,QTableWidgetItem(str(round(row[3],1))))

            i=i+1
        self.ui.tablewidget_landfield.resizeColumnsToContents()
        self.ui.tablewidget_landfield.hideColumn(0)

    def populate_tablewidget_area(self):
        list_sum=[]
        crop=self.ui.cmbbox_crop.currentText()
        proc=pyqgis_processing
        db=proc.connect_db()

        cursor=db.cursor()
        cursor.execute("select variety from crop_master where crop= ?  ",(crop,))
        list_variety=cursor.fetchall()

        for item in list_variety:
            variety=item[0]
            cursor=db.cursor()
            cursor.execute('select total (crop_area) from cropping_table where year=? and crop=? and variety=?',(self.year,crop,variety))
            total=cursor.fetchmany(1)
            list_sum.append([variety,round(total[0][0],1)])

        self.ui.tablewidget_area.clear()
        self.ui.tablewidget_area.setRowCount(len(list_sum))
        headers=[u"品種",u"作付面積"]
        self.ui.tablewidget_area.setColumnCount(len(headers))
        self.ui.tablewidget_area.setHorizontalHeaderLabels(headers)
        i=0
        for row in list_sum:
            self.ui.tablewidget_area.setItem(i,0,QTableWidgetItem(row[0]))
            self.ui.tablewidget_area.setItem(i,1,QTableWidgetItem(str(row[1])))
            i=i+1
        self.ui.tablewidget_area.resizeColumnsToContents()

    def select_feature(self):
        rows=[]

        for index in self.ui.tablewidget_landfield.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            featur_id=self.ui.tablewidget_landfield.item(row,1).text()

        selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression('"farmland_code"= \'' + featur_id + '\'' ))

        self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        #iface.mapCanvas().zoomToSelected()

    def update_area(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.lineEdit.text()=="":
            pyqgis_processing.show_msgbox(u"修正面積を入力してください")
            return

        rows=[]
        for index in self.ui.tablewidget_landfield.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        if len(rows)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        for row in rows:
            featur_id=int(self.ui.tablewidget_landfield.item(row,0).text())



        proc=pyqgis_processing
        db=proc.connect_db()

        sql=u""" update cropping_table set  crop_area=?
            where id=? """
        update_row=(float(self.ui.lineEdit.text()),featur_id)
        db.execute(sql,update_row)
        db.commit()

        self.populate_tablewidget_landfield()
        self.populate_tablewidget_area()

    def export_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        filename= path + "/"+"%s.csv"  % (str(self.year)+'_'+self.ui.cmbbox_crop.currentText()+u'_圃場一覧')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        crop=self.ui.cmbbox_crop.currentText()
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select id,farmland_code,variety,crop_area from cropping_table where year= ? and crop= ?  ",(self.year,crop))
        rows=cursor.fetchall()
        list_csv=[]
        field_name1="id"
        field_name2=u"圃場名"
        field_name3=u"品種"
        field_name4=u"作付面積"
        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),field_name4.encode('"cp932"')])
        for row in rows:
            list_csv.append([row[0],row[1].encode('"cp932"'),row[2].encode('"cp932"'),row[3]])


        import types
        print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])



