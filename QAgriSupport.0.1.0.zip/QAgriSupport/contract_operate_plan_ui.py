# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'contract_operate_plan_ui.ui'
#
# Created: Tue Jun 20 10:12:48 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(386, 541)
        self.gridLayout_4 = QtGui.QGridLayout(Dialog)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tablewidget_contract = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_contract.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_contract.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_contract.setObjectName(_fromUtf8("tablewidget_contract"))
        self.tablewidget_contract.setColumnCount(0)
        self.tablewidget_contract.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_contract, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.dt_end = QtGui.QDateEdit(self.groupBox_4)
        self.dt_end.setCalendarPopup(True)
        self.dt_end.setObjectName(_fromUtf8("dt_end"))
        self.gridLayout_5.addWidget(self.dt_end, 1, 1, 1, 1)
        self.label_3 = QtGui.QLabel(self.groupBox_4)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_5.addWidget(self.label_3, 2, 0, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox_4)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_5.addWidget(self.label_2, 1, 0, 1, 1)
        self.label = QtGui.QLabel(self.groupBox_4)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_5.addWidget(self.label, 0, 0, 1, 1)
        self.dt_start = QtGui.QDateEdit(self.groupBox_4)
        self.dt_start.setCalendarPopup(True)
        self.dt_start.setObjectName(_fromUtf8("dt_start"))
        self.gridLayout_5.addWidget(self.dt_start, 0, 1, 1, 1)
        self.cmbbox_operator = QtGui.QComboBox(self.groupBox_4)
        self.cmbbox_operator.setObjectName(_fromUtf8("cmbbox_operator"))
        self.gridLayout_5.addWidget(self.cmbbox_operator, 2, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox_4)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_5.addWidget(self.btn_insert, 3, 0, 1, 2)
        self.gridLayout_4.addWidget(self.groupBox_4, 4, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.cmbbox_operate = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout_3.addWidget(self.cmbbox_operate, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tablewidget_plan = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_plan.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_plan.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_plan.setObjectName(_fromUtf8("tablewidget_plan"))
        self.tablewidget_plan.setColumnCount(0)
        self.tablewidget_plan.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_plan, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_3, 2, 0, 1, 1)
        self.btn_show_table = QtGui.QPushButton(Dialog)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout_4.addWidget(self.btn_show_table, 3, 0, 1, 1)
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout_6 = QtGui.QGridLayout(self.groupBox_5)
        self.gridLayout_6.setObjectName(_fromUtf8("gridLayout_6"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_5)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_6.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_5, 5, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業計画（受託作業）", None))
        self.groupBox_2.setTitle(_translate("Dialog", "受託一覧", None))
        self.groupBox_4.setTitle(_translate("Dialog", "選択行への作業計画登録", None))
        self.label_3.setText(_translate("Dialog", "作業予定者", None))
        self.label_2.setText(_translate("Dialog", "作業完了予定日", None))
        self.label.setText(_translate("Dialog", "作業開始予定日", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox.setTitle(_translate("Dialog", "対象作業", None))
        self.groupBox_3.setTitle(_translate("Dialog", "日程・作業者別面積", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブルの表示", None))
        self.groupBox_5.setTitle(_translate("Dialog", "選択行の計画削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

