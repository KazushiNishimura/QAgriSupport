# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_crop_ui.ui'
#
# Created: Wed Apr 12 13:56:21 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(388, 442)
        self.gridLayout_3 = QtGui.QGridLayout(Dialog)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.table_widget_crop = QtGui.QTableWidget(Dialog)
        self.table_widget_crop.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.table_widget_crop.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.table_widget_crop.setObjectName(_fromUtf8("table_widget_crop"))
        self.table_widget_crop.setColumnCount(0)
        self.table_widget_crop.setRowCount(0)
        self.gridLayout_3.addWidget(self.table_widget_crop, 0, 0, 1, 1)
        self.gbox_register_crop = QtGui.QGroupBox(Dialog)
        self.gbox_register_crop.setObjectName(_fromUtf8("gbox_register_crop"))
        self.gridLayout = QtGui.QGridLayout(self.gbox_register_crop)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.gbox_register_crop)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.lineedit_crop = QtGui.QLineEdit(self.gbox_register_crop)
        self.lineedit_crop.setObjectName(_fromUtf8("lineedit_crop"))
        self.gridLayout.addWidget(self.lineedit_crop, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.gbox_register_crop)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.lineedit_variety = QtGui.QLineEdit(self.gbox_register_crop)
        self.lineedit_variety.setObjectName(_fromUtf8("lineedit_variety"))
        self.gridLayout.addWidget(self.lineedit_variety, 1, 1, 1, 1)
        self.btn_register_crop = QtGui.QPushButton(self.gbox_register_crop)
        self.btn_register_crop.setObjectName(_fromUtf8("btn_register_crop"))
        self.gridLayout.addWidget(self.btn_register_crop, 2, 1, 1, 1)
        self.gridLayout_3.addWidget(self.gbox_register_crop, 1, 0, 1, 1)
        self.gbox_delete_crop = QtGui.QGroupBox(Dialog)
        self.gbox_delete_crop.setObjectName(_fromUtf8("gbox_delete_crop"))
        self.gridLayout_2 = QtGui.QGridLayout(self.gbox_delete_crop)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.btn_delete_crop = QtGui.QPushButton(self.gbox_delete_crop)
        self.btn_delete_crop.setObjectName(_fromUtf8("btn_delete_crop"))
        self.gridLayout_2.addWidget(self.btn_delete_crop, 0, 0, 1, 1)
        self.gridLayout_3.addWidget(self.gbox_delete_crop, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作物・品種登録", None))
        self.gbox_register_crop.setTitle(_translate("Dialog", "作物・品種登録", None))
        self.label.setText(_translate("Dialog", "作物名", None))
        self.label_2.setText(_translate("Dialog", "品種名", None))
        self.btn_register_crop.setText(_translate("Dialog", "登録する", None))
        self.gbox_delete_crop.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete_crop.setText(_translate("Dialog", "削除する", None))

