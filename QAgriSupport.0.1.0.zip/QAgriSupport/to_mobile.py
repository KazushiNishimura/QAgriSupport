# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from to_mobile_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import os.path
import datetime
import smtplib
import csv
from email import Encoders
from email.Utils import formatdate
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.Header import Header
import zipfile

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing

        #self._zip()


        self.SMTP = "smtp.gmail.com"
        #self.SMTP="smtp.mail.yahoo.co.jp"
        #self.PORT = 587
        self.PORT = 465
        self.list_csv=[]

        self.load_csv()
        self.population_tablewidget_to()
        self.population_cmbbox()
        self.connect(self.ui.btn_send,SIGNAL("clicked()"),self.run)




    def _zip(self):
        prj_file = QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        #zf = zipfile.ZipFile(path+"/management_db.sqlite.zip", "w",zipfile.ZIP_DEFLATED)
        zf = zipfile.ZipFile(path+"/management_db.sqlite.qzip", "w",zipfile.ZIP_DEFLATED)

        #zf = zipfile.ZipFile(path+"/management_db.sqlite.zip", "w",zipfile.ZIP_STORED)
        zf.write(path+"/management_db.sqlite", "management_db.sqlite")
        zf.close()

    def create_message(self,from_addr, to_addr, subject, body, mime=None, attach_file=None):
        """
        メッセージを作成する
        @:param from_addr 差出人
        @:param to_addr 宛先
        @:param subject 件名
        @:param body 本文
        @:param mime MIME
        @:param attach_file 添付ファイル
        @:return メッセージ
        """
        msg = MIMEMultipart()
        msg["From"] = from_addr
        msg["To"] = ",".join(to_addr)
        msg["Date"] = formatdate()
        msg["Subject"] = Header(subject,'utf-8')
        body = MIMEText(body.encode('utf-8'),"plain",'utf-8')
        msg.attach(body)

        # 添付ファイル
        if mime != None and attach_file != None:
            attachment = MIMEBase(mime['type'],mime['subtype'])
            file = open(attach_file['path'])
            attachment.set_payload(file.read())
            file.close()
            Encoders.encode_base64(attachment)
            msg.attach(attachment)
            attachment.add_header("Content-Disposition","attachment", filename=attach_file['name'])

        return msg

    def send(self,from_addr, to_addrs, msg):
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'送信中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)

        """
        メールを送信する
        @:param from_addr 差出人
        @:param to_addr 宛先(list)
        @:param msg メッセージ
        """
        #smtpobj = smtplib.SMTP(self.SMTP, self.PORT)
        smtpobj = smtplib.SMTP_SSL(self.SMTP, self.PORT)
#         smtpobj.ehlo()
#         smtpobj.starttls()
#         smtpobj.ehlo()

        try:
            smtpobj.login(self.ui.cmbbox_from_mail.currentText(), self.ui.lineEdit_pass.text())
        except:
            pyqgis_processing.show_msgbox(u"アカウント："+self.ui.cmbbox_from_mail.currentText()+u"にログインできません")
            return
        smtpobj.sendmail(from_addr, to_addrs, msg.as_string())
        smtpobj.close()

        pbar.setValue(1)

    def run(self):

        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'データ圧縮中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)
        self._zip()
        pbar.setValue(1)

        list_filter=filter(lambda x: x[2]==u"送信先",self.list_csv)
        to_addr=[]
#         for item in list_filter:
#             to_addr.append(item[1])
        row_count=self.ui.tablewidget_to_mail.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_to_mail.item(i,0).checkState() == Qt.Checked:
                to_addr.append(self.ui.tablewidget_to_mail.item(i,2).text())



        #件名と本文
        subject = u"【QAgriSupportデータ送信】"
        body = u"圃場データ最新版の送付です。"
        prj_file = QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        #添付ファイル設定(text.txtファイルを添付)
        mime={'type':'application', 'subtype':'qzip'}
        #mime={'type':'application', 'subtype':'db'}
        #attach_file={'name':'management_db.sqlite.zip', 'path':path+'/management_db.sqlite.zip'}
        attach_file={'name':'management_db.sqlite.qzip', 'path':path+'/management_db.sqlite.qzip'}
        #attach_file={'name':'management_db.sqlite', 'path':path+'/management_db.sqlite'}
        #attach_file={'name':'management_db.zip', 'path':path+'/management_db.zip'}

        #メッセージの作成(添付ファイルあり)
        msg = self.create_message(self.ui.cmbbox_from_mail.currentText(), to_addr, subject, body, mime, attach_file)

        #メッセージ作成(添付ファイルなし)
        #msg = self.create_message(self.ui.cmbbox_from_mail.currentText(), to_addr, subject, body)

        #送信
        self.send(self.ui.cmbbox_from_mail.currentText(), to_addr, msg)

    def load_csv(self):
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        table_csv=open(path + "/"+u"メールリスト.csv")
        data=csv.reader(table_csv)
        header = data.next()

        for row in data:
            self.list_csv.append([row[0].decode("cp932"),row[1].decode("cp932"),row[2].decode("cp932")])

    def population_tablewidget_to(self):
        try:

            list_filter=filter(lambda x: x[2]==u"送信先",self.list_csv)
            self.ui.tablewidget_to_mail.clear()
            self.ui.tablewidget_to_mail.setSortingEnabled(True)
            self.ui.tablewidget_to_mail.setRowCount(len(list_filter))
            headers=[u"選択",u"名前",u"メールアドレス"]
            self.ui.tablewidget_to_mail.setColumnCount(len(headers))
            self.ui.tablewidget_to_mail.setHorizontalHeaderLabels(headers)

            i=0

            for item in list_filter:
                chk =QTableWidgetItem()
                chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                chk.setCheckState(Qt.Unchecked)
                self.ui.tablewidget_to_mail.setItem(i,0,chk)
                self.ui.tablewidget_to_mail.setItem(i,1,QTableWidgetItem(str(item[0])))
                self.ui.tablewidget_to_mail.setItem(i,2,QTableWidgetItem(str(item[1])))

                i=i+1

            self.ui.tablewidget_to_mail.resizeColumnsToContents()
        except:
            pass

    def population_cmbbox(self):
        try:

            list_filter=filter(lambda x: x[2]==u"送信元",self.list_csv)


            for item in list_filter:
                self.ui.cmbbox_from_mail.addItem(str(item[1]))


        except:
            pass