# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from print_contract_operation_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y


        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.contract_table=pyqgis_processing.get_contract_table()
        self.operation_table=pyqgis_processing.get_operation_table()




        proc=pyqgis_processing



        proc.clear_query(self.farmland_table)
        proc.clear_query(self.contract_table)
        proc.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        proc.set_query(self.contract_table, '"year"='+ str(self.year) )

        proc.hide_all_columns(self.farmland_table)
        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_contract_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_contract_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)



        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_operate()
        self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
        self.connect(self.ui.cmbbox_operation_term,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_term_change)
        self.connect(self.ui.cmbbox_operator,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operator_change)
# #
        self.connect(self.ui.btn_print,SIGNAL("clicked()"),self.print_map)
        self.connect(self.ui.btn_export_csv,SIGNAL("clicked()"),self.export_csv)
        self.ui.tablewidget_client.itemClicked.connect(self.tablewidget_contract_clicked)


    def populate_cmbbox_operate(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        self.ui.cmbbox_operate.clear()
        self.ui.cmbbox_operate.addItem("")

        cursor=db.cursor()
        cursor.execute("select operation from contract_operation_master")
        rows=cursor.fetchall()
        list_operation=[]
        for row in rows:
            if row[0] not in list_operation:
                list_operation.append(row[0])
                self.ui.cmbbox_operate.addItem(row[0])
        db.close()

    def cmbbox_operate_change(self):
        self.set_query_contract_table()
        self.set_query_operation_table()
        operation=self.ui.cmbbox_operate.currentText()
        list_client=self.make_list_clietnt()
        list_client_area=self.sum_contract_area(operation,list_client)
        self.populate_tablewidget_contract(list_client_area)
        self.populate_cmbbox_term()
        #self.populate_sum_table()
        self.renderer_map()

    def create_query_string_operate(self):

        operate=self.ui.cmbbox_operate.currentText()



        query_string=""" "year"=%d and "operation"='%s' """ %(self.year,operate)

        return query_string

    def create_query_string_operation(self):

        year=self.year
        crop=u"受託"
        operate=self.ui.cmbbox_operate.currentText()
        query_string=""" "year"=%d and "crop"='%s' and "operation"='%s' """ %(year,crop,operate)


        return query_string

    def set_query_contract_table(self):
        pyqgis_processing.set_query(self.contract_table,self.create_query_string_operate())

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table,self.create_query_string_operation())

    def make_list_clietnt(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select client from contract_table where operation=?",(self.ui.cmbbox_operate.currentText(),))
        rows=cursor.fetchall()
        list_client=[]
        for row in rows:
            if row[0] not in list_client:
                list_client.append(row[0])
        db.close()

        return list_client

    def sum_contract_area(self,operation,list_client):
        proc=pyqgis_processing
        db=proc.connect_db()
        list_client_area=[]
        area=0
        for client in list_client:
            key=(self.year,operation,client)
            query=""" select total (operation_area) from contract_table where year=? and operation=? and client=?"""
            cursor=db.cursor()
            cursor.execute(query,key)
            area=str(round(cursor.fetchmany(1)[0][0],1))
            list_client_area.append((client,area))
        db.close()
        return list_client_area

    def populate_tablewidget_contract(self,list_client_area):
        self.ui.tablewidget_client.clear()
        self.ui.tablewidget_client.setSortingEnabled(True)
        headers=[u"依頼者",u"面積"]
        self.ui.tablewidget_client.setColumnCount(len(headers))
        self.ui.tablewidget_client.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_client.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_client.setRowCount(0)
        row=0
        for item in list_client_area:
            self.ui.tablewidget_client.insertRow(row)
            self.ui.tablewidget_client.setItem(row,0,QTableWidgetItem(item[0]))
            self.ui.tablewidget_client.setItem(row,1,QTableWidgetItem(item[1]))
            row=row+1

    def populate_cmbbox_term(self):
        self.ui.cmbbox_operation_term.clear()
        list_schedule=[]
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        year=self.year
        crop=u"受託"
        operation=self.ui.cmbbox_operate.currentText()
        cursor.execute("select operation_schedule from operation_table where year=? and crop=? and operation=?",(year ,crop,operation,))
        rows=cursor.fetchall()
        for row in rows:
            if row[0] not in list_schedule:
                list_schedule.append(row[0])

        for item in list_schedule:
            self.ui.cmbbox_operation_term.addItem(item)

        db.close()

    def populate_cmbbox_operator_candidate(self):
        self.ui.cmbbox_operator.clear()
        proc=pyqgis_processing
        db=proc.connect_db()
        year=self.year
        crop=u"受託"
        operation=self.ui.cmbbox_operate.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        cursor=db.cursor()
        cursor.execute("select operator_candidate from operation_table where year=? and crop = ? and operation=? and operation_schedule=?",(year,crop,operation,term,))
        rows=cursor.fetchall()
        list_operator=[]
        for row in rows:
            if row[0] not in list_operator:
                list_operator.append(row[0])

        for item in list_operator:
            self.ui.cmbbox_operator.addItem(item)

        db.close()

    def cmbbox_term_change(self):
        self.populate_cmbbox_operator_candidate()

    def cmbbox_operator_change(self):
        self.renderer_map()

    def renderer_map(self):
        if self.return_render_mode()=="plan":
            self.renderer_map_plan()
        else:
            try:
                self.renderer_map_client()
            except:
                pass

    def return_render_mode(self):
        if self.ui.tabwidget.currentIndex()==1:
            return "client"
        else:
            return "plan"

    def renderer_map_plan(self):

        crop=u"受託"
        operation=self.ui.cmbbox_operate.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        operator=self.ui.cmbbox_operator.currentText()
        label_string=crop+":"+ operation+":"+term+":"+operator+u":未完了"
        query_string='\"operation_table_crop\" = '+ '\''+ crop + '\'' + 'and '+ '\"operation_table_operation\" =' + '\''+operation + '\'' \
        + ' and ' + '\"operation_table_operation_schedule\" =' + '\''+ term + '\''+ ' and ' + '\"operation_table_operator_candidate\" ='+ '\'' +operator + '\'' + \
        ' and ' + u'\"operation_table_progress\" =  \'未完了\''

        layer=self.farmland_table
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        root_rule.children()[0].setLabel(label_string)
        root_rule.children()[0].setFilterExpression(query_string)


        label_string=crop+":"+ operation+":"+term+":"+operator+u":完了"
        query_string='\"operation_table_crop\" = '+ '\''+ crop + '\'' + 'and '+ '\"operation_table_operation\" =' + '\''+operation + '\'' \
        + ' and ' + '\"operation_table_operation_schedule\" =' + '\''+ term + '\''+ ' and ' + '\"operation_table_operator_candidate\" ='+ '\'' +operator + '\'' + \
        ' and ' + u'\"operation_table_progress\" =  \'完了\''

        rule=root_rule.children()[0].clone()
        rule.setLabel(label_string)
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)

        layer.setRendererV2(renderer)
        #self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def tablewidget_contract_clicked(self):
        key=self.return_key_value_contract()
        self.renderer_map_client(key)
    def return_key_value_contract(self):
        client = None
        row_count=self.ui.tablewidget_client.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_client.item(i,0).isSelected()==True:
                client=self.ui.tablewidget_client.item(i,0).text()

                break
        key_value=(self.ui.cmbbox_operate.currentText(),client)
        return key_value

    def renderer_map_client(self,key):

        crop=u"受託"
        operation=self.ui.cmbbox_operate.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        operator=self.ui.cmbbox_operator.currentText()
        label_string=crop+":"+ operation+":"+key[1]+":"+u":未完了"
        query_string=u""" "contract_table_operation"= '%s' and "contract_table_client" = '%s' and ("operation_table_progress" =  '未完了' or \"operation_table_progress\" is None )"""  %(key)

        layer=self.farmland_table
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        root_rule.children()[0].setLabel(label_string)
        root_rule.children()[0].setFilterExpression(query_string)


        label_string=crop+":"+ operation+":"+key[1]+":"+u":完了"
        query_string=u""" "contract_table_operation"= '%s' and "contract_table_client" = '%s' and "operation_table_progress" =  '完了'"""  %(key)

        rule=root_rule.children()[0].clone()
        rule.setLabel(label_string)
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)

        layer.setRendererV2(renderer)
        #self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def print_map(self):
        if self.ui.tabwidget.currentIndex()==0:
            if self.ui.cmbbox_operate.currentText()=="":
                pyqgis_processing.show_msgbox(u"対象作業を選択してください")
                return
            if self.ui.cmbbox_operation_term.currentText()=="":
                pyqgis_processing.show_msgbox(u"対象作業予定期間を選択してください")
                return
            if self.ui.cmbbox_operator.currentText()=="":
                pyqgis_processing.show_msgbox(u"対象作業予定者を選択してください")
                return
        else:
            if self.return_key_value_contract()[1] is None:
                pyqgis_processing.show_msgbox(u"対象依頼者を選択してください")
                return

        proc=pyqgis_processing
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'レイアウト作成中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)

        proc.save_map_image()

        html=u"""<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <style>
            .cssHeaderCell {

                font-size: 16px;

            }
            .cssTableCell {
                font-size: 20px;

            }

        </style>
        </head>
         <body>
         <h1><img src="%s"  """  % ("map.png")
        html+=u"""width="100%" ></h1>"""
        html+=u""" <table border="3" width="100%" ><tr>
        <td width="50%" height="250" valign="top">作業者：</td><td width="50%" height="250" valign="top">使用機材：</td>
        </tr></table>
        <table border="3" width="100%"><tr>
        <td width="50%" height="250" valign="top">使用資材：</td><td width="50%" height="250" valign="top">備考：</td>
        </tr></table>"""



        f = open(proc.get_prj_path() +"/mapimage/directions.html", 'w') # 書き込みモードで開く
        f.write(html.encode('utf-8')) # 引数の文字列をファイルに書き込む
        f.close() # ファイルを閉じる
        pbar.setValue(1)
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"/mapimage/directions.html")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"/mapimage/directions.html"])

    def export_csv(self):
        if self.ui.tabwidget.currentIndex()==0:
            if self.ui.cmbbox_operate.currentText()=="":
                pyqgis_processing.show_msgbox(u"対象作業を選択してください")
                return
            if self.ui.cmbbox_operation_term.currentText()=="":
                pyqgis_processing.show_msgbox(u"対象作業予定期間を選択してください")
                return
            if self.ui.cmbbox_operator.currentText()=="":
                pyqgis_processing.show_msgbox(u"対象作業予定者を選択してください")
                return
        else:
            if self.return_key_value_contract()[1] is None:
                pyqgis_processing.show_msgbox(u"対象依頼者を選択してください")
                return

        crop=u"受託"
        year=self.year
        operation=self.ui.cmbbox_operate.currentText()
        client=self.return_key_value_contract()[1]
        term=self.ui.cmbbox_operation_term.currentText()
        term_r=term.replace('/', '-')
        operator=self.ui.cmbbox_operator.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/作業指示（受託作業）"):
            os.mkdir(path+u"/作業指示（受託作業）")
        path+=u"/作業指示（受託作業）"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+'_'+operation+  u'_作業圃場一覧')

        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1="pkuid"
        field_name2=u"地区名"
        field_name3=u"圃場名"
        field_name4=u"依頼者"
        field_name5=u"作業予定者"
        field_name6=u"作業予定期間"
        field_name7=u"作業状況"
        field_name8=u"作業面積"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),field_name7.encode('"cp932"'),field_name8.encode('"cp932"')])

        features=self.farmland_table.getFeatures()

        msg=True
        for feature in features:
            field1=feature["pkuid"]

            field2 = pyqgis_processing.get_string(feature["district"])
            field3=feature["farmland_code"]
            field4=feature["contract_table_client"]
            if not feature["operation_table_operator_candidate"]:
                field5=u"未設定"
            else:
                field5=feature["operation_table_operator_candidate"]
            if not feature["operation_table_operation_schedule"]:
                field6=u"未設定"
            else:
                field6=feature["operation_table_operation_schedule"]
            if not feature["operation_table_progress"]:
                field7=u"未完了"
            else:
                field7=feature["operation_table_progress"]
            field8=feature["contract_table_operation_area"]
            if self.ui.tabwidget.currentIndex()==0:
                if field6==term and field5==operator:
                    list_csv.append([field1,field2.encode('"cp932"'),field3.encode('"cp932"'),
                                 field4.encode('"cp932"'),field5.encode('"cp932"'),field6.encode('"cp932"'),field7.encode('"cp932"'),field8])
            else:
                if field4==client:
                    list_csv.append([field1,field2.encode('"cp932"'),field3.encode('"cp932"'),
                                 field4.encode('"cp932"'),field5.encode('"cp932"'),field6.encode('"cp932"'),field7.encode('"cp932"'),field8])




        import types

        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])
