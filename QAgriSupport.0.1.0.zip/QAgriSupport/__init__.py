# -*- coding: utf-8 -*-

def classFactory(iface):
  from .main import main
  return main(iface)