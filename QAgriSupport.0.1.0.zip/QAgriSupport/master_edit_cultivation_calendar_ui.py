# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_cultivation_calendar_ui.ui'
#
# Created: Wed Apr 12 14:05:50 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(396, 658)
        self.gridLayout_5 = QtGui.QGridLayout(Dialog)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.cmbbox_crop = QtGui.QComboBox(self.groupBox_2)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.gridLayout.addWidget(self.cmbbox_crop, 0, 0, 1, 1)
        self.gridLayout_5.addWidget(self.groupBox_2, 0, 0, 1, 1)
        self.tablewidget_cultivation = QtGui.QTableWidget(Dialog)
        self.tablewidget_cultivation.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_cultivation.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_cultivation.setObjectName(_fromUtf8("tablewidget_cultivation"))
        self.tablewidget_cultivation.setColumnCount(0)
        self.tablewidget_cultivation.setRowCount(0)
        self.gridLayout_5.addWidget(self.tablewidget_cultivation, 1, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.dateEdit_2 = QtGui.QDateEdit(self.groupBox)
        self.dateEdit_2.setCalendarPopup(True)
        self.dateEdit_2.setObjectName(_fromUtf8("dateEdit_2"))
        self.gridLayout_2.addWidget(self.dateEdit_2, 2, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_2.addWidget(self.label_2, 1, 0, 1, 1)
        self.dateEdit = QtGui.QDateEdit(self.groupBox)
        self.dateEdit.setCalendarPopup(True)
        self.dateEdit.setObjectName(_fromUtf8("dateEdit"))
        self.gridLayout_2.addWidget(self.dateEdit, 1, 1, 1, 1)
        self.lineEdit = QtGui.QLineEdit(self.groupBox)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.gridLayout_2.addWidget(self.lineEdit, 0, 1, 1, 1)
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_2.addWidget(self.label_3, 2, 0, 1, 1)
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_2.addWidget(self.btn_insert, 3, 1, 1, 1)
        self.gridLayout_5.addWidget(self.groupBox, 2, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.label_4 = QtGui.QLabel(self.groupBox_3)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout_3.addWidget(self.label_4, 1, 0, 1, 1)
        self.dateEdit_4 = QtGui.QDateEdit(self.groupBox_3)
        self.dateEdit_4.setCalendarPopup(True)
        self.dateEdit_4.setObjectName(_fromUtf8("dateEdit_4"))
        self.gridLayout_3.addWidget(self.dateEdit_4, 2, 1, 1, 1)
        self.dateEdit_3 = QtGui.QDateEdit(self.groupBox_3)
        self.dateEdit_3.setCalendarPopup(True)
        self.dateEdit_3.setObjectName(_fromUtf8("dateEdit_3"))
        self.gridLayout_3.addWidget(self.dateEdit_3, 1, 1, 1, 1)
        self.label_6 = QtGui.QLabel(self.groupBox_3)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout_3.addWidget(self.label_6, 2, 0, 1, 1)
        self.lineEdit_2 = QtGui.QLineEdit(self.groupBox_3)
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.gridLayout_3.addWidget(self.lineEdit_2, 0, 1, 1, 1)
        self.label_5 = QtGui.QLabel(self.groupBox_3)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout_3.addWidget(self.label_5, 0, 0, 1, 1)
        self.btn_edit = QtGui.QPushButton(self.groupBox_3)
        self.btn_edit.setObjectName(_fromUtf8("btn_edit"))
        self.gridLayout_3.addWidget(self.btn_edit, 3, 1, 1, 1)
        self.gridLayout_5.addWidget(self.groupBox_3, 3, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_4)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_4.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.gridLayout_5.addWidget(self.groupBox_4, 4, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業の登録", None))
        self.groupBox_2.setTitle(_translate("Dialog", "対象作物", None))
        self.groupBox.setTitle(_translate("Dialog", "作業登録", None))
        self.dateEdit_2.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.label_2.setText(_translate("Dialog", "作業開始日", None))
        self.dateEdit.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.label_3.setText(_translate("Dialog", "作業完了日", None))
        self.label.setText(_translate("Dialog", "作業名", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox_3.setTitle(_translate("Dialog", "選択行の編集", None))
        self.label_4.setText(_translate("Dialog", "作業開始日", None))
        self.dateEdit_4.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.dateEdit_3.setDisplayFormat(_translate("Dialog", "MM/dd", None))
        self.label_6.setText(_translate("Dialog", "作業完了日", None))
        self.label_5.setText(_translate("Dialog", "作業名", None))
        self.btn_edit.setText(_translate("Dialog", "変更", None))
        self.groupBox_4.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

