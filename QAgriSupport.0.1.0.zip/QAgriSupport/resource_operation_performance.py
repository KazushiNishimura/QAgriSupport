# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from resource_operation_performance_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y




        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_crop()

        self.ui.spbox_year.setValue(datetime.date.today().year)
        self.ui.spbox_year_2.setValue(datetime.date.today().year)

        #self.connect(self.ui.chkbox_year,SIGNAL("clicked()"),self.check_year)
        self.connect(self.ui.chkbox_crop,SIGNAL("clicked()"),self.check_crop)
        self.connect(self.ui.chkbox_operation,SIGNAL("clicked()"),self.check_operation)
        self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.populate_cmbbox_operation)
        self.ui.gbox_year1.clicked.connect(self.gbox_select1)
        self.ui.gbox_year2.clicked.connect(self.gbox_select2)
        self.connect(self.ui.btn_print,SIGNAL("clicked()"),self.run)




    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop from crop_master group by crop")
        rows=cursor.fetchall()
        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            self.ui.cmbbox_crop.addItem(row[0])

        db.close()
        self.ui.cmbbox_crop.addItem(u"受託")

    def populate_cmbbox_operation(self):
        proc=pyqgis_processing
        if self.ui.cmbbox_crop.currentText()==u"受託":
            db=proc.connect_db()
            #crop=self.ui.cmbbox_crop.currentText()
            cursor=db.cursor()
            cursor.execute("select operation from contract_operation_master")
            rows=cursor.fetchall()
            self.ui.cmbbox_operation.clear()
            for row in rows:
                self.ui.cmbbox_operation.addItem(row[0])
            db.close()
        else:
            db=proc.connect_db()
            crop=self.ui.cmbbox_crop.currentText()
            cursor=db.cursor()
            cursor.execute("select operation from cultivation_calendar_master where crop = ?",(crop,))
            rows=cursor.fetchall()
            self.ui.cmbbox_operation.clear()
            for row in rows:
                self.ui.cmbbox_operation.addItem(row[0])
            db.close()

    def return_mode(self):
        if self.ui.rbtn_operator.isChecked()==True:
            return "operator"
        else:
            return "machine"

    def retur_mode(self):
        if self.ui.gbox_year1.isChecked()==True:
            return "year1"
        else:
            return "year2"

    def check_crop(self):
        if self.ui.chkbox_crop.isChecked()==True:

            self.ui.chkbox_crop.setEnabled(True)
            self.ui.cmbbox_crop.setEnabled(True)
            self.ui.chkbox_operation.setEnabled(True)
            self.ui.cmbbox_operation.setEnabled(False)
        else:

            self.ui.chkbox_crop.setEnabled(True)
            self.ui.cmbbox_crop.setEnabled(False)
            self.ui.chkbox_operation.setEnabled(False)
            self.ui.cmbbox_operation.setEnabled(False)
    def check_operation(self):
        if self.ui.chkbox_operation.isChecked()==True:

            self.ui.chkbox_crop.setEnabled(True)
            self.ui.cmbbox_crop.setEnabled(True)
            self.ui.chkbox_operation.setEnabled(True)
            self.ui.cmbbox_operation.setEnabled(True)
        else:

            self.ui.chkbox_crop.setEnabled(True)
            self.ui.cmbbox_crop.setEnabled(True)
            self.ui.chkbox_operation.setEnabled(True)
            self.ui.cmbbox_operation.setEnabled(False)

    def gbox_select1(self):
        if self.ui.gbox_year1.isChecked()==True:
            self.ui.gbox_year2.setChecked(False)


        else:
            self.ui.gbox_year2.setChecked(True)


    def gbox_select2(self):
        if self.ui.gbox_year2.isChecked()==True:
            self.ui.gbox_year1.setChecked(False)


        else:
            self.ui.gbox_year1.setChecked(True)


    def operation_performance_machine(self):
        year=self.ui.spbox_year.value()

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/要員・機械稼動実績"):
            os.mkdir(path+u"/要員・機械稼動実績")
        path+=u"/要員・機械稼動実績"

        filename_all= path + "/"+"%s.csv"  % (str(year)+  u'_機械稼動実績詳細')
        table_csv=open(filename_all, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1=u"作業機"
        field_name2=u"年度"
        field_name3=u"作物"
        field_name4=u"作業"
        field_name5=u"使用者"
        field_name6=u"稼動面積"
        field_name7=u"圃場名"
        field_name8=u"作業日"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),
                         field_name7.encode('"cp932"'),field_name8.encode('"cp932"')])

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()


        sql_string=self.return_sql_machine_all_string()



        cursor.execute(sql_string)
        rows=cursor.fetchall()
        print len(rows)
        list_client=[]
        for row in rows:
            field1=row[0].encode('"cp932"')
            field2=row[1]
            field3=row[2].encode('"cp932"')
            field4=row[3].encode('"cp932"')
            field5=row[4].encode('"cp932"')
            field6=row[5]
            try:
                field7=row[6].encode('"cp932"')
            except:
                field7=None
            try:
                field8=row[7].encode('"cp932"')
            except:
                field8=None
            list_csv.append([field1,field2,field3,field4,field5,field6,field7,field8])
            list_client.append(row[0])

        dataWriter.writerows(list_csv)
        table_csv.close()


        filename_sum= path + "/"+"%s.csv"  % (str(year)+  u'_機械稼動実績集計')
        table_csv=open(filename_sum, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1=u"作業機"
        field_name2=u"年度"
        field_name3=u"作物"
        field_name4=u"作業"
        field_name5=u"使用者"
        field_name6=u"稼動面積"


        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"')])

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()


        sql_string=self.return_sql_machine_sum_string() +"""
         group by machine_use_table.machine,machine_use_table.year,machine_use_table.crop, machine_use_table.operation,machine_use_table.operator_main"""



        cursor.execute(sql_string)
        rows=cursor.fetchall()
        print len(rows)
        list_client=[]
        for row in rows:
            field1=row[0].encode('"cp932"')
            field2=row[1]
            field3=row[2].encode('"cp932"')
            field4=row[3].encode('"cp932"')
            field5=row[4].encode('"cp932"')
            field6=row[5]

            list_csv.append([field1,field2,field3,field4,field5,field6])
            list_client.append(row[0])

        dataWriter.writerows(list_csv)
        table_csv.close()
        #集計結果は立ち上げないことにした
#         if sys.platform == "win32":
#             os.startfile(filename_sum)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename_sum])

        msg=u"""集計結果及び個票を%sに出力しました """ %(path)
        pyqgis_processing.show_msgbox(msg)

    def operation_performance_operator(self):
        year=self.ui.spbox_year.value()

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/要員・機械稼動実績"):
            os.mkdir(path+u"/要員・機械稼動実績")
        path+=u"/要員・機械稼動実績"

        filename_all= path + "/"+"%s.csv"  % (str(year)+  u'_要員稼動実績詳細')
        table_csv=open(filename_all, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1=u"作業者"
        field_name2=u"年度"
        field_name3=u"作物"
        field_name4=u"作業"
        field_name5=u"区分"
        field_name6=u"稼動面積"
        field_name7=u"圃場名"
        field_name8=u"作業日"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),
                         field_name7.encode('"cp932"'),field_name8.encode('"cp932"')])

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()


        sql_string=self.return_sql_operator_all_string()



        cursor.execute(sql_string)
        rows=cursor.fetchall()
        print len(rows)
        list_client=[]
        for row in rows:
            field1=row[0].encode('"cp932"')
            field2=row[1]
            field3=row[2].encode('"cp932"')
            field4=row[3].encode('"cp932"')
            field5=row[4].encode('"cp932"')
            field6=row[5]
            try:
                field7=row[6].encode('"cp932"')
            except:
                field7=None
            try:
                field8=row[7].encode('"cp932"')
            except:
                field8=None
            list_csv.append([field1,field2,field3,field4,field5,field6,field7,field8])
            list_client.append(row[0])

        dataWriter.writerows(list_csv)
        table_csv.close()


        filename_sum= path + "/"+"%s.csv"  % (str(year)+  u'_要員稼動実績集計')
        table_csv=open(filename_sum, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1=u"作業者"
        field_name2=u"年度"
        field_name3=u"作物"
        field_name4=u"作業"
        field_name5=u"区分"
        field_name6=u"稼動面積"


        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"')])

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()


        sql_string=self.return_sql_operator_sum_string() +"""
         group by operator_record_table.operator,operator_record_table.year,operator_record_table.crop, operator_record_table.operation,operator_record_table.operator_class"""



        cursor.execute(sql_string)
        rows=cursor.fetchall()
        print len(rows)
        list_client=[]
        for row in rows:
            field1=row[0].encode('"cp932"')
            field2=row[1]
            field3=row[2].encode('"cp932"')
            field4=row[3].encode('"cp932"')
            field5=row[4].encode('"cp932"')
            field6=row[5]

            list_csv.append([field1,field2,field3,field4,field5,field6])
            list_client.append(row[0])

        dataWriter.writerows(list_csv)
        table_csv.close()
        #集計結果は立ち上げないことに
#         if sys.platform == "win32":
#             os.startfile(filename_sum)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename_sum])

        msg=u"""集計結果及び個票を%sに出力しました """ %(path)
        pyqgis_processing.show_msgbox(msg)

    def create_sql_string_operator_base_all(self):
        sql_string=u"""select operator_record_table.operator,operator_record_table.year,operator_record_table.crop, operator_record_table.operation,operator_record_table.operator_class ,
        case
            when operator_record_table.crop= '受託' then contract_table.operation_area
            else cropping_table.crop_area
        end,
        operation_table.farmland_code,
        operation_table.operation_day
        from  (((operator_record_table
        left join
                    operation_table on operator_record_table.year=operation_table.year and
                            operator_record_table.crop=operation_table.crop and
                            operator_record_table.operator_main=operation_table.operator and
                            operator_record_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where operator_record_table.operation_day like '%""" +str(self.ui.spbox_year.value())+ "%' "
        return sql_string

    def create_sql_string_operator_base_sum(self):
        sql_string=u"""select operator_record_table.operator,operator_record_table.year,operator_record_table.crop, operator_record_table.operation,operator_record_table.operator_class ,
        case
            when operator_record_table.crop= '受託' then total(contract_table.operation_area)
            else total(cropping_table.crop_area)
        end
        from  (((operator_record_table
        left join
                    operation_table on operator_record_table.year=operation_table.year and
                            operator_record_table.crop=operation_table.crop and
                            operator_record_table.operator_main=operation_table.operator and
                            operator_record_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where operator_record_table.operation_day like '%""" +str(self.ui.spbox_year.value())+ "%' "


        return sql_string

    def create_sql_string_operator_year_all(self):
        sql_string=u"""select operator_record_table.operator,operator_record_table.year,operator_record_table.crop, operator_record_table.operation,operator_record_table.operator_class ,
        case
            when operator_record_table.crop= '受託' then contract_table.operation_area
            else cropping_table.crop_area
        end,
        operation_table.farmland_code,
        operation_table.operation_day
        from  (((operator_record_table
        left join
                    operation_table on operator_record_table.year=operation_table.year and
                            operator_record_table.crop=operation_table.crop and
                            operator_record_table.operator_main=operation_table.operator and
                            operator_record_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where operator_record_table.year=%d """  %(self.ui.spbox_year_2.value())
        return sql_string

    def create_sql_string_operator_year_sum(self):
        sql_string=u"""select operator_record_table.operator,operator_record_table.year,operator_record_table.crop, operator_record_table.operation,operator_record_table.operator_class ,
        case
            when operator_record_table.crop= '受託' then total(contract_table.operation_area)
            else total(cropping_table.crop_area)
        end
        from  (((operator_record_table
        left join
                    operation_table on operator_record_table.year=operation_table.year and
                            operator_record_table.crop=operation_table.crop and
                            operator_record_table.operator_main=operation_table.operator and
                            operator_record_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where operator_record_table.year=%d """  %(self.ui.spbox_year_2.value())

        return sql_string

    def create_sql_string_operator_year_crop_all(self):
        sql_string=self.create_sql_string_operator_year_all()+ """  and operator_record_table.crop='%s' """  %(self.ui.cmbbox_crop.currentText())
        return sql_string

    def create_sql_string_operator_year_crop_sum(self):
        sql_string=self.create_sql_string_operator_year_sum()+ """  and operator_record_table.crop='%s' """  %(self.ui.cmbbox_crop.currentText())
        return sql_string

    def create_sql_string_operator_year_crop_operation_all(self):
        sql_string=self.create_sql_string_operator_year_crop_all()+ """  and operator_record_table.operation='%s' """  %(self.ui.cmbbox_operation.currentText())
        return sql_string

    def create_sql_string_operator_year_crop_operation_sum(self):
        sql_string=self.create_sql_string_operator_year_crop_sum()+ """  and operator_record_table.operation='%s' """  %(self.ui.cmbbox_operation.currentText())
        return sql_string
    def return_sql_operator_all_string(self):
        if self.ui.gbox_year1.isChecked()==True:
            return self.create_sql_string_operator_base_all()
        else:
            if self.ui.chkbox_crop.isChecked()==True:
                if self.ui.chkbox_operation.isChecked()==True:
                    return self.create_sql_string_operator_year_crop_operation_all()
                else:
                    return self.create_sql_string_operator_year_crop_all()
            else:
                return self.create_sql_string_operator_year_all()

    def return_sql_operator_sum_string(self):
        if self.ui.gbox_year1.isChecked()==True:
            return self.create_sql_string_operator_base_sum()
        else:
            if self.ui.chkbox_crop.isChecked()==True:
                if self.ui.chkbox_operation.isChecked()==True:
                    return self.create_sql_string_operator_year_crop_operation_sum()
                else:
                    return self.create_sql_string_operator_year_crop_sum()
            else:
                return self.create_sql_string_operator_year_sum()


    #ここから機械

    def create_sql_string_machine_base_all(self):
        sql_string=u"""select machine_use_table.machine,machine_use_table.year,machine_use_table.crop, machine_use_table.operation,machine_use_table.operator_main ,
        case
            when machine_use_table.crop= '受託' then contract_table.operation_area
            else cropping_table.crop_area
        end,
        operation_table.farmland_code,
        operation_table.operation_day
        from  (((machine_use_table
        left join
                    operation_table on machine_use_table.year=operation_table.year and
                            machine_use_table.crop=operation_table.crop and
                            machine_use_table.operator_main=operation_table.operator and
                            machine_use_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where machine_use_table.operation_day like '%""" +str(self.ui.spbox_year.value())+ "%' "
        return sql_string

    def create_sql_string_machine_base_sum(self):
        sql_string=u"""select machine_use_table.machine,machine_use_table.year,machine_use_table.crop, machine_use_table.operation,machine_use_table.operator_main ,
        case
            when machine_use_table.crop= '受託' then total(contract_table.operation_area)
            else total(cropping_table.crop_area)
        end
        from  (((machine_use_table
        left join
                    operation_table on machine_use_table.year=operation_table.year and
                            machine_use_table.crop=operation_table.crop and
                            machine_use_table.operator_main=operation_table.operator and
                            machine_use_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where machine_use_table.operation_day like '%""" +str(self.ui.spbox_year.value())+ "%' "


        return sql_string

    def create_sql_string_machine_year_all(self):
        sql_string=u"""select machine_use_table.machine,machine_use_table.year,machine_use_table.crop, machine_use_table.operation,machine_use_table.operator_main ,
        case
            when machine_use_table.crop= '受託' then contract_table.operation_area
            else cropping_table.crop_area
        end,
        operation_table.farmland_code,
        operation_table.operation_day
        from  (((machine_use_table
        left join
                    operation_table on machine_use_table.year=operation_table.year and
                            machine_use_table.crop=operation_table.crop and
                            machine_use_table.operator_main=operation_table.operator and
                            machine_use_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where machine_use_table.year=%d """  %(self.ui.spbox_year_2.value())
        return sql_string

    def create_sql_string_machine_year_sum(self):
        sql_string=u"""select machine_use_table.machine,machine_use_table.year,machine_use_table.crop, machine_use_table.operation,machine_use_table.operator_main ,
        case
            when machine_use_table.crop= '受託' then total(contract_table.operation_area)
            else total(cropping_table.crop_area)
        end
        from  (((machine_use_table
        left join
                    operation_table on machine_use_table.year=operation_table.year and
                            machine_use_table.crop=operation_table.crop and
                            machine_use_table.operator_main=operation_table.operator and
                            machine_use_table.operation_day=operation_table.operation_day)
        left join
                    cropping_table  on cropping_table.year=operation_table.year and
                                    cropping_table.crop=operation_table.crop and
                                    cropping_table.farmland_code=operation_table.farmland_code)
        left join
                    contract_table  on contract_table.year=operation_table.year and
                            contract_table.operation=operation_table.operation and
                            contract_table.farmland_code=operation_table.farmland_code)
        where machine_use_table.year=%d """  %(self.ui.spbox_year_2.value())

        return sql_string

    def create_sql_string_machine_year_crop_all(self):
        sql_string=self.create_sql_string_machine_year_all()+ """  and machine_use_table.crop='%s' """  %(self.ui.cmbbox_crop.currentText())
        return sql_string

    def create_sql_string_machine_year_crop_sum(self):
        sql_string=self.create_sql_string_machine_year_sum()+ """  and machine_use_table.crop='%s' """  %(self.ui.cmbbox_crop.currentText())
        return sql_string

    def create_sql_string_machine_year_crop_operation_all(self):
        sql_string=self.create_sql_string_machine_year_crop_all()+ """  and machine_use_table.operation='%s' """  %(self.ui.cmbbox_operation.currentText())
        return sql_string

    def create_sql_string_machine_year_crop_operation_sum(self):
        sql_string=self.create_sql_string_machine_year_crop_sum()+ """  and machine_use_table.operation='%s' """  %(self.ui.cmbbox_operation.currentText())
        return sql_string
    def return_sql_machine_all_string(self):
        if self.ui.gbox_year1.isChecked()==True:
            return self.create_sql_string_machine_base_all()
        else:
            if self.ui.chkbox_crop.isChecked()==True:
                if self.ui.chkbox_operation.isChecked()==True:
                    return self.create_sql_string_machine_year_crop_operation_all()
                else:
                    return self.create_sql_string_machine_year_crop_all()
            else:
                return self.create_sql_string_machine_year_all()

    def return_sql_machine_sum_string(self):
        if self.ui.gbox_year1.isChecked()==True:
            return self.create_sql_string_machine_base_sum()
        else:
            if self.ui.chkbox_crop.isChecked()==True:
                if self.ui.chkbox_operation.isChecked()==True:
                    return self.create_sql_string_machine_year_crop_operation_sum()
                else:
                    return self.create_sql_string_machine_year_crop_sum()
            else:
                return self.create_sql_string_machine_year_sum()


    def run(self):
        if self.ui.rbtn_operator.isChecked()==True:
            self.operation_performance_operator()
        else:
            self.operation_performance_machine()
