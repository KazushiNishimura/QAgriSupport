# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from webview_operation_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
from time import sleep
import os, sys, subprocess

from PyQt4.QtWebKit import  *

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,year,crop,operation,term,operator_candidate):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=year
        self.crop=crop
        self.operation=operation
        self.term=term
        self.operator_candidate=operator_candidate
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing

        QWebSettings.clearMemoryCaches()

        if os.path.exists(proc.get_prj_path()+"\mapimage\map.jpg"):
            os.remove(proc.get_prj_path()+"\mapimage\map.jpg")

        if os.path.exists(proc.get_prj_path()+"\mapimage\directions.pdf"):
            os.remove(proc.get_prj_path()+"\mapimage\directions.pdf")

        self.view_map()

        self.connect(self.ui.btn_pdf,SIGNAL("clicked()"),self.topdf)



    def view_map(self):
        proc=pyqgis_processing

#         if os.path.exists(proc.get_prj_path()+"\mapimage\map.jpg"):
#             os.remove(proc.get_prj_path()+"\mapimage\map.jpg")
        #sleep(5)

        db=proc.connect_db()
        #対象圃場一覧の取得
        cursor=db.cursor()
        query_string='select operation_table.farmland_code, cropping_table.crop_area,operation_table.operator,operation_table.operation_day,operation_table.progress from operation_table inner join cropping_table on operation_table.farmland_code = cropping_table.farmland_code \
            where operation_table.year=? and operation_table.crop=? and operation_table.operation=? and operation_table.operation_schedule=? and operation_table.operator_candidate=? \
            and cropping_table.year=? and cropping_table.crop=?'
        cursor.execute(query_string,(self.year,self.crop,self.operation,self.term,self.operator_candidate,self.year,self.crop))
        rows=cursor.fetchall()
        #print rows
        #使用可能資材一覧の取得
        cursor2=db.cursor()
        query_string2='select material from material_master \
            where crop=? '
        cursor2.execute(query_string2,(self.crop,))
        rows2=cursor2.fetchall()


        proc.save_map_image()
        #sleep(5)
        #myWV=self.ui.webView(None)
        html=u"""<html><head>

        <style>
            .cssHeaderCell {

                font-size: 16px;

            }
            .cssTableCell {
                font-size: 20px;

            }

        </style>

        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
         <script type="text/javascript">
         google.load("visualization", "1", {packages:["table"]});
         google.setOnLoadCallback(drawChart);
         function drawChart(){
        var data=google.visualization.arrayToDataTable([
        ["%s","%s","%s","%s","%s"],""" % (u'圃場名',u'作付面積(m2)',u'作業実施者',u'作業実施日',u'作業状況')
        for row in rows:
            #print row[0]
            if row[4]==u"完了":
                html+='["%s","%s","%s","%s","%s"],' % (row[0],str(round(row[1],1)),row[2],row[3],row[4])
            else:
                html+='["%s","%s","%s","%s","%s"],' % (row[0],str(round(row[1],1)),"","","")
        html+=u"""]);
        var cssClassNames = {
                    'headerCell': 'cssHeaderCell',
                    'tableCell': 'cssTableCell'
                };
        var options ={
        title: "圃場一覧",
        width:800,
        cssClassNames: cssClassNames
        };
        var chart =new google.visualization.Table(
        document.getElementById("table1"));
        chart.draw(data,options);}</script>


        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
         <script type="text/javascript">
         google.load("visualization", "1", {packages:["table"]});
         google.setOnLoadCallback(drawChart);
        function drawChart(){
        var data=google.visualization.arrayToDataTable([
        ["%s"],""" % (u'資材名')
        for row in rows2:
            #print row[0]
            html+='["%s"],' % (row[0])
        html+=u"""]);
        var cssClassNames = {
                    'headerCell': 'cssHeaderCell',
                    'tableCell': 'cssTableCell'
                };
        var options ={
        title: "使用可能資材",
        width:800,
        cssClassNames: cssClassNames
        };
        var chart =new google.visualization.Table(
        document.getElementById("table2"));
        chart.draw(data,options);}</script>

         </script></head>
         <body>
         <h1><img src="%s"  """  % (proc.get_prj_path() +"/mapimage/map.jpg")
        html+=u"""width="100%" ></h1>"""
        html+=u""" <table border="3" width="100%" ><tr>
        <td width="50%" height="250" valign="top">作業者：</td><td width="50%" height="250" valign="top">使用機材：</td>
        </tr></table>
        <table border="3" width="100%"><tr>
        <td width="50%" height="250" valign="top">使用資材：</td><td width="50%" height="250" valign="top">備考：</td>
        </tr></table>
        <h2>　</h2>
        <h2>　</h2>
        <h2>　</h2>
        <h2>　</h2>
        <h2>圃場一覧</h2>
        <div id="table1"  ></div>
        <h2>使用可能資材一覧</h2>
        <div id="table2"  ></div>


        </body></html>"""
        self.ui.webView.setHtml(html)
        f = open(proc.get_prj_path() +"/mapimage/directions.html", 'w') # 書き込みモードで開く
        f.write(html.encode('utf-8')) # 引数の文字列をファイルに書き込む
        f.close() # ファイルを閉じる
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"/mapimage/directions.html")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"/mapimage/directions.html"])

        #view表示の不具合確認用にhtmlをコンソールに出力
        #print html


    def topdf(self):
        proc=pyqgis_processing

#         if os.path.exists(proc.get_prj_path()+"\mapimage\directions.pdf"):
#             os.remove(proc.get_prj_path()+"\mapimage\directions.pdf")
        #sleep(5)
        printer = QPrinter()
        printer.setPageSize(QPrinter.A4)
        printer.setColorMode(QPrinter.Color)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName((proc.get_prj_path() +"\mapimage\directions.pdf"))
        self.ui.webView.page().mainFrame().print_(printer)

        #os.startfile(proc.get_prj_path() +"\mapimage\directions.pdf")
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"\mapimage\directions.pdf")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"\mapimage\directions.pdf"])
