# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from webview_report_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
from time import sleep
import os, sys, subprocess

from PyQt4.QtWebKit import  *

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,year,crop,operation):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=year
        self.crop=crop
        self.operation=operation
        #self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing

        QWebSettings.clearMemoryCaches()



        if os.path.exists(proc.get_prj_path()+"\mapimage\directions.pdf"):
            os.remove(proc.get_prj_path()+"\mapimage\directions.pdf")

        self.view_report()

        self.connect(self.ui.btn_print_report_plan,SIGNAL("clicked()"),self.topdf)



    def view_report(self):
        proc=pyqgis_processing

#         if os.path.exists(proc.get_prj_path()+"\mapimage\map.jpg"):
#             os.remove(proc.get_prj_path()+"\mapimage\map.jpg")


        db=proc.connect_db()
        #対象圃場一覧の取得
        cursor=db.cursor()
        query_string='select operation_table.farmland_code, cropping_table.crop_area,operation_table.operation_schedule,operation_table.operator_candidate from operation_table inner join cropping_table on operation_table.farmland_code = cropping_table.farmland_code \
            where operation_table.year=? and operation_table.crop=? and operation_table.operation=? \
            and cropping_table.year=? and cropping_table.crop=?'
        cursor.execute(query_string,(self.year,self.crop,self.operation,self.year,self.crop))
        rows=cursor.fetchall()
        #print rows

        html="""<html><head>

        <style>
            .cssHeaderCell {

                font-size: 16px;

            }
            .cssTableCell {
                font-size: 20px;

            }

        </style>

        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
         <script type="text/javascript">
         google.load("visualization", "1", {packages:["table"]});
         google.setOnLoadCallback(drawChart);
         function drawChart(){
        var data=google.visualization.arrayToDataTable([
        ["%s","%s","%s","%s"],""" % (u'圃場名',u'作付面積(m2)',u'作業予定期間',u'作業予定者')
        for row in rows:
            #print row[0]
            html+='["%s","%s","%s","%s"],' % (row[0],str(round(row[1],1)),row[2],row[3])

        html+=u"""]);
        var cssClassNames = {
                    'headerCell': 'cssHeaderCell',
                    'tableCell': 'cssTableCell'
                };
        var options ={
        title: "圃場一覧",
        width:800,
        height:4000,
        cssClassNames: cssClassNames
        };
        var chart =new google.visualization.Table(
        document.getElementById("table1"));
        chart.draw(data,options);}</script>
         </script></head>
         <body>
        <h2>圃場一覧</h2>
        <div id="table1"  ></div>
        </body></html>"""
        self.ui.webView.setHtml(html)


    def topdf(self):
        proc=pyqgis_processing

#         if os.path.exists(proc.get_prj_path()+"\mapimage\directions.pdf"):
#             os.remove(proc.get_prj_path()+"\mapimage\directions.pdf")
        #sleep(5)
        printer = QPrinter()
        printer.setPageSize(QPrinter.A4)
        printer.setColorMode(QPrinter.Color)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName((proc.get_prj_path() +"\mapimage\directions.pdf"))
        self.ui.webView.page().mainFrame().print_(printer)

        #os.startfile(proc.get_prj_path() +"\mapimage\directions.pdf")
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"\mapimage\directions.pdf")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"\mapimage\directions.pdf"])
