# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic
import os


# リソース読み込み
try:
  from . import resource
except ImportError:
  pass



class main:

  def __init__(self, iface):
    self.iface = iface

  # QGISのメニューに表示するときに呼ばれるやつ
  def initGui(self):
    # 小メニューを作る
    self.action1 = QAction(QIcon(":/icon/marubatu32.png"), u"ファイルを開く", self.iface.mainWindow())
    self.action1.setObjectName("sample1")
    self.action2 = QAction(u"ダイアログを開く", self.iface.mainWindow())
    self.action2.setObjectName("sample2")
    self.action3=QAction(u"生産管理システム",self.iface.mainWindow())
    self.action3.setObjectName("open_dock")
    self.action4=QAction(u"筆ポリゴンインポーター",self.iface.mainWindow())
    self.action4.setObjectName("open_importer")
    self.action_gpx_renderer=QAction(u"gpxのレンダリング",self.iface.mainWindow())
    self.action_gpx_renderer.setObjectName("gpx_renderer")
    self.start_land_management=QAction(u"地域営農計画システム",self.iface.mainWindow())
    self.start_land_management.setObjectName("start_land_management")
    # 大メニューを作る
    self.menu = QMenu(self.iface.mainWindow())
    self.menu.setObjectName("daradara")
    self.menu.setTitle("QAgriSupport")
    #self.menu.addAction(self.action1)
    #self.menu.addAction(self.action2)
    self.menu.addAction(self.action3)
    self.menu.addAction(self.action4)
    #self.menu.addAction(self.action_gpx_renderer)


    # 大メニューをメニューバーに挿入する
    menuBar = self.iface.mainWindow().menuBar()
    menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)

    # 小メニューを押したとき実行するよう、トリガーをセット
    QObject.connect(self.action3,SIGNAL("triggered()"),self.run3)
    QObject.connect(self.action4,SIGNAL("triggered()"),self.open_importer)
    QObject.connect(self.action_gpx_renderer,SIGNAL("triggered()"),self.run_gpx)



  def unload(self):
    self.menu.deleteLater()

  def run3(self):
    #path = os.path.dirname(os.path.abspath(__file__))
    #self.dock = uic.loadUi(os.path.join(path, "dockwidgetui.ui"))
    from dockwidget import DockWidget
    self.doc=DockWidget(self.iface)
    self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.doc)
    #self.dlg=DockWidget(self.iface)
    #self.dlg.show()

  def run_gpx(self):
      from gpx_renderer import Dialog
      self.dlg=Dialog(self.iface)
      self.dlg.show()
      self.dlg.exec_()

  def open_importer(self):
    from poly_importer import Dialog
    self.dlg = Dialog(self.iface)

    # 表示
    self.dlg.show()

    # 実行
    self.dlg.exec_()





