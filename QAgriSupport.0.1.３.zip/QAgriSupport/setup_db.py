# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from renderer_contract_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv
#from resource import *
import shutil




def copy_from_resource(crs):
    if sys.platform == "win32":
        if not os.path.exists("c:/gisdata"):
            os.mkdir("c:/gisdata")
    else:
        if not os.path.exists(os.path.expanduser('~/gisdata')):
            os.mkdir(os.path.expanduser('~/gisdata'))

    prj_file=os.path.expanduser('~/.qgis2/python/plugins/QAgriSupport/resource%s/agrimanagement.qgs')  %("/"+str(crs))
    db_file=os.path.expanduser('~/.qgis2/python/plugins/QAgriSupport/resource%s/management_db.sqlite') %("/"+str(crs))
    #land_list_file=os.path.expanduser(u'~/.qgis2/python/plugins/QAgriSupport/resource%s/農地台帳.csv') %("/"+str(crs))
    #mail_list_file=os.path.expanduser(u'~/.qgis2/python/plugins/QAgriSupport/resource%s/メールリスト.csv') %("/"+str(crs))
    if sys.platform == "win32":
        shutil.copy(prj_file, "c:/gisdata/agrimanagement.qgs")
        shutil.copy(db_file, "c:/gisdata/management_db.sqlite")
        #shutil.copy(land_list_file,u"c:/gisdata/農地台帳.csv")
        land_list_file= u"c:/gisdata/農地台帳.csv"

        #shutil.copy(land_list_file,u"c:/gisdata/メールリスト.csv")
        mail_list_file=u"c:/gisdata/メールリスト.csv"

    else:
        prj_to=os.path.expanduser('~/gisdata/agrimanagement.qgs')
        shutil.copy(prj_file, prj_to)
        db_to=os.path.expanduser('~/gisdata/management_db.sqlite')
        shutil.copy(db_file, db_to)
        land_list_file=os.path.expanduser(u'~/gisdata/農地台帳.csv')
        #shutil.copy(land_list_file,land_list_to)
        mail_list_file=os.path.expanduser(u'~/gisdata/メールリスト.csv')
        #shutil.copy(mail_list_file,mail_list_to)

    table_csv=open(land_list_file, 'w')
    dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
    list_csv=[]
    field_name1=u"エリア"
    field_name2=u"呼名"
    field_name3=u"地名地番"
    field_name4=u"台帳面積"
    field_name5=u"実利用面積"
    field_name6=u"地権者"

    list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                     field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"')])
    dataWriter.writerows(list_csv)
    table_csv.close()

    table_csv=open(mail_list_file, 'w')
    dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
    list_csv=[]
    field_name1=u"名前"
    field_name2=u"アドレス"
    field_name3=u"種別"


    list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"')])
    dataWriter.writerows(list_csv)
    table_csv.close()

    os.mkdir("c:/gisdata/mapimage")


def create_tables(crs):
#     #まずは空のメモリーレイヤを作成→没
#     crs = "EPSG:"+str(return_epsg(crs))#toWkt()
#     memlayer=QgsVectorLayer("Polygon?crs=" + crs,'farmland_table','memory')
#     pr = memlayer.dataProvider()
#     pr.addAttributes([QgsField("pkuid", QVariant.LongLong),
#                     QgsField("district", QVariant.String),
#                     QgsField("subdistrict",  QVariant.String),
#                     QgsField("farmland_code", QVariant.String),
#                     QgsField("kind", QVariant.String),
#                     QgsField("centroid", QVariant.String),
#                     QgsField("vertex", QVariant.String),
#                     QgsField("land_area", QVariant.Double)])
#     memlayer.updateFields()
#
#     #spatialiteにexport"
#     if sys.platform == "win32":
#         db_path="c:/gisdata/farmland_table.sqlite"
#     else:
#         db_path=os.path.expanduser('~/gisdata/farmland_table.sqlite')
#
#     QgsVectorFileWriter.writeAsVectorFormat(memlayer,db_path,"utf-8", None, "SQLite", False, None ,["SPATIALITE=YES",])
#
#     #db名をリネーム
#     if sys.platform == "win32":
#         os.rename("c:/gisdata/farmland_table.sqlite", "c:/gisdata/management_db.sqlite")
#     else:
#         db_path=os.path.expanduser('~/gisdata/farmland_table.sqlite')
#         db_rename=os.path.expanduser('~/gisdata/management_db.sqlite')
#         os.rename(db_path,db_rename)


    from pyspatialite import dbapi2 as db
    if sys.platform == "win32":
        db_path="c:/gisdata/management_db.sqlite"
    else:
        db_path=os.path.expanduser('~/gisdata/management_db.sqlite')

    conn = db.connect(db_path)

    #圃場図テーブル
    sql_string = """CREATE TABLE  farmland_table (
                    pkuid INTEGER NOT NULL PRIMARY KEY,
                    district text,
                    subdistrict  text,
                    farmland_code  text ,
                    kind text,
                    centroid  text,
                    vertex text,
                    land_area FLOAT)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)
    sql_string ="""SELECT AddGeometryColumn('farmland_table','geometry', %d, 'POLYGON', 'XY')""" %(return_epsg(crs))
    cursor.execute(sql_string)
    #作付台帳（cropping_table）
    sql_string = """CREATE TABLE  cropping_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    farmland_code  text NOT NULL,
                    crop  text not null,
                    variety  text not null,
                    crop_area  real)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #受託台帳（contract_table）
    sql_string = """CREATE TABLE  contract_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    farmland_code  text NOT NULL,
                    operation text,
                    client  text,
                    operation_area real )"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #資材発注・納品台帳（material_order_table）
    sql_string = """CREATE TABLE  material_order_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    material  text  not null,
                    order_day  text not null,
                    order_amount   real not null,
                    deliverd_day text )"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作業台帳（operation_table）
    sql_string = """CREATE TABLE  operation_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    farmland_code text not null,
                    crop text not null,
                    operation  text not null,
                    operator_candidate  text not null,
                    operation_schedule  text not null,
                    schedule_start  text  not null,
                    schedule_end  text  not null,
                    operator   text ,
                    operation_day  text ,
                    progress  text)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作業者実績台帳（operator_record_table）
    sql_string = """CREATE TABLE  operator_record_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    operator_main  text not null,
                    crop text not null,
                    operation  text not null,
                    operator text not null,
                    operator_class text not null,
                    operation_day  text not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #機材使用台帳（machine_use_table）
    sql_string = """CREATE TABLE  machine_use_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    operator_main  text not null,
                    crop text not null,
                    operation  text not null,
                    machine text not null,
                    operation_day text not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #資材使用台帳（material_use_table）
    sql_string = """CREATE TABLE  material_use_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    operator_main  text not null,
                    crop text not null,
                    operation  text not null,
                    operation_day text not null,
                    material text not null,
                    material_use_amount  real not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #製品台帳（product_table）
    sql_string = """CREATE TABLE  product_table (
                    id  integer NOT NULL PRIMARY KEY,
                    year integer NOT NULL,
                    farmland_code  text not null,
                    crop  text not null,
                    yield  real ,
                    average_weight real,
                    average_moisture real ,
                    growth_stage text ,
                    weed  text,
                    cutting_length integer,
                    processing text,
                    wrapping_count integer,
                    stock_yard text ,
                    customor_candidate text,
                    deliver_day  text)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作業日報台帳（report_table）
    sql_string = """CREATE TABLE  report_table (
                    id  integer NOT NULL PRIMARY KEY,
                    operation_day text,
                    crop  text,
                    operation  text,
                    operator  text)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作物マスタ（crop_master）
    sql_string = """CREATE TABLE  crop_master (
                    id  integer NOT NULL PRIMARY KEY,
                    crop text not null,
                    variety  text )"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作業暦マスタ（cultivation_calendar_master）
    sql_string = """CREATE TABLE  cultivation_calendar_master (
                    id  integer NOT NULL PRIMARY KEY,
                    crop text not null,
                    operation text not null,
                    term_start text not null,
                    term_end   text not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #受託作業マスタ（contract_operation_master）
    sql_string = """CREATE TABLE  contract_operation_master (
                    id  integer NOT NULL PRIMARY KEY,
                    operation text not null,
                    term_start text not null,
                    term_end text not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作業者マスタ（operator_master）
    sql_string = """CREATE TABLE  operator_master (
                    id  integer NOT NULL PRIMARY KEY,
                    operator text  not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #受託者マスタ（client_master）
    sql_string = """CREATE TABLE  client_master (
                    id  integer NOT NULL PRIMARY KEY,
                    client text  not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #資材マスタ（material_master）
    sql_string = """CREATE TABLE  material_master (
                    id  integer NOT NULL PRIMARY KEY,
                    material text not null,
                    crop  text not null,
                    material_unit text not null,
                    package_unit  text not null,
                    package_amount real not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #作業機マスタ（machine_master）
    sql_string = """CREATE TABLE  machine_master (
                    id  integer NOT NULL PRIMARY KEY,
                    machine text not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #保管場所マスタ（stock_yard_master）
    sql_string = """CREATE TABLE  stock_yard_master (
                    id  integer NOT NULL PRIMARY KEY,
                    stock_yard text  not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #販売先マスタ（customor_master）
    sql_string = """CREATE TABLE  customor_master (
                    id  integer NOT NULL PRIMARY KEY,
                    customor text  not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #生育マスタ（growth_stage_master）
    sql_string = """CREATE TABLE  growth_stage_master (
                    id  integer NOT NULL PRIMARY KEY,
                    growth_stage text  not null)"""
    cursor=conn.cursor()
    cursor.execute(sql_string)

    #qrコードジェネレーター(qrcode_generator)

def select_crs(dlg):
    p_iface=iface
    from selection_crs import Dialog
    pdlg=Dialog(dlg)
    pdlg.show()
    pdlg.exec_()

def return_epsg(i):
    if i==1:
        epsg=6669
    elif i==2:
        epsg=6670
    elif i==3:
        epsg=6671
    elif i==4:
        epsg=6672
    elif i==5:
        epsg=6673
    elif i==6:
        epsg=6674
    elif i==7:
        epsg=6675
    elif i==8:
        epsg=6676
    elif i==9:
        epsg=6677
    elif i==10:
        epsg=6678
    elif i==11:
        epsg=6679
    elif i==12:
        epsg=6680
    elif i==13:
        epsg=6681
    elif i==14:
        epsg=6682
    elif i==15:
        epsg=6683
    elif i==16:
        epsg=6684
    elif i==17:
        epsg=6685
    elif i==18:
        epsg=6686
    elif i==19:
        epsg=6687
    else:
        print i
    return epsg










