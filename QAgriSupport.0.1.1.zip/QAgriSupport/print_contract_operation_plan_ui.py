# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'print_contract_operation_plan_ui.ui'
#
# Created: Thu May 25 11:09:54 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(408, 249)
        self.gridLayout_2 = QtGui.QGridLayout(Dialog)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.cmbbox_operate = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout_3.addWidget(self.cmbbox_operate, 0, 1, 1, 1)
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_3.addWidget(self.label, 0, 0, 1, 1)
        self.gridLayout_2.addWidget(self.groupBox, 0, 0, 1, 1)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.gridLayout_2.addWidget(self.btn_export_csv, 3, 0, 1, 1)
        self.tabwidget = QtGui.QTabWidget(Dialog)
        self.tabwidget.setObjectName(_fromUtf8("tabwidget"))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.formLayout = QtGui.QFormLayout(self.tab)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.label_2 = QtGui.QLabel(self.tab)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label_2)
        self.cmbbox_operation_term = QtGui.QComboBox(self.tab)
        self.cmbbox_operation_term.setObjectName(_fromUtf8("cmbbox_operation_term"))
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.cmbbox_operation_term)
        self.label_3 = QtGui.QLabel(self.tab)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.LabelRole, self.label_3)
        self.cmbbox_operator = QtGui.QComboBox(self.tab)
        self.cmbbox_operator.setObjectName(_fromUtf8("cmbbox_operator"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.cmbbox_operator)
        self.tabwidget.addTab(self.tab, _fromUtf8(""))
        self.tab_2 = QtGui.QWidget()
        self.tab_2.setObjectName(_fromUtf8("tab_2"))
        self.gridLayout = QtGui.QGridLayout(self.tab_2)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tablewidget_client = QtGui.QTableWidget(self.tab_2)
        self.tablewidget_client.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_client.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_client.setObjectName(_fromUtf8("tablewidget_client"))
        self.tablewidget_client.setColumnCount(0)
        self.tablewidget_client.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_client, 0, 0, 1, 1)
        self.tabwidget.addTab(self.tab_2, _fromUtf8(""))
        self.gridLayout_2.addWidget(self.tabwidget, 1, 0, 1, 1)
        self.btn_print = QtGui.QPushButton(Dialog)
        self.btn_print.setObjectName(_fromUtf8("btn_print"))
        self.gridLayout_2.addWidget(self.btn_print, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        self.tabwidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業指示図作成（受託作業）", None))
        self.groupBox.setTitle(_translate("Dialog", "対象計画の検索", None))
        self.label.setText(_translate("Dialog", "作業", None))
        self.btn_export_csv.setText(_translate("Dialog", "csv出力する", None))
        self.label_2.setText(_translate("Dialog", "作業予定期間", None))
        self.label_3.setText(_translate("Dialog", "作業予定者", None))
        self.tabwidget.setTabText(self.tabwidget.indexOf(self.tab), _translate("Dialog", "日程・担当者毎に作成", None))
        self.tabwidget.setTabText(self.tabwidget.indexOf(self.tab_2), _translate("Dialog", "依頼者毎に作成", None))
        self.btn_print.setText(_translate("Dialog", "指示図作成", None))

