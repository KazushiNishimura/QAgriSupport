# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'qrcode_print_ui.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(176, 188)
        self.gridLayout_3 = QtGui.QGridLayout(Dialog)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn = QtGui.QPushButton(Dialog)
        self.btn.setObjectName(_fromUtf8("btn"))
        self.gridLayout_3.addWidget(self.btn, 2, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.spbox = QtGui.QSpinBox(self.groupBox_2)
        self.spbox.setObjectName(_fromUtf8("spbox"))
        self.gridLayout_2.addWidget(self.spbox, 1, 0, 1, 1)
        self.gridLayout_3.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.lineedit = QtGui.QLineEdit(self.groupBox)
        self.lineedit.setObjectName(_fromUtf8("lineedit"))
        self.gridLayout.addWidget(self.lineedit, 0, 0, 1, 1)
        self.gridLayout_3.addWidget(self.groupBox, 0, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "製品ラベル印刷", None))
        self.btn.setText(_translate("Dialog", "印刷レイアウト作成", None))
        self.groupBox_2.setTitle(_translate("Dialog", "シート印刷枚数（12ラベル/枚）", None))
        self.groupBox.setTitle(_translate("Dialog", "生産組織識別名称", None))

