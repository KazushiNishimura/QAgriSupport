# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from correct_report_operator_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,dlg):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.dlg=dlg
        self.populate_cmbbox_operator()

        self.connect(self.ui.btn_ok,SIGNAL("clicked()"),self.ok)
        self.connect(self.ui.btn_cancel,SIGNAL("clicked()"),self.cancel)

    def populate_cmbbox_operator(self):
        proc = pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operator from operator_master")
        rows=cursor.fetchall()
        self.ui.cmbbox_operator.clear()
        #self.ui.cmbbox_operator.addItem("")
        for row in rows:
            self.ui.cmbbox_operator.addItem(row[0])
        db.close()

    def ok(self):
        self.dlg.operator=self.ui.cmbbox_operator.currentText()
        self.close()

    def cancel(self):
        self.dlg.operator="cancel"
        self.close()