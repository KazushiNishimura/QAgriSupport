# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'correct_report_machine_ui.ui'
#
# Created: Fri Apr 07 17:42:05 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(273, 285)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.tablewidget_machine = QtGui.QTableWidget(Dialog)
        self.tablewidget_machine.setObjectName(_fromUtf8("tablewidget_machine"))
        self.tablewidget_machine.setColumnCount(0)
        self.tablewidget_machine.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_machine, 1, 0, 1, 2)
        self.btn_cancel = QtGui.QPushButton(Dialog)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.gridLayout.addWidget(self.btn_cancel, 2, 0, 1, 1)
        self.btn_ok = QtGui.QPushButton(Dialog)
        self.btn_ok.setObjectName(_fromUtf8("btn_ok"))
        self.gridLayout.addWidget(self.btn_ok, 2, 1, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "機材の追加", None))
        self.label.setText(_translate("Dialog", "機材一覧", None))
        self.btn_cancel.setText(_translate("Dialog", "キャンセル", None))
        self.btn_ok.setText(_translate("Dialog", "機材の追加", None))

