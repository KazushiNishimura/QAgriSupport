# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from qrcode_print_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess


class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.connect(self.ui.btn, SIGNAL("clicked()"),self.print_qr)

    def print_qr(self):
        if self.ui.lineedit.text()=="":
            pyqgis_processing.show_msgbox(u"生産組織識別名称を入力してください")
            return
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'レイアウト作成中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)
        html=u"""<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <style>
               @page {
         　　　　 /* margin: 21.2mm 18.6mm 21.2mm 18.6mm; */
                margin:0;
                }
                @media print {
                margin: 21.2mm 18.6mm 21.2mm 18.6mm;
                /*  body {width: 172.8mm; height: 253.8mm;} */
                }
                .cssHeaderCell {
                   /* font-size: 40px;  */
                }
                .cssTableCell {
                    /* font-size: 40px; */
                }
                .print_page{
                 /* width: 172.8mm; */
                 /* height: 253.8mm; */
                 width: 100%;
                 height: 100%;
                page-break-after: always; /* 各ページの終わりに改ページ */
                }
                .print_page:last-child{
                page-break-after: auto; /* 最後のページの改ページを防ぐ */
                }
            </style>
            </head>
            <link media="print" rel="stylesheet" href="print.css">
            <article>"""
        proc=pyqgis_processing
        db=proc.connect_db()

        farm_name=self.ui.lineedit.text()
        iterate=self.ui.spbox.value()
        for i in range(iterate):
            html+=""" <section class="print_page" ><body>"""
            for j in range(6):
                cursor=db.cursor()
                cursor.execute('insert into qrcode_test2 (farm_name) values (?)',(farm_name,))
                insert_id=cursor.lastrowid
                qr_string=farm_name+"-" + str(insert_id)
                #print str(insert_id)
                #print qr_string
                html+=u"""<table border="1" width="100%" height="16.7%" ><tr>
                <td width="50%"  valign="top"><img src="http://chart.apis.google.com/chart?chs=130x130&cht=qr&chl="""
                html+=qr_string
                html+=u""" " alt="QRコード" align="left">"""
                html+=u"""<font size="4">生産組織：<br>"""+ farm_name + u"<br>生育ステージ：<br>出穂　　糊熟　<br>黄熟　　完熟</font>"  #"""<h1>%s</h1>""" %(farm_name)
                html+="""</td>"""
                cursor=db.cursor()
                cursor.execute('insert into qrcode_test2 (farm_name) values (?)',(farm_name,))
                insert_id=cursor.lastrowid
                qr_string=farm_name+"-" + str(insert_id)
                html+=u"""<td width="50%"  valign="top"><img src="http://chart.apis.google.com/chart?chs=130x130&cht=qr&chl="""
                html+=qr_string
                html+=u""" " alt="QRコード" align="left">"""
                html+=u"""<font size="4">生産組織：<br>"""+ farm_name + u"<br>生育ステージ：<br>出穂　　糊熟　<br>黄熟　　完熟</font>"
                html+="""</td></tr></table>"""
            html+="</section></body>"""
        html+="""</article>"""
        db.commit()
        db.close()
        f = open(proc.get_prj_path() +"/qrcode.html", 'w') # 書き込みモードで開く
        f.write(html.encode('utf-8')) # 引数の文字列をファイルに書き込む
        f.close() # ファイルを閉じる
        pbar.setValue(1)
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"/qrcode.html")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"/qrcode.html"])







