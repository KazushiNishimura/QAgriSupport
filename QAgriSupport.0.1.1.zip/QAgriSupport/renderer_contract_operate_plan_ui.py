# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'renderer_contract_operate_plan_ui.ui'
#
# Created: Wed May 17 15:17:17 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(428, 600)
        self.gridLayout_4 = QtGui.QGridLayout(Dialog)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tablewidget_contract = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_contract.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_contract.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_contract.setObjectName(_fromUtf8("tablewidget_contract"))
        self.tablewidget_contract.setColumnCount(0)
        self.tablewidget_contract.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_contract, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.tablewidget_plan = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_plan.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_plan.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_plan.setObjectName(_fromUtf8("tablewidget_plan"))
        self.tablewidget_plan.setColumnCount(0)
        self.tablewidget_plan.setRowCount(0)
        self.gridLayout_3.addWidget(self.tablewidget_plan, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox_3, 2, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.cmbbox_operate = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout.addWidget(self.cmbbox_operate, 0, 0, 1, 1)
        self.gridLayout_4.addWidget(self.groupBox, 0, 0, 1, 1)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.gridLayout_4.addWidget(self.btn_export_csv, 5, 0, 1, 1)
        self.btn_show_table = QtGui.QPushButton(Dialog)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout_4.addWidget(self.btn_show_table, 4, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox_4)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.rbtn_plan = QtGui.QRadioButton(self.groupBox_4)
        self.rbtn_plan.setChecked(True)
        self.rbtn_plan.setAutoRepeat(False)
        self.rbtn_plan.setObjectName(_fromUtf8("rbtn_plan"))
        self.horizontalLayout.addWidget(self.rbtn_plan)
        self.rbtn_client = QtGui.QRadioButton(self.groupBox_4)
        self.rbtn_client.setObjectName(_fromUtf8("rbtn_client"))
        self.horizontalLayout.addWidget(self.rbtn_client)
        self.gridLayout_4.addWidget(self.groupBox_4, 3, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業計画（受託作業）", None))
        self.groupBox_2.setTitle(_translate("Dialog", "受託一覧", None))
        self.groupBox_3.setTitle(_translate("Dialog", "日程・作業者別面積", None))
        self.groupBox.setTitle(_translate("Dialog", "対象作業", None))
        self.btn_export_csv.setText(_translate("Dialog", "計画の出力", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブルの表示", None))
        self.groupBox_4.setTitle(_translate("Dialog", "色分けのルール", None))
        self.rbtn_plan.setText(_translate("Dialog", "作業日程で色分けする", None))
        self.rbtn_client.setText(_translate("Dialog", "依頼者毎に色分けする", None))

