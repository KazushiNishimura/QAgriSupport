# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtSql import QSqlTableModel
from master_edit_cultivation_calendar_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):

    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.ui.dateEdit.setDate(datetime.date.today())
        self.ui.dateEdit_2.setDate(datetime.date.today())
        self.ui.dateEdit_3.setDate(datetime.date.today())
        self.ui.dateEdit_4.setDate(datetime.date.today())

        self.populate_cmbbox()

        self.connect(self.ui.cmbbox_crop, SIGNAL("currentIndexChanged(const QString&)"),self.populate_table)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.ui.tablewidget_cultivation.itemSelectionChanged.connect(self.selection_changed)
        self.connect(self.ui.btn_edit,SIGNAL("clicked()"),self.update_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
    def populate_cmbbox(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()

        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmbbox_crop.addItem(row[0])


    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")


        cursor=db.cursor()

        cursor.execute('select id ,operation,term_start,term_end from cultivation_calendar_master where crop= ?', (self.ui.cmbbox_crop.currentText(),))
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tablewidget_cultivation.clear()
        self.ui.tablewidget_cultivation.setSortingEnabled(True)
        self.ui.tablewidget_cultivation.setRowCount(row_count)
        headers=["id",u"作業名",u"作業開始時期",u"作業完了時期"]
        self.ui.tablewidget_cultivation.setColumnCount(len(headers))
        self.ui.tablewidget_cultivation.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_cultivation.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_cultivation.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tablewidget_cultivation.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_cultivation.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tablewidget_cultivation.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tablewidget_cultivation.setItem(i,3,QTableWidgetItem(row[3]))
            i=i+1
        self.ui.tablewidget_cultivation.resizeColumnsToContents()
        self.ui.tablewidget_cultivation.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.lineEdit.text()=="":
            pyqgis_processing.show_msgbox(u"作業名を入力してください")
            return
        path=pyqgis_processing.get_prj_path()
        connect_db=sqlite3.connect(path+"/"+"management_db.sqlite")
        crop=self.ui.cmbbox_crop.currentText()
        op_name=self.ui.lineEdit.text()
        term_start="{0:02d}".format(self.ui.dateEdit.date().month())+ "/"  +"{0:02d}".format(self.ui.dateEdit.date().day())
        term_end="{0:02d}".format(self.ui.dateEdit_2.date().month())+"/"+"{0:02d}".format(self.ui.dateEdit_2.date().day())
        new_row=(crop,op_name,term_start,term_end)
        connect_db.execute('insert into cultivation_calendar_master (crop,operation,term_start,term_end) values (?,?,?,?)',new_row)
        connect_db.commit()
        self.ui.lineEdit.clear()
        self.populate_table()

    def selection_changed(self):

        rows=[]
        for index in self.ui.tablewidget_cultivation.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            #print self.ui.tablewidget_cultivation.item(row,1).text()
            self.ui.lineEdit_2.setText(self.ui.tablewidget_cultivation.item(row,1).text())
            self.ui.dateEdit_3.setDate(pyqgis_processing.date_from_text(self.ui.tablewidget_cultivation.item(row,2).text()))
            self.ui.dateEdit_4.setDate(pyqgis_processing.date_from_text(self.ui.tablewidget_cultivation.item(row,3).text()))

    def update_row(self):
        path=pyqgis_processing.get_prj_path()
        connect_db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=connect_db.cursor()
        rows=[]
        for index in self.ui.tablewidget_cultivation.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        if len(rows)==0:
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        for row in rows:
            operation=self.ui.lineEdit_2.text()
            term_start="{0:02d}".format(self.ui.dateEdit_3.date().month())+ "/"  +"{0:02d}".format(self.ui.dateEdit_3.date().day())
            term_end="{0:02d}".format(self.ui.dateEdit_4.date().month())+"/"+"{0:02d}".format(self.ui.dateEdit_4.date().day())
            id_=int(self.ui.tablewidget_cultivation.item(row,0).text())
            cursor.execute('update cultivation_calendar_master set operation=?,term_start=?,term_end=? where id=?',(operation,term_start,term_end,id_,))
            self.ui.tablewidget_cultivation.setItem(row,0,QTableWidgetItem(str(id_)))
            self.ui.tablewidget_cultivation.setItem(row,1,QTableWidgetItem(operation))
            self.ui.tablewidget_cultivation.setItem(row,2,QTableWidgetItem(term_start))
            self.ui.tablewidget_cultivation.setItem(row,3,QTableWidgetItem(term_end))


        connect_db.commit()
        connect_db.close()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        connect_db=sqlite3.connect(path+"/"+"management_db.sqlite")
        for i in range(0,self.ui.tablewidget_cultivation.rowCount()):
            if self.ui.tablewidget_cultivation.item(i,0).isSelected()==True:
                connect_db.execute('delete from cultivation_calendar_master where id = ?',(int(self.ui.tablewidget_cultivation.item(i,0).text()),))


        connect_db.commit()
        connect_db.close()

        self.populate_table()






