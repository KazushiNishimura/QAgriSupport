# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'to_mobile_ui.ui'
#
# Created: Mon Apr 24 16:46:30 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(342, 445)
        self.gridLayout_3 = QtGui.QGridLayout(Dialog)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridlayout = QtGui.QGridLayout(self.groupBox)
        self.gridlayout.setObjectName(_fromUtf8("gridlayout"))
        self.cmbbox_from_mail = QtGui.QComboBox(self.groupBox)
        self.cmbbox_from_mail.setObjectName(_fromUtf8("cmbbox_from_mail"))
        self.gridlayout.addWidget(self.cmbbox_from_mail, 0, 0, 1, 1)
        self.lineEdit_pass = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_pass.setObjectName(_fromUtf8("lineEdit_pass"))
        self.gridlayout.addWidget(self.lineEdit_pass, 2, 0, 1, 1)
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridlayout.addWidget(self.label, 1, 0, 1, 1)
        self.gridLayout_3.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.tablewidget_to_mail = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_to_mail.setObjectName(_fromUtf8("tablewidget_to_mail"))
        self.tablewidget_to_mail.setColumnCount(0)
        self.tablewidget_to_mail.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_to_mail, 0, 0, 1, 1)
        self.gridLayout_3.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.btn_send = QtGui.QPushButton(Dialog)
        self.btn_send.setObjectName(_fromUtf8("btn_send"))
        self.gridLayout_3.addWidget(self.btn_send, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "モバイルへのデータ送信", None))
        self.groupBox.setTitle(_translate("Dialog", "送信元アカウント（Gmail限定）", None))
        self.label.setText(_translate("Dialog", "パスワード", None))
        self.groupBox_2.setTitle(_translate("Dialog", "送信先アカウント", None))
        self.btn_send.setText(_translate("Dialog", "モバイルにデータを送信する", None))

