# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtSql import QSqlTableModel
from master_edit_contract_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.ui.dateEdit_start.setDate(datetime.date.today())
        self.ui.dateEdit_end.setDate(datetime.date.today())
        self.ui.dateEdit_start_2.setDate(datetime.date.today()),
        self.ui.dateEdit_end_2.setDate(datetime.date.today())


        self.populate_table()

        self.ui.tableWidget_contract.itemSelectionChanged.connect(self.selection_change)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_edit,SIGNAL("clicked()"),self.update_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)


    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/" + "management_db.sqlite")
        cursor=db.cursor()
        cursor.execute("select id ,operation , term_start ,term_end from contract_operation_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tableWidget_contract.clear()
        self.ui.tableWidget_contract.setSortingEnabled(True)
        self.ui.tableWidget_contract.setRowCount(row_count)
        headers=["id",u"受託作業名",u"作業開始時期",u"作業完了時期"]
        self.ui.tableWidget_contract.setColumnCount(len(headers))
        self.ui.tableWidget_contract.setHorizontalHeaderLabels(headers)
        self.ui.tableWidget_contract.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget_contract.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tableWidget_contract.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tableWidget_contract.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tableWidget_contract.setItem(i,2,QTableWidgetItem(row[2]))
            self.ui.tableWidget_contract.setItem(i,3,QTableWidgetItem(row[3]))
            i=i+1
        self.ui.tableWidget_contract.resizeColumnsToContents()

        cursor.close()
        db.close()
    def insert_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        operation=self.ui.lineEdit_contract.text()
        term_start="{0:02d}".format(self.ui.dateEdit_start.date().month())+ \
        "/"  +"{0:02d}".format(self.ui.dateEdit_start.date().day())
        term_end="{0:02d}".format(self.ui.dateEdit_end.date().month())+ \
        "/"+"{0:02d}".format(self.ui.dateEdit_end.date().day())
        new_row=(operation,term_start,term_end)
        db.execute('insert into contract_operation_master (operation,term_start,term_end) values (?,?,?)',new_row)
        db.commit()
        db.close()
        self.ui.lineEdit_contract.clear()
        self.populate_table()

    def selection_change(self):
        rows=[]
        for index in self.ui.tableWidget_contract.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            self.ui.lineEdit_contract2.setText(self.ui.tableWidget_contract.item(row,1).text())
            self.ui.dateEdit_start_2.setDate(pyqgis_processing.date_from_text(self.ui.tableWidget_contract.item(row,2).text()))
            self.ui.dateEdit_end_2.setDate(pyqgis_processing.date_from_text(self.ui.tableWidget_contract.item(row,3).text()))

    def update_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path + "/" + "management_db.sqlite")
        cursor=db.cursor()
        rows=[]
        for index in self.ui.tableWidget_contract.selectedIndexes():
            if index.column()==0:
                rows.append(index.row())
        for row in rows:
            operation=self.ui.lineEdit_contract2.text()
            term_start="{0:02d}".format(self.ui.dateEdit_start_2.date().month())+ "/"  +"{0:02d}".format(self.ui.dateEdit_start_2.date().day())
            term_end="{0:02d}".format(self.ui.dateEdit_end_2.date().month())+"/"+"{0:02d}".format(self.ui.dateEdit_end_2.date().day())
            id =int(self.ui.tableWidget_contract.item(row,0).text())
            cursor.execute('update contract_operation_master set operation=?,term_start=?,term_end=? where id=?',(operation,term_start,term_end,id))
            self.ui.tableWidget_contract.setItem(row,0,QTableWidgetItem(str(id)))
            self.ui.tableWidget_contract.setItem(row,1,QTableWidgetItem(operation))
            self.ui.tableWidget_contract.setItem(row,2,QTableWidgetItem(term_start))
            self.ui.tableWidget_contract.setItem(row,3,QTableWidgetItem(term_end))
        db.commit()
        db.close()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        rows=[]
        for index in self.ui.tableWidget_contract.selectedIndexes():
            if index.column()==0:
                rows.append(index.row())
        for row in rows:
            db.execute('delete from contract_operation_master where id = ?',(int(self.ui.tableWidget_contract.item(row,0).text()),))
        db.commit()
        db.close()
        self.populate_table()


