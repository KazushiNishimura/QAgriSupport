# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from master_edit_stock_yard_ui import  Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_table()

        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)


    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")

        cursor=db.cursor()
        cursor.execute("select id ,stock_yard from stock_yard_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tablewidget_stock_yard.clear()
        self.ui.tablewidget_stock_yard.setSortingEnabled(True)
        self.ui.tablewidget_stock_yard.setRowCount(row_count)
        headers=["id",u"生育ステージ"]
        self.ui.tablewidget_stock_yard.setColumnCount(len(headers))
        self.ui.tablewidget_stock_yard.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_stock_yard.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_stock_yard.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tablewidget_stock_yard.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_stock_yard.setItem(i,1,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tablewidget_stock_yard.resizeColumnsToContents()
        self.ui.tablewidget_stock_yard.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.ledit_stock_yard.text()=="":
            pyqgis_processing.show_msgbox(u"生育ステージを入力してください")
            return
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        growth_stage=self.ui.ledit_stock_yard.text()
        new_row=(growth_stage,)
        db.execute('insert into stock_yard_master (stock_yard) values (?)',new_row)
        db.commit()
        db.close()
        self.ui.ledit_stock_yard.clear()
        self.populate_table()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        for i in range(0,self.ui.tablewidget_stock_yard.rowCount()):
            if self.ui.tablewidget_stock_yard.item(i,0).isSelected()==True:
                db.execute('delete from stock_yard_master where id = ?',(int(self.ui.tablewidget_stock_yard.item(i,0).text()),))


        db.commit()
        db.close()

        self.populate_table()


