# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from product_table_edit_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import csv
import os, sys, subprocess


class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.year=y
        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
#         self.operation_table=proc.get_operation_table()
        self.cropping_table=proc.get_cropping_table()
        self.contract_table=proc.get_contract_table()

        #proc.remove_join()
#         proc.clear_query(self.farmland_table)
#         proc.clear_query(self.operation_table)
#         proc.clear_query(self.cropping_table)
#         proc.clear_query(self.contract_table)
#         proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\' or "kind"=\'受託地\'')
# #         proc.set_query(self.operation_table,'"year"='+str(self.year))
#         proc.set_query(self.cropping_table,'"year"='+str(self.year))
#         proc.set_query(self.contract_table,'"year"='+str(self.year))

        #proc.add_join_operation_table()
        #proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\'  and  "operation_table_progress" =\'未完了\' ')

#         proc.hide_all_columns(self.farmland_table)
#         proc.set_column_visibility(self.farmland_table, 'operation_table_operator', True)
#         proc.set_column_visibility(self.farmland_table, 'operation_table_operation_day', True)
#         proc.set_column_visibility(self.farmland_table, 'operation_table_progress', True)


#         proc.show_columns_farmland_table(self.farmland_table)
#         proc.show_columns_operation_table(self.farmland_table)
#         proc.set_alias_farmland_table(self.farmland_table)
#         proc.set_alias_operation_table(self.farmland_table)

#         self.ui.dateEdit_operation_day.setDate(datetime.date.today())
        self.populate_cmbbox_crop()
        self.populate_cmbbox_stage()
        self.populate_cmbbox_weed()
        self.populate_cmbbox_stockyard()
        self.populate_cmbbox_process()
#         self.populate_cmbbox_operator()
#         self.populate_table_suboperator()
#         self.populate_table_machine()
#
#
        self.farmland_table.selectionChanged.connect(self.selection_changed)
        self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
        self.connect(self.ui.cmbbox_operation,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
        self.connect(self.ui.btn_register,SIGNAL("clicked()"),self.update_info)
        self.connect(self.ui.btn_open_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_csv_export,SIGNAL("clicked()"),self.export_csv)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_record)
#             self.connect(self.ui.cmbbox_operation_term,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_term_change)
#         self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.render_map)
#         self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.check_variety)
#         self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
#         self.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
#         self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
#         self.connect(self.ui.btn_add,SIGNAL("clicked()"),self.add_row)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)

    def delete_record(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"圃場が複数選択されています")
            return

        if self.ui.cmbbox_crop.currentText()==u"受託":
            crop=u"受託"
            operation=self.ui.cmbbox_operation.currentText()
        else:
            crop=self.ui.cmbbox_crop.currentText()

        for feature in features:
            farmland_code=feature['farmland_code']

        year=self.year

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        if self.ui.cmbbox_crop.currentText()==u"受託":
            query="""delete from product_table where year=? and farmland_code=? and crop=? and operation=?  """
        else:
            query="""delete from product_table where year=? and farmland_code=? and crop=?  """
        if self.ui.cmbbox_crop.currentText()==u"受託":
            key=(year,farmland_code,crop,operation)
        else:
            key=(year,farmland_code,crop)

        cursor.execute(query,key)
        row=cursor.fetchone()

        if row is None:
            pass
        else:

            db.execute(query,key)


        db.commit()
        db.close()

        self.get_farmland_info()

    def export_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_crop.currentText()==u"受託":
            crop=u"受託"
            operation=self.ui.cmbbox_operation.currentText()
        else:
            crop=self.ui.cmbbox_crop.currentText()

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/製品品質台帳"):
            os.mkdir(path+u"/製品品質台帳")
        path+=u"/製品品質台帳"
        if self.ui.cmbbox_crop.currentText()==u"受託":
            filename= path + "/"+"%s.csv"  % (str(self.year)+'_'+u'作業受託_'+self.ui.cmbbox_operation.currentText())
        else:
            filename= path + "/"+"%s.csv"  % (str(self.year)+'_'+self.ui.cmbbox_crop.currentText())
#         print path
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()

        crop=self.ui.cmbbox_crop.currentText()
        if crop==u"受託":
            operation=self.ui.cmbbox_operation.currentText()
            query="""select farmland_code,yield,average_weight,
            average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
            stock_yard from product_table where year=? and
            crop=? and operation=?  """
            key=(self.year,crop,operation)
        else:
            query="""select farmland_code,yield,average_weight,
            average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
            stock_yard from product_table where year=? and
            crop=? """
            key=(self.year,crop)

        cursor.execute(query,key)
        rows=cursor.fetchall()

        list_csv=[]
        field_name1=u"圃場名"
        field_name2=u"ロール個数"
        field_name3=u"平均重量"
        field_name4=u"平均水分率"
        field_name5=u"生育ステージ"
        field_name6=u"雑草量"
        field_name7=u"切断長"
        field_name8=u"破砕"
        field_name9=u"巻き数"
        field_name10=u"保管場所"
        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),
                         field_name6.encode('"cp932"'),field_name7.encode('"cp932"'),field_name8.encode('"cp932"'),field_name9.encode('"cp932"'),field_name10.encode('"cp932"')])
        for row in rows:
            field1=row[0].encode('"cp932"')

            if row[1] is None:
                field2=u""
            else:
                field2=row[1]

            if row[2] is None:
                field3=u""
            else:
                field3=row[2]

            if row[3] is None:
                field4=u""
            else:
                field4=row[3]

            if row[4] is None:
                field5=u""
            else:
                field5=row[4].encode('"cp932"')

            if row[5] is None:
                field6=u""
            else:
                field6=row[5].encode('"cp932"')

            if row[6] is None:
                field7=u""
            else:
                field7=row[6]

            if row[7] is None:
                field8=u""
            else:
                field8=row[7].encode('"cp932"')

            if row[8] is None:
                field9=u""
            else:
                field9=row[8]

            if row[9] is None:
                field10=u""
            else:
                field10=row[9].encode('"cp932"')


            list_csv.append([field1,field2,field3,field4,field5,field6,field7,field8,field9,field10])
            #print row[1]


        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])

    def show_attribute_table(self):
        pyqgis_processing.clear_attributetable()
        lyr=self.farmland_table
        self.attribute_table=iface.showAttributeTable(lyr)

    def update_info(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            pyqgis_processing.show_msgbox(u"圃場を選択してください")
            return
        elif len(features)>1:
            pyqgis_processing.show_msgbox(u"圃場が複数選択されています")
            return

        if self.ui.cmbbox_crop.currentText()==u"受託":
            crop=u"受託"
            operation=self.ui.cmbbox_operation.currentText()
        else:
            crop=self.ui.cmbbox_crop.currentText()

        for feature in features:
            farmland_code=feature['farmland_code']

        year=self.year



        try:
            count_roll= float(self.ui.ledit_count.text())
        except:
            count_roll=None

        try:
            av_weight=float(self.ui.ledit_weight.text())
        except:
            av_weight=None

        try:
            av_moisture=float(self.ui.ledit_moisture.text())
        except:
            av_moisture=None

        if self.ui.cmbox_stage.currentText()==u"指定無し":
            stage=None
        else:
            stage=self.ui.cmbox_stage.currentText()

        if self.ui.cmbbox_weed.currentText()==u"指定無し":
            weed=None
        else:
            weed=self.ui.cmbbox_weed.currentText()

        try:
            cut_length=float(self.ui.ledit_cutlength.text())
        except:
            cut_length=None

        if self.ui.cmbbox_process.currentText()==u"指定無し":
            processing=None
        else:
            processing=self.ui.cmbbox_process.currentText()

        try:
            wrapping=float(self.ui.ledit_wrapping.text())
        except:
            wrapping=None

        if self.ui.cmbbox_stockyard.currentText()==u"指定無し":
            stockyard=None
        else:
            stockyard=self.ui.cmbbox_stockyard.currentText()

        #既存データの確認
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        if self.ui.cmbbox_crop.currentText()==u"受託":
            query="""select * from product_table where year=? and farmland_code=? and crop=? and operation=?  """
        else:
            query="""select * from product_table where year=? and farmland_code=? and crop=?  """
        if self.ui.cmbbox_crop.currentText()==u"受託":
            key=(year,farmland_code,crop,operation)
        else:
            key=(year,farmland_code,crop)

        cursor.execute(query,key)
        row=cursor.fetchone()
        new_row =None
        if row is None:
            if self.ui.cmbbox_crop.currentText()==u"受託":
                new_row=(year,farmland_code,crop,count_roll,av_weight,av_moisture,stage,weed,cut_length,processing,wrapping,stockyard,operation,1)
                db.execute("""insert into product_table (year,farmland_code,crop,yield,average_weight,
                average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,stock_yard,operation,registered) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",new_row)
            else:
                new_row=(year,farmland_code,crop,count_roll,av_weight,av_moisture,stage,weed,cut_length,processing,wrapping,stockyard,1)
                db.execute("""insert into product_table (year,farmland_code,crop,yield,average_weight,
                average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,stock_yard,registered) values (?,?,?,?,?,?,?,?,?,?,?,?,?)""",new_row)
        else:
            if self.ui.cmbbox_crop.currentText()==u"受託":
                new_row=(count_roll,av_weight,av_moisture,stage,weed,cut_length,processing,wrapping,stockyard,year,farmland_code,crop,operation)
                db.execute("""update product_table  set yield=?,average_weight=?,
                average_moisture=?,growth_stage=?,weed=?,cutting_length=?,processing=?,wrapping_count=?,stock_yard=?
                 where year=? and farmland_code=? and crop=? and operation=?""",new_row)
            else:
                new_row=(count_roll,av_weight,av_moisture,stage,weed,cut_length,processing,wrapping,stockyard,year,farmland_code,crop)
                db.execute("""update product_table  set yield=?,average_weight=?,
                average_moisture=?,growth_stage=?,weed=?,cutting_length=?,processing=?,wrapping_count=?,stock_yard=?
                 where year=? and farmland_code=? and crop=?""",new_row)

        db.commit()
        db.close()

        self.clear_item()
        self.get_farmland_info()

    def clear_item(self):

        self.ui.ledit_count.setText("")
        self.ui.ledit_weight.setText("")
        self.ui.ledit_moisture.setText("")
        self.ui.cmbox_stage.setCurrentIndex(0)
        self.ui.cmbbox_weed.setCurrentIndex(0)
        self.ui.ledit_cutlength.setText("")
        self.ui.cmbbox_process.setCurrentIndex(0)
        self.ui.ledit_wrapping.setText("")
        self.ui.cmbbox_stockyard.setCurrentIndex(0)


    def get_farmland_info(self):
        features=self.farmland_table.selectedFeatures()
        if len(features)==0:
            self.clear_item()
            return
        for feature in features:
            farmland_code=feature['farmland_code']
            self.ui.lbl_farmland.setText(farmland_code)

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        if self.ui.cmbbox_crop.currentText()==u"受託":
            crop=self.ui.cmbbox_crop.currentText()
            operation=self.ui.cmbbox_operation.currentText()
            query="""select yield,average_weight,
            average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
            stock_yard from product_table where year=? and farmland_code=? and
            crop=? and operation=?  """
            key=(self.year,farmland_code,crop,operation)
            cursor.execute(query,key)
            row=cursor.fetchone()
        else:
            crop=self.ui.cmbbox_crop.currentText()
            #operation=self.ui.cmbbox_operation.currentText()
            query="""select yield,average_weight,
            average_moisture,growth_stage,weed,cutting_length,processing,wrapping_count,
            stock_yard from product_table where year=? and farmland_code=? and
            crop=?   """
            key=(self.year,farmland_code,crop)
            cursor.execute(query,key)
            row=cursor.fetchone()


#         for item in row:
#             print item

        if row is None:
            self.clear_item()
            return


        if row[0] !=None:
            self.ui.ledit_count.setText(str(row[0]))
        else:
            self.ui.ledit_count.setText("")
        if row[1] !=None:
            self.ui.ledit_weight.setText(str(row[1]))
        else:
            self.ui.ledit_weight.setText(str(""))
        if row[2] !=None:
            self.ui.ledit_moisture.setText(str(row[2]))
        else:
            self.ui.ledit_moisture.setText("")
        if row[3]!=None:
            index = self.ui.cmbox_stage.findText(row[3], QtCore.Qt.MatchFixedString)
            if index >= 0:
                self.ui.cmbox_stage.setCurrentIndex(index)
        else:
            self.ui.cmbox_stage.setCurrentIndex(0)
        if row[4]!=None:
            index = self.ui.cmbbox_weed.findText(row[4], QtCore.Qt.MatchFixedString)
            if index >= 0:
                self.ui.cmbbox_weed.setCurrentIndex(index)
        else:
            self.ui.cmbbox_weed.setCurrentIndex(0)
        if row[5]!=None:
            self.ui.ledit_cutlength.setText(str(row[5]))
        else:
            self.ui.ledit_cutlength.setText("")
        if row[6]!=None:
            index = self.ui.cmbbox_process.findText(row[6], QtCore.Qt.MatchFixedString)
            if index >= 0:
                self.ui.cmbbox_process.setCurrentIndex(index)
        else:
            self.ui.cmbbox_process.setCurrentIndex(0)
        if row[7]!=None:
            self.ui.ledit_wrapping.setText(str(row[7]))
        else:
            self.ui.ledit_wrapping.setText("")
        if row[8]!=None:
            index = self.ui.cmbbox_stockyard.findText(row[8], QtCore.Qt.MatchFixedString)
            if index >= 0:
                self.ui.cmbbox_stockyard.setCurrentIndex(index)
        else:
            self.ui.cmbbox_stockyard.setCurrentIndex(0)


    def selection_changed(self):
        self.get_farmland_info()

    def populate_cmbbox_stage(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select growth_stage from growth_stage_master")
        rows=cursor.fetchall()

        self.ui.cmbox_stage.clear()
        self.ui.cmbox_stage.addItem(u"指定無し")
        list_stage=[]
        for row in rows:
            if row[0] not in list_stage:
                list_stage.append(row[0])
                self.ui.cmbox_stage.addItem(row[0])

    def populate_cmbbox_process(self):

        self.ui.cmbbox_process.addItem(u"指定無し")
        self.ui.cmbbox_process.addItem(u"有り")
        self.ui.cmbbox_process.addItem(u"無し")
    def populate_cmbbox_weed(self):

        self.ui.cmbbox_weed.addItem(u"指定無し")
        self.ui.cmbbox_weed.addItem(u"普通")
        self.ui.cmbbox_weed.addItem(u"多い")

    def populate_cmbbox_stockyard(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select stock_yard from stock_yard_master")
        rows=cursor.fetchall()

        self.ui.cmbbox_stockyard.clear()
        self.ui.cmbbox_stockyard.addItem(u"指定無し")
        list_yard=[]
        for row in rows:
            if row[0] not in list_yard:
                list_yard.append(row[0])
                self.ui.cmbbox_stockyard.addItem(row[0])


    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()

        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmbbox_crop.addItem(row[0])

        db.close()
        self.ui.cmbbox_crop.addItem(u"受託")

    def cmbbox_crop_change(self):
        proc=pyqgis_processing
        if self.ui.cmbbox_crop.currentText()==u"受託":
            db=proc.connect_db()
            #crop=self.ui.cmbbox_crop.currentText()
            cursor=db.cursor()
            cursor.execute("select operation from contract_operation_master")
            rows=cursor.fetchall()
            self.ui.cmbbox_operation.clear()
            for row in rows:
                self.ui.cmbbox_operation.addItem(row[0])
            db.close()
        else:
            self.ui.cmbbox_operation.clear()
            self.ui.cmbbox_operation.addItem(u"指定不要")
            self.set_query_cropping_table()
            self.render_farmland_crop()

    def cmbbox_operate_change(self):
        proc=pyqgis_processing
        if self.ui.cmbbox_crop.currentText()==u"受託":
            self.set_query_contract_table()
            self.renderer_map_contract()

    def set_query_contract_table(self):
        pyqgis_processing.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        query_string= '\"year\" ='+ str(self.year) +' and ( '
        operation=self.ui.cmbbox_operation.currentText()
        query_string=query_string+ '\"operation\" ='+ '\''+ operation +'\''+')'
        pyqgis_processing.set_query(self.contract_table, query_string)
        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_contract_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_contract_table(self.farmland_table)

    def renderer_map_contract(self):
        layer=self.farmland_table
        operation =self.ui.cmbbox_operation.currentText()
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u""
        query_string= '\"contract_table_client\"  is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        rule=root_rule.children()[0].clone()
        rule.setLabel(u"受託登録圃場")
        query_string= '\"contract_table_client\"  is not None'
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)


        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()




    def render_farmland_crop(self):
        list_rule=[]
        crop=self.ui.cmbbox_crop.currentText()
        label_string=  crop
        query_string= """ "cropping_table_crop" ='%s' """ %(crop)
        list_rule.append([label_string,query_string])
        pyqgis_processing.renderer_map1(self.farmland_table, list_rule)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()


    def set_query_cropping_table(self):
        proc=pyqgis_processing
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.cropping_table)
        proc.set_query(self.farmland_table, u'"kind"=\'経営耕地\'')
        query_string= '\"year\" ='+ str(self.year) +' and  ' + '\"crop\" ='+ '\''+ self.ui.cmbbox_crop.currentText() +'\''
        pyqgis_processing.set_query(self.cropping_table, query_string)
        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_cropping_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_cropping_table(self.farmland_table)









