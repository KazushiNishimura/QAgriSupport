# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'correct_report_operator_ui.ui'
#
# Created: Fri Apr 07 14:54:20 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(230, 107)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.cmbbox_operator = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operator.setObjectName(_fromUtf8("cmbbox_operator"))
        self.verticalLayout.addWidget(self.cmbbox_operator)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 2)
        self.btn_cancel = QtGui.QPushButton(Dialog)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.gridLayout.addWidget(self.btn_cancel, 1, 0, 1, 1)
        self.btn_ok = QtGui.QPushButton(Dialog)
        self.btn_ok.setObjectName(_fromUtf8("btn_ok"))
        self.gridLayout.addWidget(self.btn_ok, 1, 1, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "主担当作業者修正", None))
        self.groupBox.setTitle(_translate("Dialog", "作業者選択", None))
        self.btn_cancel.setText(_translate("Dialog", "キャンセル", None))
        self.btn_ok.setText(_translate("Dialog", "作業者を修正する", None))

