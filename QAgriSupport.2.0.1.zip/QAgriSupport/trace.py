# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from trace_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import csv
import sqlite3
import types
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.year=y
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.list_csv=[]

        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.cropping_table=pyqgis_processing.get_cropping_table()

        self.ui.spbox_year.setValue(datetime.date.today().year)

        self.populate_cmbbox_crop()

        #self.load_csv()

        proc=pyqgis_processing
        proc.set_query(self.farmland_table, u'"kind"=\'経営耕地\'')
        proc.hide_all_columns(self.farmland_table)
        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_cropping_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_cropping_table(self.farmland_table)
#
#         #proc.remove_join()
#         proc.clear_query(self.farmland_table)
#
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
#
#         self.populate_cmbbox_kind()
#
#         self.render_farmland()
#
#         self.farmland_table.selectionChanged.connect(self.selection_changed)
#         self.connect(self.ui.btn_update_area_selected,SIGNAL("clicked()"),self.update_area_selected)
#         self.connect(self.ui.btn_update_all,SIGNAL("clicked()"),self.update_area_all)
#         self.connect(self.ui.btn_write_geom,SIGNAL("clicked()"),self.write_geom)
#         self.connect(self.ui.btn_farmland_code,SIGNAL("clicked()"),self.update_farmland_code)
#         self.connect(self.ui.btn_district,SIGNAL("clicked()"),self.update_district)
#         self.connect(self.ui.btn_kind,SIGNAL("clicked()"),self.update_kind)
#         self.connect(self.ui.btn_area,SIGNAL("clicked()"),self.update_area)
        self.connect(self.ui.cmbbox_crop, SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_change)
        self.connect(self.ui.spbox_year, SIGNAL("valueChanged (int)"),self.spbox_change)
        self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_show_simple_record,SIGNAL("clicked()"),self.print_simple_log)
        self.connect(self.ui.btn_show_list,SIGNAL("clicked()"),self.export_all_csv)
        self.farmland_table.selectionChanged.connect(self.selection_changed)
        self.ui.tablewidget_record.itemSelectionChanged.connect(self.change_tablewidgets)



    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop from crop_master group by crop")
        rows=cursor.fetchall()
        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            self.ui.cmbbox_crop.addItem(row[0])

        db.close()

    def spbox_change(self):
        self.year=self.ui.spbox_year.value()
        self.cmbbox_change()
    def cmbbox_change(self):
        self.set_query_cropping_table()
        self.render_farmland()
        #self.populate_tablewidget_landfield()

    def set_query_cropping_table(self):
        pyqgis_processing.set_query(self.cropping_table, self.create_query_string_crop())

    def create_query_string_crop(self):
        crop=self.ui.cmbbox_crop.currentText()

        query_string=""" "year" =%s and  "crop" ='%s'""" %(str(self.year),crop)
        return query_string

    def render_farmland(self):
        pyqgis_processing.renderer_map1(self.farmland_table, self.create_renderer_rule())
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def create_renderer_rule(self):
        crop=self.ui.cmbbox_crop.currentText()
        list_rule=[]
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop,variety from cropping_table where year=? and crop = ? group by crop,variety",(self.year,crop,))
        rows=cursor.fetchall()
        for row in rows:
            crop=row[0]
            variety=row[1]
            label_string=  crop + ':' + variety
            query_string=""" "cropping_table_crop" ='%s' and "cropping_table_variety" ='%s'""" %(crop,variety)
            list_rule.append([label_string,query_string])
        return list_rule

    def show_attribute_table(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return

        pyqgis_processing.clear_attributetable()
        pyqgis_processing.clear_attributetable()
        layer=self.farmland_table
        query= """ "cropping_table_crop"= """ + "\'" + self.ui.cmbbox_crop.currentText() + "\'"

        self.attribute_table=iface.showAttributeTable(layer,query)

    def print_simple_log(self):
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        proc=pyqgis_processing

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/トレサ出力"):
            os.mkdir(path+u"/トレサ出力")
        path+=u"/トレサ出力"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+  u'_履歴一覧')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        list_csv=[]
        field_name1=u"圃場名"
        field_name2=u"作業名"
        field_name3=u"作業責任者"
        field_name4=u"作業実施日"
        field_name5=u"使用資材1"
        field_name6=u"使用資材2"


        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"')])

        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]

            #list_csv.append(farmland_code2)
            #list_csv.append([farmland_code.encode('"cp932"')])
            db=proc.connect_db()
            cursor=db.cursor()
            cursor.execute("select operation,operator,operation_day,farmland_code from operation_table where year= ? and crop= ?  and farmland_code=? and progress=?" ,(self.year,crop,farmland_code,u"完了"))
            rows=cursor.fetchall()
            for row in rows:
                list_csv_sub=[]
                #list_csv.append(farmland_code.encode('"cp932"'))
                #list_csv.append(farmland_code)
                list_csv_sub=[row[3].encode('"cp932"'),row[0].encode('"cp932"'),row[1].encode('"cp932"'),row[2].encode('"cp932"')]
                cursor2=db.cursor()
                cursor2.execute("select material from material_use_table where year= ? and crop= ?  and operation=? and operator_main=? and operation_day=?",(self.year,crop,row[0],row[1],row[2]))
                rows2=cursor2.fetchall()
                for row2 in rows2:
                    list_csv_sub.append(row2[0].encode('"cp932"'))
                   # print row2[0]
                list_csv.append(list_csv_sub)

        db.close()
        dataWriter.writerows(list_csv)
        table_csv.close()

#         if sys.platform == "win32":
#             os.startfile(filename)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename])

        msg=u"""履歴一覧を%sに出力しました """ %(path)
        pyqgis_processing.show_msgbox(msg)

    def selection_changed(self):
        self.population_tablewidget_record()



    def population_tablewidget_record(self):

        features=self.farmland_table.selectedFeatures()
        try:
            feature=features[0]
        except:
            return
        farmland_code=feature['farmland_code']
#         for feature in features:
#             farmland_code=feature['farmland_code']
#             break

        crop=self.ui.cmbbox_crop.currentText()

        db=pyqgis_processing.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation,operator,operation_day,farmland_code from operation_table where year= ? and crop= ?  and farmland_code=? and progress=?" ,(self.year,crop,farmland_code,u"完了"))
        rows=cursor.fetchall()
        self.ui.tablewidget_record.clear()
        self.ui.tablewidget_record.setSortingEnabled(True)
        self.ui.tablewidget_record.setRowCount(len(rows))
        headers=[u"作業名",u"作業者名",u"作業実施日"]
        self.ui.tablewidget_record.setColumnCount(len(headers))
        self.ui.tablewidget_record.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            self.ui.tablewidget_record.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_record.setItem(i,1,QTableWidgetItem(str(row[1])))
            self.ui.tablewidget_record.setItem(i,2,QTableWidgetItem(str(row[2])))
            i=i+1

        self.ui.tablewidget_record.resizeColumnsToContents()

    def change_tablewidgets(self):

        try:
            key_value=self.return_key_value()
            self.populate_tablewidget_operator(key_value)
            self.populate_tablewidget_machine(key_value)
            self.populate_tablewidget_material(key_value)
        except:
            self.ui.tablewidget_operator.clear()
            self.ui.tablewidget_operator.setRowCount(0)
            self.ui.tablewidget_operator.setColumnCount(0)
            self.ui.tablewidget_machine.clear()
            self.ui.tablewidget_machine.setRowCount(0)
            self.ui.tablewidget_machine.setColumnCount(0)
            self.ui.tablewidget_material.clear()
            self.ui.tablewidget_material.setRowCount(0)
            self.ui.tablewidget_material.setColumnCount(0)

        #self.select_landfields()
        #self.renderer_map()
        #self.get_year(key_value)

    def return_key_value(self):
        row_count=self.ui.tablewidget_record.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_record.item(i,0).isSelected()==True:
                operation_day=self.ui.tablewidget_record.item(i,2).text()
                crop=self.ui.cmbbox_crop.currentText()
                operation=self.ui.tablewidget_record.item(i,0).text()
                operator=self.ui.tablewidget_record.item(i,1).text()
                break
        key_value=(operation_day,crop,operation,operator)
        #print operator
        return key_value

    def populate_tablewidget_operator(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select id ,operator,operator_class from operator_record_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tablewidget_operator.clear()
        self.ui.tablewidget_operator.setSortingEnabled(True)
        headers=["id",u"作業者名",u"区分"]
        self.ui.tablewidget_operator.setColumnCount(len(headers))
        self.ui.tablewidget_operator.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_operator.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_operator.setRowCount(row_count)
        i=0

        for row in rows:

            self.ui.tablewidget_operator.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_operator.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tablewidget_operator.setItem(i,2,QTableWidgetItem(row[2]))
            i=i+1
        self.ui.tablewidget_operator.resizeColumnsToContents()
        self.ui.tablewidget_operator.hideColumn(0)

        cursor.close()
        db.close()

    def populate_tablewidget_machine(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select id ,machine from machine_use_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tablewidget_machine.clear()
        self.ui.tablewidget_machine.setSortingEnabled(True)
        headers=["id",u"機械名"]
        self.ui.tablewidget_machine.setColumnCount(len(headers))
        self.ui.tablewidget_machine.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_machine.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_machine.setRowCount(row_count)
        i=0

        for row in rows:

            self.ui.tablewidget_machine.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_machine.setItem(i,1,QTableWidgetItem(row[1]))

            i=i+1
        self.ui.tablewidget_machine.resizeColumnsToContents()
        self.ui.tablewidget_machine.hideColumn(0)

        cursor.close()
        db.close()

    def populate_tablewidget_material(self,key_value):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(""" select id ,material,material_use_amount from material_use_table where operation_day=? and crop=? and operation=? and operator_main=?""",key_value)
        rows=cursor.fetchall()
        row_count=len(rows)


        self.ui.tablewidget_material.clear()
        self.ui.tablewidget_material.setSortingEnabled(True)
        headers=["id",u"資材名",u"使用量",u"使用単位"]
        self.ui.tablewidget_material.setColumnCount(len(headers))
        self.ui.tablewidget_material.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_material.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_material.setRowCount(row_count)
        i=0

        for row in rows:
            self.ui.tablewidget_material.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_material.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tablewidget_material.setItem(i,2,QTableWidgetItem(str(row[2])))

            self.ui.tablewidget_material.setItem(i,3,QTableWidgetItem(proc.get_material_master(row[1],key_value[1])[1]))
            i=i+1
        self.ui.tablewidget_material.resizeColumnsToContents()
        self.ui.tablewidget_material.hideColumn(0)

        cursor.close()
        db.close()


    def export_all_csv(self):
        self.export_main_csv()
        self.export_operator_csv()
        self.export_machine_csv()
        self.export_material_csv()


    def export_main_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return

        crop=self.ui.cmbbox_crop.currentText()
        year=self.year

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/トレサ出力"):
            os.mkdir(path+u"/トレサ出力")
        path+=u"/トレサ出力"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+u'_圃場別全作業実施履歴')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation from cultivation_calendar_master where  crop= ?  ",(crop,))
        rows=cursor.fetchall()
        list_operation=[]
        for row in rows:
            list_operation.append(row[0])


        list_csv=[]
        title1="pkuid"
        title2=u"地区名"
        title3=u"圃場名"
        title4=u"品種"
        title5=u"作付面積"

        #list_title=[title1,title2,title3,title4,title5]
        list_title=[title1.encode('"cp932"'),title2.encode('"cp932"'),title3.encode('"cp932"'),title4.encode('"cp932"'),title5.encode('"cp932"')]

        #sjis_list_operation = [s.encode("sjis") for s in list_operation]
        #list_title.extend(sjis_list_operation)
        for s in list_operation:
            s1=s+u"_作業実施日"
            s2=s+u"_作業実施者"
            list_title.extend([s1.encode("sjis")])
            list_title.extend([s2.encode("sjis")])


        #sjis_list_title = [unicode(s, "utf8").encode("sjis") for s in list_title]
        list_csv.append(list_title)
        #対象作物の作付圃場を抽出
        query_string='select farmland_table.pkuid,farmland_table.district,farmland_table.farmland_code,cropping_table.variety,cropping_table.crop_area \
            from farmland_table inner join cropping_table on farmland_table.farmland_code = cropping_table.farmland_code \
            where cropping_table.year=? and cropping_table.crop=? '
        cursor=db.cursor()
        cursor.execute(query_string,(self.year,crop))
        rows=cursor.fetchall()
        #圃場毎に作業の進捗状況を検索→リスト化
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'進捗状況')
        max = len(rows)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(1, max)
        widget.show()
        widget.raise_()
        i=1
        pbar.setValue(i)
        for row in rows:
            i=i+1
            pbar.setValue(i)
            csv_row=[]
            field1=row[0]
            field2=row[1]
            field3=row[2]
            field4=row[3]
            field5=row[4]
            csv_row.append(field1)
            try:
                csv_row.append(field2.encode('"cp932"'))
            except:
                csv_row.append("")
            csv_row.append(field3.encode('"cp932"'))
            csv_row.append(field4.encode('"cp932"'))
            csv_row.append(field5)

            for operation in list_operation:
                #progress=self.get_progress(self.year, crop, operation, row[2])
                try:
                    date_operator=self.get_date_and_operator(self.year, crop, operation, row[2])[0]
                    #print progress
                except:
                    date_operator=[u"未計画",u"未計画"]
                    #print "false"


               # csv_row.append(progress)
                try:
                    operation_day=date_operator[0].encode('"cp932"')
                except:
                    operation_day=u"未実施"
                    operation_day=operation_day.encode('"cp932"')
                try:
                    operator=date_operator[1].encode('"cp932"')
                except:
                    operator=u"未実施"
                    operator=operator.encode('"cp932"')
                #print operation_day
                #print operator
                csv_row.append(operation_day)
                csv_row.append(operator)

            #print csv_row
            #sjis_csv_row = [unicode(s, "utf8").encode("sjis") for s in csv_row]
            list_csv.append(csv_row)

        import types
        #print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

#         if sys.platform == "win32":
#             os.startfile(filename)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename])


    def get_date_and_operator(self,year,crop,operation,farmland_code):
        query_string='select operation_day,operator from operation_table  \
            where year=? and crop=?  and operation=? and farmland_code=?'
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(query_string,(year,crop,operation,farmland_code))
        rows=cursor.fetchall()

        return rows

    def export_operator_csv(self):


        crop=self.ui.cmbbox_crop.currentText()
        year=self.year

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/トレサ出力"):
            os.mkdir(path+u"/トレサ出力")
        path+=u"/トレサ出力"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+u'_作業者詳細')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation,operation_day,operator,operator_class from operator_record_table where  crop= ? and year=? ",(crop,self.year))
        rows=cursor.fetchall()
        list_csv=[]
        #title1="pkuid"
        title2=u"作業"
        title3=u"作業実施日"
        title4=u"作業者"
        title5=u"作業者区分"

        #list_title=[title1,title2,title3,title4,title5]
        list_title=[title2.encode('"cp932"'),title3.encode('"cp932"'),title4.encode('"cp932"'),title5.encode('"cp932"')]
        list_csv.append(list_title)
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'進捗状況')
        max = len(rows)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(1, max)
        widget.show()
        widget.raise_()
        i=1
        pbar.setValue(i)
        for row in rows:
            i=i+1
            pbar.setValue(i)
            csv_row=[]
            field1=row[0]
            field2=row[1]
            field3=row[2]
            field4=row[3]
            csv_row.append(field1.encode('"cp932"'))
            csv_row.append(field2.encode('"cp932"'))
            csv_row.append(field3.encode('"cp932"'))
            csv_row.append(field4.encode('"cp932"'))
            list_csv.append(csv_row)

        import types
        #print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

#         if sys.platform == "win32":
#             os.startfile(filename)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename])

    def export_machine_csv(self):


        crop=self.ui.cmbbox_crop.currentText()
        year=self.year

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/トレサ出力"):
            os.mkdir(path+u"/トレサ出力")
        path+=u"/トレサ出力"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+u'_使用機械詳細')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation,operation_day,operator_main,machine from machine_use_table where  crop= ? and year=? ",(crop,self.year))
        rows=cursor.fetchall()
        list_csv=[]
        #title1="pkuid"
        title2=u"作業"
        title3=u"作業実施日"
        title4=u"作業者"
        title5=u"使用機械"

        #list_title=[title1,title2,title3,title4,title5]
        list_title=[title2.encode('"cp932"'),title3.encode('"cp932"'),title4.encode('"cp932"'),title5.encode('"cp932"')]
        list_csv.append(list_title)
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'進捗状況')
        max = len(rows)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(1, max)
        widget.show()
        widget.raise_()
        i=1
        pbar.setValue(i)
        for row in rows:
            i=i+1
            pbar.setValue(i)
            csv_row=[]
            field1=row[0]
            field2=row[1]
            field3=row[2]
            field4=row[3]
            csv_row.append(field1.encode('"cp932"'))
            csv_row.append(field2.encode('"cp932"'))
            csv_row.append(field3.encode('"cp932"'))
            csv_row.append(field4.encode('"cp932"'))
            list_csv.append(csv_row)

        import types
        #print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

#         if sys.platform == "win32":
#             os.startfile(filename)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename])

    def export_material_csv(self):


        crop=self.ui.cmbbox_crop.currentText()
        year=self.year

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/トレサ出力"):
            os.mkdir(path+u"/トレサ出力")
        path+=u"/トレサ出力"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+u'_使用資材詳細')
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation,operation_day,operator_main,material,material_use_amount from material_use_table where  crop= ? and year=? ",(crop,self.year))
        rows=cursor.fetchall()
        list_csv=[]
        #title1="pkuid"
        title2=u"作業"
        title3=u"作業実施日"
        title4=u"作業者"
        title5=u"使用資材"
        title6=u"使用量"
        title7=u"資材単位"

        #list_title=[title1,title2,title3,title4,title5]
        list_title=[title2.encode('"cp932"'),title3.encode('"cp932"'),title4.encode('"cp932"'),title5.encode('"cp932"'),title6.encode('"cp932"'),title7.encode('"cp932"')]
        list_csv.append(list_title)
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'進捗状況')
        max = len(rows)
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(1, max)
        widget.show()
        widget.raise_()
        i=1
        pbar.setValue(i)
        for row in rows:
            i=i+1
            pbar.setValue(i)
            csv_row=[]
            field1=row[0]
            field2=row[1]
            field3=row[2]
            field4=row[3]
            field5=row[4]
            csv_row.append(field1.encode('"cp932"'))
            csv_row.append(field2.encode('"cp932"'))
            csv_row.append(field3.encode('"cp932"'))
            csv_row.append(field4.encode('"cp932"'))
            csv_row.append(field5)
            #print row[3]
            unit=pyqgis_processing.get_material_master(row[3],crop)[0]
            #print unit
            csv_row.append(unit.encode('"cp932"'))
            list_csv.append(csv_row)

        import types
        #print type(list_csv[0][1])
        dataWriter.writerows(list_csv)
        table_csv.close()

#         if sys.platform == "win32":
#             os.startfile(filename)
#         else:
#             opener ="open" if sys.platform == "darwin" else "xdg-open"
#             subprocess.call([opener, filename])
        msg=u"""履歴一覧を%sに出力しました """ %(path)
        pyqgis_processing.show_msgbox(msg)
