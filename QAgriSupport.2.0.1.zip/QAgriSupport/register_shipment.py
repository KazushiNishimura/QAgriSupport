# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from register_shipment_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import csv
import os, sys, subprocess

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.year=y
        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.cropping_table=proc.get_cropping_table()
        self.contract_table=proc.get_contract_table()

        #proc.remove_join()
#         proc.clear_query(self.farmland_table)
#         proc.clear_query(self.operation_table)
#         proc.clear_query(self.cropping_table)
#         proc.clear_query(self.contract_table)
#         proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\' or "kind"=\'受託地\'')
# #         proc.set_query(self.operation_table,'"year"='+str(self.year))
#         proc.set_query(self.cropping_table,'"year"='+str(self.year))
#         proc.set_query(self.contract_table,'"year"='+str(self.year))

        #proc.add_join_operation_table()
        #proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\'  and  "operation_table_progress" =\'未完了\' ')

#         proc.hide_all_columns(self.farmland_table)
#         proc.set_column_visibility(self.farmland_table, 'operation_table_operator', True)
#         proc.set_column_visibility(self.farmland_table, 'operation_table_operation_day', True)
#         proc.set_column_visibility(self.farmland_table, 'operation_table_progress', True)


#         proc.show_columns_farmland_table(self.farmland_table)
#         proc.show_columns_operation_table(self.farmland_table)
#         proc.set_alias_farmland_table(self.farmland_table)
#         proc.set_alias_operation_table(self.farmland_table)

#         self.ui.dateEdit_operation_day.setDate(datetime.date.today())
        self.populate_cmbbox_crop()
        self.populate_cmbbox_customer()
        self.ui.dtedit_shipment.setDate(datetime.date.today())
#         self.populate_cmbbox_stage()
#         self.populate_cmbbox_weed()
#         self.populate_cmbbox_stockyard()
#         self.populate_cmbbox_process()
#         self.populate_cmbbox_operator()
#         self.populate_table_suboperator()
#         self.populate_table_machine()
#
#
#         self.farmland_table.selectionChanged.connect(self.selection_changed)
        self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
        self.connect(self.ui.cmbbox_operation,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
        self.connect(self.ui.btn_open_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
#         self.connect(self.ui.btn_register,SIGNAL("clicked()"),self.update_info)
#         self.connect(self.ui.btn_open_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.btn_csv,SIGNAL("clicked()"),self.export_csv)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_record)
#             self.connect(self.ui.cmbbox_operation_term,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_term_change)
#         self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.render_map)
#         self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.check_variety)
        self.connect(self.ui.btn_register,SIGNAL("clicked()"),self.update_record)
#         self.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
#         self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
#         self.connect(self.ui.btn_add,SIGNAL("clicked()"),self.add_row)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
        self.farmland_table.selectionChanged.connect(self.populate_table_widget)


    def update_record(self):
        if self.ui.cmbbox_crop.currentText()=="":
            return
        if self.ui.cmbbox_operation.currentText()=="":
            return
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        customer=self.ui.cmbbox_customer.currentText()
        shipping_day=self.ui.dtedit_shipment.date().toString("yyyy/MM/dd")
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)


        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()

        for farmland in list_farmland:

            proc=pyqgis_processing
            db=proc.connect_db()
            cursor=db.cursor()
            if self.ui.cmbbox_crop.currentText()==u"受託":
                query="""select * from product_table where year=? and farmland_code=? and crop=? and operation=?  """
            else:
                query="""select * from product_table where year=? and farmland_code=? and crop=?  """
            if self.ui.cmbbox_crop.currentText()==u"受託":
                key=(self.year,farmland[1],crop,operation)
            else:
                key=(year,farmland[1],crop)
            cursor.execute(query,key)
            row=cursor.fetchone()
            new_row =None
            if row is None:
                if self.ui.cmbbox_crop.currentText()==u"受託":
                    new_row=(year,farmland[1],crop,operation,customer,shipping_day,1,1)
                    db.execute("""insert into product_table (year,farmland_code,crop,operation,customer_candidate,deliver_day,registered,registered2) values (?,?,?,?,?,?,?,?)""",new_row)
                else:
                    new_row=(year,farmland[1],crop,customer,shipping_day,1,1)
                    db.execute("""insert into product_table (year,farmland_code,crop,customer_candidate,deliver_day,registered,registered2) values (?,?,?,?,?,?,?)""",new_row)
            else:
                if self.ui.cmbbox_crop.currentText()==u"受託":
                    new_row=(customer,shipping_day,1,year,farmland[1],crop,operation)
                    db.execute("""update product_table  set customer_candidate=?,deliver_day=?,registered2=?
                     where year=? and farmland_code=? and crop=? and operation=?""",new_row)
                else:
                    new_row=(customer,shipping_day,1,year,farmland[1],crop)
                    db.execute("""update product_table  set  customer_candidate=?,deliver_day=?,registered2=?
                     where year=? and farmland_code=? and crop=?""",new_row)

            db.commit()
        db.close()

        self.populate_table_widget()



    def show_attribute_table(self):
        pyqgis_processing.clear_attributetable()
        lyr=self.farmland_table

        self.attribute_table=iface.showAttributeTable(lyr)



    def populate_table_widget(self):
        if self.ui.cmbbox_crop.currentText()=="":
            return
        crop=self.ui.cmbbox_crop.currentText()
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)

        row_count=len(list_farmland)
        self.ui.tablewidget_shipment.clear()
        self.ui.tablewidget_shipment.setSortingEnabled(True)
        self.ui.tablewidget_shipment.setRowCount(row_count)
        headers=[u"圃場名",u"ロール個数",u"出荷先",u"出荷日"]
        self.ui.tablewidget_shipment.setColumnCount(len(headers))
        self.ui.tablewidget_shipment.setHorizontalHeaderLabels(headers)

        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        i=0
        for farmland in list_farmland:
            query_string="select farmland_code,yield, customer_candidate,deliver_day from product_table where year=? and crop=? and farmland_code=?"

            key=(self.year,crop,farmland[1])

            cursor.execute(query_string,key)
            rows=cursor.fetchall()
            for row in rows:
                self.ui.tablewidget_shipment.setItem(i,0,QTableWidgetItem(row[0]))
                if row[1] is not None:
                    self.ui.tablewidget_shipment.setItem(i,1,QTableWidgetItem(str(row[1])))
                if row[2] is not None:
                    self.ui.tablewidget_shipment.setItem(i,2,QTableWidgetItem(row[2]))
                if row[3] is not None:
                    self.ui.tablewidget_shipment.setItem(i,3,QTableWidgetItem(row[3]))

                i=i+1
        self.ui.tablewidget_shipment.resizeColumnsToContents()



    def populate_cmbbox_customer(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select customer from customer_master")
        rows=cursor.fetchall()

        self.ui.cmbbox_customer.clear()
        self.ui.cmbbox_customer.addItem("")
        list_customer=[]
        for row in rows:
            if row[0] not in list_customer:
                list_customer.append(row[0])
                self.ui.cmbbox_customer.addItem(row[0])

        db.close()



    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()

        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmbbox_crop.addItem(row[0])

        db.close()
        self.ui.cmbbox_crop.addItem(u"受託")

    def cmbbox_crop_change(self):
        proc=pyqgis_processing
        if self.ui.cmbbox_crop.currentText()==u"受託":
            db=proc.connect_db()
            #crop=self.ui.cmbbox_crop.currentText()
            cursor=db.cursor()
            cursor.execute("select operation from contract_operation_master")
            rows=cursor.fetchall()
            self.ui.cmbbox_operation.clear()
            for row in rows:
                self.ui.cmbbox_operation.addItem(row[0])
            db.close()
        else:
            self.ui.cmbbox_operation.clear()
            self.ui.cmbbox_operation.addItem(u"指定不要")
            self.set_query_cropping_table()
            self.render_farmland_crop()

    def cmbbox_operate_change(self):
        proc=pyqgis_processing
        if self.ui.cmbbox_crop.currentText()==u"受託":
            self.set_query_contract_table()
            self.renderer_map_contract()

    def set_query_contract_table(self):
        pyqgis_processing.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        query_string= '\"year\" ='+ str(self.year) +' and ( '
        operation=self.ui.cmbbox_operation.currentText()
        query_string=query_string+ '\"operation\" ='+ '\''+ operation +'\''+')'
        pyqgis_processing.set_query(self.contract_table, query_string)
        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_contract_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_contract_table(self.farmland_table)

    def renderer_map_contract(self):
        layer=self.farmland_table
        operation =self.ui.cmbbox_operation.currentText()
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u""
        query_string= '\"contract_table_client\"  is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        rule=root_rule.children()[0].clone()
        rule.setLabel(u"受託登録圃場")
        query_string= '\"contract_table_client\"  is not None'
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)


        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()




    def render_farmland_crop(self):
        list_rule=[]
        crop=self.ui.cmbbox_crop.currentText()
        label_string=  crop
        query_string= """ "cropping_table_crop" ='%s' """ %(crop)
        list_rule.append([label_string,query_string])
        pyqgis_processing.renderer_map1(self.farmland_table, list_rule)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()


    def set_query_cropping_table(self):
        proc=pyqgis_processing
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.cropping_table)
        proc.set_query(self.farmland_table, u'"kind"=\'経営耕地\'')
        query_string= '\"year\" ='+ str(self.year) +' and  ' + '\"crop\" ='+ '\''+ self.ui.cmbbox_crop.currentText() +'\''
        pyqgis_processing.set_query(self.cropping_table, query_string)
        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_cropping_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_cropping_table(self.farmland_table)


    def export_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_crop.currentText()==u"受託":
            crop=u"受託"
            operation=self.ui.cmbbox_operation.currentText()
        else:
            crop=self.ui.cmbbox_crop.currentText()

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/製品出荷台帳"):
            os.mkdir(path+u"/製品出荷台帳")
        path+=u"/製品出荷台帳"
        if self.ui.cmbbox_crop.currentText()==u"受託":
            filename= path + "/"+"%s.csv"  % (str(self.year)+'_'+u'作業受託_'+self.ui.cmbbox_operation.currentText())
        else:
            filename= path + "/"+"%s.csv"  % (str(self.year)+'_'+self.ui.cmbbox_crop.currentText())
#         print path
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()

        crop=self.ui.cmbbox_crop.currentText()
        if crop==u"受託":
            operation=self.ui.cmbbox_operation.currentText()
            query="""select farmland_code,yield,customer_candidate,deliver_day
             from product_table where year=? and
            crop=? and operation=? and customer_candidate is not null """
            key=(self.year,crop,operation)
        else:
            query="""select farmland_code,yield,customer_candidate,deliver_day
             from product_table where year=? and
            crop=? and customer_candidate is not null"""
            key=(self.year,crop)

        cursor.execute(query,key)
        rows=cursor.fetchall()

        list_csv=[]
        field_name1=u"圃場名"
        field_name2=u"ロール個数"
        field_name3=u"出荷先"
        field_name4=u"出荷日"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),field_name4.encode('"cp932"')])
        for row in rows:
            field1=row[0].encode('"cp932"')

            if row[1] is None:
                field2=u""
            else:
                field2=row[1]

            if row[2] is None:
                field3=u""
            else:
                field3=row[2].encode('"cp932"')

            if row[3] is None:
                field4=u""
            else:
                field4=row[3].encode('"cp932"')


            list_csv.append([field1,field2,field3,field4])
            #print row[1]


        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])

        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/製品出荷台帳"):
            os.mkdir(path+u"/製品出荷台帳")
        path+=u"/製品出荷台帳"
        filename= path + "/"+"%s.csv"  % (str(self.year)+'_'+u'集計')

        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()

        crop=self.ui.cmbbox_crop.currentText()

        operation=self.ui.cmbbox_operation.currentText()
        query="""select crop,operation,customer_candidate,sum(yield)
         from product_table where year=? group by crop,operation,customer_candidate"""
        key=(self.year,)


        cursor.execute(query,key)
        rows=cursor.fetchall()

        list_csv=[]
        field_name1=u"作物名"
        field_name2=u"作業名"
        field_name3=u"出荷先"
        field_name4=u"出荷数"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),field_name4.encode('"cp932"')])
        for row in rows:
            field1=row[0].encode('"cp932"')

            if row[1] is None:
                field2=u""
            else:
                field2=row[1].encode('"cp932"')

            if row[2] is None:
                field3=u""
            else:
                field3=row[2].encode('"cp932"')

            if row[3] is None:
                field4=u""
            else:
                field4=row[3]


            list_csv.append([field1,field2,field3,field4])
            #print row[1]


        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])





