# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'register_shipment_ui.ui'
#
# Created: Mon Jun 29 15:10:49 2020
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(510, 828)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.cmbbox_crop = QtGui.QComboBox(self.groupBox)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.verticalLayout_2.addWidget(self.cmbbox_crop)
        self.verticalLayout.addWidget(self.groupBox)
        self.gbox_operation = QtGui.QGroupBox(Dialog)
        self.gbox_operation.setObjectName(_fromUtf8("gbox_operation"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.gbox_operation)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.cmbbox_operation = QtGui.QComboBox(self.gbox_operation)
        self.cmbbox_operation.setObjectName(_fromUtf8("cmbbox_operation"))
        self.verticalLayout_3.addWidget(self.cmbbox_operation)
        self.verticalLayout.addWidget(self.gbox_operation)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.groupBox_3)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.cmbbox_customer = QtGui.QComboBox(self.groupBox_3)
        self.cmbbox_customer.setObjectName(_fromUtf8("cmbbox_customer"))
        self.verticalLayout_4.addWidget(self.cmbbox_customer)
        self.verticalLayout.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.verticalLayout_5 = QtGui.QVBoxLayout(self.groupBox_4)
        self.verticalLayout_5.setObjectName(_fromUtf8("verticalLayout_5"))
        self.dtedit_shipment = QtGui.QDateEdit(self.groupBox_4)
        self.dtedit_shipment.setCalendarPopup(True)
        self.dtedit_shipment.setObjectName(_fromUtf8("dtedit_shipment"))
        self.verticalLayout_5.addWidget(self.dtedit_shipment)
        self.verticalLayout.addWidget(self.groupBox_4)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.verticalLayout_6 = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
        self.tablewidget_shipment = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_shipment.setObjectName(_fromUtf8("tablewidget_shipment"))
        self.tablewidget_shipment.setColumnCount(0)
        self.tablewidget_shipment.setRowCount(0)
        self.verticalLayout_6.addWidget(self.tablewidget_shipment)
        self.verticalLayout.addWidget(self.groupBox_2)
        self.btn_register = QtGui.QPushButton(Dialog)
        self.btn_register.setObjectName(_fromUtf8("btn_register"))
        self.verticalLayout.addWidget(self.btn_register)
        self.btn_open_attribute_table = QtGui.QPushButton(Dialog)
        self.btn_open_attribute_table.setObjectName(_fromUtf8("btn_open_attribute_table"))
        self.verticalLayout.addWidget(self.btn_open_attribute_table)
        self.btn_csv = QtGui.QPushButton(Dialog)
        self.btn_csv.setObjectName(_fromUtf8("btn_csv"))
        self.verticalLayout.addWidget(self.btn_csv)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "販売・出荷先の登録", None))
        self.groupBox.setTitle(_translate("Dialog", "作物名", None))
        self.gbox_operation.setTitle(_translate("Dialog", "作業名", None))
        self.groupBox_3.setTitle(_translate("Dialog", "販売先", None))
        self.groupBox_4.setTitle(_translate("Dialog", "出荷日", None))
        self.groupBox_2.setTitle(_translate("Dialog", "選択圃場の出荷登録状況", None))
        self.btn_register.setText(_translate("Dialog", "選択圃場に販売先を登録", None))
        self.btn_open_attribute_table.setText(_translate("Dialog", "属性テーブルを開く", None))
        self.btn_csv.setText(_translate("Dialog", "CSVに出力", None))

