# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'tsp_generic_ui.ui'
#
# Created: Thu Oct 29 14:28:40 2020
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(494, 506)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_make_route = QtGui.QPushButton(Dialog)
        self.btn_make_route.setObjectName(_fromUtf8("btn_make_route"))
        self.verticalLayout.addWidget(self.btn_make_route)
        self.tablewdget_route = QtGui.QTableWidget(Dialog)
        self.tablewdget_route.setObjectName(_fromUtf8("tablewdget_route"))
        self.tablewdget_route.setColumnCount(0)
        self.tablewdget_route.setRowCount(0)
        self.verticalLayout.addWidget(self.tablewdget_route)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "最短経路探索", None))
        self.btn_make_route.setText(_translate("Dialog", "経路を探索する", None))

