# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtSql import QSqlTableModel
from shipping_plan_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing
import datetime

class Dialog(QDialog,Ui_Dialog):

    def __init__(self,iface,year):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=year

        self.setWindowFlags(Qt.WindowStaysOnTopHint)

#         self.ui.dateEdit.setDate(datetime.date.today())
#         self.ui.dateEdit_2.setDate(datetime.date.today())
#         self.ui.dateEdit_3.setDate(datetime.date.today())
#         self.ui.dateEdit_4.setDate(datetime.date.today())

        self.populate_cmbbox()
        self.populate_cmbbox2()

        self.connect(self.ui.cmb_box_crop, SIGNAL("currentIndexChanged(const QString&)"),self.populate_table)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.ui.tablewidget_shipping.itemSelectionChanged.connect(self.selection_changed)
        self.connect(self.ui.btn_edit,SIGNAL("clicked()"),self.update_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
    def populate_cmbbox(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()

        self.ui.cmb_box_crop.clear()
        self.ui.cmb_box_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmb_box_crop.addItem(row[0])

    def populate_cmbbox2(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=db.cursor()
        cursor.execute("select customer from customer_master")
        rows=cursor.fetchall()

        self.ui.cmb_box_customor.clear()
        self.ui.cmb_box_customor.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmb_box_customor.addItem(row[0])


    def populate_table(self):
        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")


        cursor=db.cursor()

        cursor.execute('select id ,customer,shipments from shipping_plan_table  where year=? and crop= ?', (self.year,self.ui.cmb_box_crop.currentText()))
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tablewidget_shipping.clear()
        self.ui.tablewidget_shipping.setSortingEnabled(True)
        self.ui.tablewidget_shipping.setRowCount(row_count)
        headers=["id",u"販売先",u"個数"]
        self.ui.tablewidget_shipping.setColumnCount(len(headers))
        self.ui.tablewidget_shipping.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_shipping.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_shipping.setSelectionBehavior(QAbstractItemView.SelectRows)
        i=0
        for row in rows:
            self.ui.tablewidget_shipping.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.tablewidget_shipping.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.tablewidget_shipping.setItem(i,2,QTableWidgetItem(str(row[2])))

            i=i+1
        self.ui.tablewidget_shipping.resizeColumnsToContents()
        self.ui.tablewidget_shipping.hideColumn(0)

        cursor.close()
        db.close()

    def insert_row(self):
        if self.ui.cmb_box_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"作物を選択してください")
            return
        if self.ui.cmb_box_customor.currentText()=="":
            pyqgis_processing.show_msgbox(u"販売先を選択してください")
            return
        path=pyqgis_processing.get_prj_path()
        connect_db=sqlite3.connect(path+"/"+"management_db.sqlite")
        crop=self.ui.cmb_box_crop.currentText()
        customer=self.ui.cmb_box_customor.currentText()
        shipments=self.ui.spbox_quantity.value()
        new_row=(self.year,crop,customer,shipments)
        connect_db.execute('insert into shipping_plan_table (year,crop,customer,shipments) values (?,?,?,?)',new_row)
        connect_db.commit()

        self.populate_table()

    def selection_changed(self):

        rows=[]
        for index in self.ui.tablewidget_shipping.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        for row in rows:
            #print self.ui.tablewidget_cultivation.item(row,1).text()
            self.ui.spbox_quantity2.setValue(int(self.ui.tablewidget_shipping.item(row,2).text()))


    def update_row(self):
        if self.ui.cmb_box_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"作物を選択してください")
            return
        if self.ui.cmb_box_customor.currentText()=="":
            pyqgis_processing.show_msgbox(u"販売先を選択してください")
            return
        path=pyqgis_processing.get_prj_path()
        connect_db=sqlite3.connect(path+"/"+"management_db.sqlite")
        cursor=connect_db.cursor()
        rows=[]
        for index in self.ui.tablewidget_shipping.selectedIndexes():
            if index.column()==1:
                rows.append(index.row())
        if len(rows)==0:
            pyqgis_processing.show_msgbox(u"対象出荷計画を選択してください")
            return

        for row in rows:
            shipments=self.ui.spbox_quantity2.value()
            id_=int(self.ui.tablewidget_shipping.item(row,0).text())
            cursor.execute('update shipping_plan_table set shipments=? where id=?',(shipments,id_,))
            self.ui.tablewidget_shipping.setItem(row,2,QTableWidgetItem(str(shipments)))

        connect_db.commit()
        connect_db.close()

    def delete_row(self):
        path=pyqgis_processing.get_prj_path()
        connect_db=sqlite3.connect(path+"/"+"management_db.sqlite")
        for i in range(0,self.ui.tablewidget_shipping.rowCount()):
            if self.ui.tablewidget_shipping.item(i,0).isSelected()==True:
                connect_db.execute('delete from shipping_plan_table where id = ?',(int(self.ui.tablewidget_shipping.item(i,0).text()),))


        connect_db.commit()
        connect_db.close()

        self.populate_table()






