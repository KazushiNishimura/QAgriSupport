# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtCore import QVariant
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from tsp_generic_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime
import math

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()
        self.cropping_table=proc.get_cropping_table()


        self.connect(self.ui.btn_make_route,SIGNAL("clicked()"),self.make_route)
#         self.connect(self.ui.btn_write_geom,SIGNAL("clicked()"),self.calc_xy)
        self.ui.tablewdget_route.itemSelectionChanged.connect(self.select_landfields)

    def make_route(self):
        list_farmlandcode=[]
        for feature in self.farmland_table.selectedFeatures():
            list_farmlandcode.append([feature.id(),feature['farmland_code'],feature['land_area']])
        if len(list_farmlandcode)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        from land_management_tsp1 import run_simple_tsp
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if lyr.name()=='farmland_table':
                layer1=lyr
                break
        land_list=[]
        for feature in self.farmland_table.selectedFeatures():
            geom=QgsGeometry(feature.geometry())
            cgeom=geom.centroid()
            point=cgeom.asPoint()
#             land_list.append([feature[feature.fieldNameIndex('X')],feature[feature.fieldNameIndex('Y')],feature.id()])
            land_list.append([point.x(),point.y(),feature.id()])
            #print feature.id()
        best_route=run_simple_tsp(land_list)
        qpoint=[]

        for point in best_route:
            qpoint.append(QgsPoint(float(point[2]),float(point[3])))

        line=QgsGeometry.fromPolyline(qpoint)
        f=QgsFeature()
        f.setGeometry(line)
        crs = layer1.crs().authid()#toWkt()
        memlayer=QgsVectorLayer("LineString?crs=" + crs,u'経路','memory')
        renderer=memlayer.rendererV2()
        symb=renderer.symbol()
        symb.setWidth(2)
        mempr=memlayer.dataProvider()
        mempr.addFeatures([f])
        memlayer.updateExtents()
        QgsMapLayerRegistry.instance().addMapLayers([memlayer])

        self.populate_table(best_route)

        dist=0
        for i in xrange(0,len(best_route)-2):
            land_from=best_route[i]
            land_to=best_route[i+1]
            distance_x = abs(land_from[2]-land_to[2])
            distance_y = abs(land_from[3]-land_to[3])
            dist_part = math.sqrt( (distance_x*distance_x) + (distance_y*distance_y) )
            dist=dist+dist_part

#         print dist


#         for point in best_route:
#             print  point[0],point[1]

    def populate_table(self,best_route):
        self.ui.tablewdget_route.clear()
        self.ui.tablewdget_route.setSortingEnabled(True)
        headers=[u"順序",u"id",u"圃場名",u"面積"]
        self.ui.tablewdget_route.setColumnCount(len(headers))
        self.ui.tablewdget_route.setHorizontalHeaderLabels(headers)
        self.ui.tablewdget_route.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewdget_route.setRowCount(0)


        for land in best_route:
            i=0
            #idから圃場めいと面性を取得
#             self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression('"" = \'Canada\''))
            fids = [land[1]]
            request = QgsFeatureRequest()
            request.setFilterFids(fids)
            features = self.farmland_table.getFeatures(request)
            farmland=features.next()
            farmland_code=farmland["farmland_code"]
            land_area=farmland["land_area"]
            self.ui.tablewdget_route.insertRow(i)
            self.ui.tablewdget_route.setItem(i,0,QTableWidgetItem('{:0=5}'.format(land[0])))
            self.ui.tablewdget_route.setItem(i,1,QTableWidgetItem(str(land[1])))
            self.ui.tablewdget_route.setItem(i,2,QTableWidgetItem(farmland_code))
            self.ui.tablewdget_route.setItem(i,3,QTableWidgetItem(str(int(land_area))))

            i=i+1

    def select_landfields(self):
        proc=pyqgis_processing
        ids=self.return_select_ids()
        print ids
        self.farmland_table.setSelectedFeatures(ids)



    def return_select_ids(self):
        row_count=self.ui.tablewdget_route.rowCount()
        select_ids=[]
        id=0
        for i in range(row_count):
            if self.ui.tablewdget_route.item(i,1).isSelected()==True:
                id=int(self.ui.tablewdget_route.item(i,1).text())
                select_ids.append(id)
#                 print id
#         print select_ids
        return select_ids

    def check_table(self):
        #XY座標の存在確認
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor = db.execute("PRAGMA table_info('%s')" % "farmland_table")
        res = cursor.fetchall()
        i = 0
        while i < len(res):
            if res[i][1] == "X": break
            i += 1
#         print i
#         print len(res)
        if i == len(res): #存在してないので作る,プログラム的には無理かも
#             print u"作成"
#             cursor = db.execute("ALTER TABLE %s ADD COLUMN %s float" % ("farmland_table","X"))
#             self.farmland_table.isValid()
#             self.farmland_table.dataProvider().addAttributes([QgsField("X", QVariant.Double), QgsField("Y", QVariant.Double)])
            self.farmland_table.startEditing()
            self.farmland_table.addAttribute(QgsField("X", QVariant.Double))
            self.farmland_table.addAttribute(QgsField("Y", QVariant.Double))
#             self.farmland_table.addAttributes([QgsField("X", QVariant.Double), QgsField("Y", QVariant.Double)])
#             db.commit()
#             cursor = db.execute("ALTER TABLE %s ADD COLUMN %s float" % ("farmland_table","Y"))
#             db.commit()
#         self.farmland_table.updateFields()
            self.farmland_table.updateFields()
            self.farmland_table.endEditCommand()


    def calc_xy(self):
        self.check_table()
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'XY座標計算中')
        _max = self.farmland_table.featureCount()
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, _max)

        widget.show()
        widget.raise_()
        self.farmland_table.startEditing()
        i=1
        features=self.farmland_table.getFeatures()
        for feature in features:
            pbar.setValue(i)
            geom=QgsGeometry(feature.geometry())
            cgeom=geom.centroid()
            point=cgeom.asPoint()
            feature[feature.fieldNameIndex('X')]=point.x()
            feature[feature.fieldNameIndex('Y')]=point.y()
            self.farmland_table.updateFeature(feature)
            i=i+1
        self.farmland_table.commitChanges()
        self.farmland_table.endEditCommand()








#
#