# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_client_ui.ui'
#
# Created: Wed Jan 11 18:27:56 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(400, 430)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tableWidget_client = QtGui.QTableWidget(Dialog)
        self.tableWidget_client.setObjectName(_fromUtf8("tableWidget_client"))
        self.tableWidget_client.setColumnCount(0)
        self.tableWidget_client.setRowCount(0)
        self.gridLayout_2.addWidget(self.tableWidget_client, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.btn_insert = QtGui.QPushButton(self.groupBox_2)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_4.addWidget(self.btn_insert, 4, 1, 1, 1)
        self.lineEdit = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.gridLayout_4.addWidget(self.lineEdit, 1, 1, 1, 1)
        self.label = QtGui.QLabel(self.groupBox_2)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_4.addWidget(self.label, 1, 0, 1, 1)
        self.gridLayout_2.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn_delete = QtGui.QPushButton(self.groupBox)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_3.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.gridLayout_2.addWidget(self.groupBox, 2, 0, 1, 1)
        self.gridLayout.addLayout(self.gridLayout_2, 0, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.groupBox_2.setTitle(_translate("Dialog", "作業委託者登録", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.label.setText(_translate("Dialog", "委託者名", None))
        self.groupBox.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

