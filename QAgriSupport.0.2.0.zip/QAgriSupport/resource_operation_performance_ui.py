# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'resource_operation_performance_ui.ui'
#
# Created: Fri May 26 14:26:25 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(433, 251)
        self.formLayout_4 = QtGui.QFormLayout(Dialog)
        self.formLayout_4.setObjectName(_fromUtf8("formLayout_4"))
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.formLayout_2 = QtGui.QFormLayout(self.groupBox_3)
        self.formLayout_2.setObjectName(_fromUtf8("formLayout_2"))
        self.gbox_year1 = QtGui.QGroupBox(self.groupBox_3)
        self.gbox_year1.setCheckable(True)
        self.gbox_year1.setObjectName(_fromUtf8("gbox_year1"))
        self.formLayout_3 = QtGui.QFormLayout(self.gbox_year1)
        self.formLayout_3.setObjectName(_fromUtf8("formLayout_3"))
        self.spbox_year = QtGui.QSpinBox(self.gbox_year1)
        self.spbox_year.setMaximum(9999)
        self.spbox_year.setObjectName(_fromUtf8("spbox_year"))
        self.formLayout_3.setWidget(0, QtGui.QFormLayout.SpanningRole, self.spbox_year)
        self.formLayout_2.setWidget(0, QtGui.QFormLayout.LabelRole, self.gbox_year1)
        self.gbox_year2 = QtGui.QGroupBox(self.groupBox_3)
        self.gbox_year2.setEnabled(True)
        self.gbox_year2.setCheckable(True)
        self.gbox_year2.setChecked(False)
        self.gbox_year2.setObjectName(_fromUtf8("gbox_year2"))
        self.formLayout = QtGui.QFormLayout(self.gbox_year2)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))
        self.spbox_year_2 = QtGui.QSpinBox(self.gbox_year2)
        self.spbox_year_2.setEnabled(True)
        self.spbox_year_2.setMaximum(9999)
        self.spbox_year_2.setObjectName(_fromUtf8("spbox_year_2"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.spbox_year_2)
        self.chkbox_crop = QtGui.QCheckBox(self.gbox_year2)
        self.chkbox_crop.setEnabled(True)
        self.chkbox_crop.setObjectName(_fromUtf8("chkbox_crop"))
        self.formLayout.setWidget(3, QtGui.QFormLayout.LabelRole, self.chkbox_crop)
        self.cmbbox_crop = QtGui.QComboBox(self.gbox_year2)
        self.cmbbox_crop.setEnabled(False)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.formLayout.setWidget(3, QtGui.QFormLayout.FieldRole, self.cmbbox_crop)
        self.chkbox_operation = QtGui.QCheckBox(self.gbox_year2)
        self.chkbox_operation.setEnabled(False)
        self.chkbox_operation.setObjectName(_fromUtf8("chkbox_operation"))
        self.formLayout.setWidget(4, QtGui.QFormLayout.LabelRole, self.chkbox_operation)
        self.cmbbox_operation = QtGui.QComboBox(self.gbox_year2)
        self.cmbbox_operation.setEnabled(False)
        self.cmbbox_operation.setObjectName(_fromUtf8("cmbbox_operation"))
        self.formLayout.setWidget(4, QtGui.QFormLayout.FieldRole, self.cmbbox_operation)
        self.label = QtGui.QLabel(self.gbox_year2)
        self.label.setObjectName(_fromUtf8("label"))
        self.formLayout.setWidget(1, QtGui.QFormLayout.LabelRole, self.label)
        self.formLayout_2.setWidget(0, QtGui.QFormLayout.FieldRole, self.gbox_year2)
        self.formLayout_4.setWidget(1, QtGui.QFormLayout.SpanningRole, self.groupBox_3)
        self.btn_print = QtGui.QPushButton(Dialog)
        self.btn_print.setObjectName(_fromUtf8("btn_print"))
        self.formLayout_4.setWidget(2, QtGui.QFormLayout.FieldRole, self.btn_print)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.rbtn_operator = QtGui.QRadioButton(self.groupBox)
        self.rbtn_operator.setChecked(True)
        self.rbtn_operator.setObjectName(_fromUtf8("rbtn_operator"))
        self.horizontalLayout.addWidget(self.rbtn_operator)
        self.rbtn_machine = QtGui.QRadioButton(self.groupBox)
        self.rbtn_machine.setObjectName(_fromUtf8("rbtn_machine"))
        self.horizontalLayout.addWidget(self.rbtn_machine)
        self.formLayout_4.setWidget(0, QtGui.QFormLayout.SpanningRole, self.groupBox)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "要員･機械稼動実績", None))
        self.groupBox_3.setTitle(_translate("Dialog", "データ抽出方法", None))
        self.gbox_year1.setTitle(_translate("Dialog", "対象年から抽出する", None))
        self.gbox_year2.setTitle(_translate("Dialog", "年度・作物・作業で絞り込む", None))
        self.chkbox_crop.setText(_translate("Dialog", "作物で絞り込む", None))
        self.chkbox_operation.setText(_translate("Dialog", "作業で絞り込む", None))
        self.label.setText(_translate("Dialog", "対象年度", None))
        self.btn_print.setText(_translate("Dialog", "出力", None))
        self.groupBox.setTitle(_translate("Dialog", "対象", None))
        self.rbtn_operator.setText(_translate("Dialog", "要員", None))
        self.rbtn_machine.setText(_translate("Dialog", "機械", None))

