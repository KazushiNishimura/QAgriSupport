# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'rm_plan_ui.ui'
#
# Created: Fri Jan 18 13:03:14 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(400, 300)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.cmbbox_operation = QtGui.QComboBox(self.groupBox)
        self.cmbbox_operation.setObjectName(_fromUtf8("cmbbox_operation"))
        self.horizontalLayout.addWidget(self.cmbbox_operation)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.tablewidget_plan = QtGui.QTableWidget(Dialog)
        self.tablewidget_plan.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_plan.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_plan.setObjectName(_fromUtf8("tablewidget_plan"))
        self.tablewidget_plan.setColumnCount(0)
        self.tablewidget_plan.setRowCount(0)
        self.gridLayout.addWidget(self.tablewidget_plan, 1, 0, 1, 1)
        self.btn_update = QtGui.QPushButton(Dialog)
        self.btn_update.setObjectName(_fromUtf8("btn_update"))
        self.gridLayout.addWidget(self.btn_update, 2, 0, 1, 1)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.gridLayout.addWidget(self.btn_export_csv, 3, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "播種～収穫予定日推定", None))
        self.groupBox.setTitle(_translate("Dialog", "対象作業", None))
        self.btn_update.setText(_translate("Dialog", "選択行の更新", None))
        self.btn_export_csv.setText(_translate("Dialog", "CSVへの出力", None))

