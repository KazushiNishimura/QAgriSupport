# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'tsp_make_route_ui.ui'
#
# Created: Fri Jan 18 15:03:04 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(369, 655)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.mGroupBox = QgsCollapsibleGroupBox(Dialog)
        self.mGroupBox.setObjectName(_fromUtf8("mGroupBox"))
        self.gridLayout = QtGui.QGridLayout(self.mGroupBox)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox = QtGui.QGroupBox(self.mGroupBox)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.rbtn_new = QtGui.QRadioButton(self.groupBox)
        self.rbtn_new.setObjectName(_fromUtf8("rbtn_new"))
        self.verticalLayout.addWidget(self.rbtn_new)
        self.lineedit_route_name = QtGui.QLineEdit(self.groupBox)
        self.lineedit_route_name.setObjectName(_fromUtf8("lineedit_route_name"))
        self.verticalLayout.addWidget(self.lineedit_route_name)
        self.rbtn_update = QtGui.QRadioButton(self.groupBox)
        self.rbtn_update.setObjectName(_fromUtf8("rbtn_update"))
        self.verticalLayout.addWidget(self.rbtn_update)
        self.tablewidget_route = QtGui.QTableWidget(self.groupBox)
        self.tablewidget_route.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_route.setObjectName(_fromUtf8("tablewidget_route"))
        self.tablewidget_route.setColumnCount(0)
        self.tablewidget_route.setRowCount(0)
        self.verticalLayout.addWidget(self.tablewidget_route)
        self.btn_start = QtGui.QPushButton(self.groupBox)
        self.btn_start.setObjectName(_fromUtf8("btn_start"))
        self.verticalLayout.addWidget(self.btn_start)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.verticalLayout_2.addWidget(self.mGroupBox)
        self.tablewidget_farmland = QtGui.QTableWidget(Dialog)
        self.tablewidget_farmland.setObjectName(_fromUtf8("tablewidget_farmland"))
        self.tablewidget_farmland.setColumnCount(0)
        self.tablewidget_farmland.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tablewidget_farmland)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.groupBox.setTitle(_translate("Dialog", "最短経路の作成・呼び出し", None))
        self.rbtn_new.setText(_translate("Dialog", "新規に最短経路を作成する", None))
        self.rbtn_update.setText(_translate("Dialog", "既存の最短経路を呼び出す", None))
        self.btn_start.setText(_translate("Dialog", "作成・呼び出し", None))

#from qgscollapsiblegroupbox import QgsCollapsibleGroupBox
from qgis.gui import QgsCollapsibleGroupBox
