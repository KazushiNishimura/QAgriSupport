# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from print_operation_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.year=y
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()

        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\'')
        proc.set_query(self.operation_table,'"year"='+str(self.year))

        #proc.add_join_operation_table()

        proc.hide_all_columns(self.farmland_table)
        proc.set_column_visibility(self.farmland_table,'operation_table_operator',True)
        proc.set_column_visibility(self.farmland_table,'operation_table_operation_day',True)
        proc.set_column_visibility(self.farmland_table,'operation_table_progress',True)

        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        self.populate_cmbbox_crop()


        #self.populate_table_material()


        self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
        self.connect(self.ui.cmbbox_operation,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operation_change)
        self.connect(self.ui.cmbbox_operation_term,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_term_change)
        self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.render_map)
        self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.check_variety)
        self.connect(self.ui.btn_print,SIGNAL("clicked()"),self.print_map)
        self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
        self.connect(self.ui.btn_csv,SIGNAL("clicked()"),self.export_csv)

    def check_variety(self):
        if self.ui.chkbox_variety.checkState()==Qt.Checked:
            #self.add_rule_variety()
            pyqgis_processing.add_rule_variety(self.ui.cmbbox_crop.currentText())
            #print self.ui.chkbox_variety.checkState()
        elif self.ui.chkbox_variety.checkState()==Qt.Unchecked:
            #self.remove_variety()
            self.render_map()
           # print self.ui.chkbox_variety.checkState()

    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()
        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmbbox_crop.addItem(row[0])

        db.close()

    def populate_cmbbox_operation(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        crop=self.ui.cmbbox_crop.currentText()
        cursor=db.cursor()
        cursor.execute("select operation from cultivation_calendar_master where crop=?",(crop,))
        rows=cursor.fetchall()
        self.ui.cmbbox_operation.clear()
        for row in rows:
            self.ui.cmbbox_operation.addItem(row[0])

        db.close()

    def cmbbox_crop_change(self):
        self.populate_cmbbox_operation()

    def cmbbox_operation_change(self):
        self.populate_cmbbox_term()
        self.set_query_operation_table()

    def cmbbox_term_change(self):
        self.populate_cmbbox_operator_candidate()

    def populate_cmbbox_term(self):
        self.ui.cmbbox_operation_term.clear()
        list_schedule=[]
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        cursor.execute("select operation_schedule from operation_table where year=? and crop=? and operation=?",(year ,crop,operation,))
        rows=cursor.fetchall()
        for row in rows:
            if row[0] not in list_schedule:
                list_schedule.append(row[0])

        for item in list_schedule:
            self.ui.cmbbox_operation_term.addItem(item)

        db.close()

    def populate_cmbbox_operator_candidate(self):
        self.ui.cmbbox_operator_candidate.clear()
        proc=pyqgis_processing
        db=proc.connect_db()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        cursor=db.cursor()
        cursor.execute("select operator_candidate from operation_table where year=? and crop = ? and operation=? and operation_schedule=?",(year,crop,operation,term,))
        rows=cursor.fetchall()
        list_operator=[]
        for row in rows:
            if row[0] not in list_operator:
                list_operator.append(row[0])

        for item in list_operator:
            self.ui.cmbbox_operator_candidate.addItem(item)

        db.close()

    def render_map(self):

        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        operator=self.ui.cmbbox_operator_candidate.currentText()
        label_string=crop+":"+ operation+":"+term+":"+operator+u":未完了"

        query_string=u""""operation_table_crop" = '%s' and "operation_table_operation" ='%s'
        and "operation_table_operation_schedule" ='%s' and "operation_table_operator_candidate" ='%s'
        and "operation_table_progress" =  '未完了'""" %(crop,operation,term,operator)

        layer=self.farmland_table
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        root_rule.children()[0].setLabel(label_string)
        root_rule.children()[0].setFilterExpression(query_string)


        label_string=crop+":"+ operation+":"+term+":"+operator+u":完了"

        query_string=u""""operation_table_crop" = '%s' and "operation_table_operation" ='%s'
        and "operation_table_operation_schedule" ='%s' and "operation_table_operator_candidate" ='%s'
        and "operation_table_progress" =  '完了'""" %(crop,operation,term,operator)

        rule=root_rule.children()[0].clone()
        rule.setLabel(label_string)
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)

        layer.setRendererV2(renderer)
        #self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def create_query_string_operation(self):
        query_string='\"year\" ='+str(self.year)+ ' and ('
        operation=self.ui.cmbbox_operation.currentText()
        crop=self.ui.cmbbox_crop.currentText()
        query_string=query_string+'\"crop\" =' + '\''+ crop + '\' and ' +'\"operation\" =' + '\''+ operation + '\'' + ')'
        return query_string

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table, self.create_query_string_operation())

    def print_map(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operation.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        if self.ui.cmbbox_operation_term.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業予定期間を選択してください")
            return
        if self.ui.cmbbox_operator_candidate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業予定者を選択してください")
            return


        proc=pyqgis_processing
        widget = QWidget()
        widget.setGeometry(100, 100, 250, 100)
        widget.setWindowTitle(u'レイアウト作成中')
        pbar = QProgressBar(widget)
        pbar.setGeometry(25, 40, 200, 25)
        pbar.setRange(0, 1)
        widget.show()
        widget.raise_()
        pbar.setValue(0)



        db=proc.connect_db()
        #対象圃場一覧の取得
        cursor=db.cursor()
        query_string='select operation_table.farmland_code, cropping_table.crop_area,operation_table.operator,operation_table.operation_day,operation_table.progress from operation_table inner join cropping_table on operation_table.farmland_code = cropping_table.farmland_code \
            where operation_table.year=? and operation_table.crop=? and operation_table.operation=? and operation_table.operation_schedule=? and operation_table.operator_candidate=? \
            and cropping_table.year=? and cropping_table.crop=?'
        cursor.execute(query_string,(self.year,self.ui.cmbbox_crop.currentText(),self.ui.cmbbox_operation.currentText(),self.ui.cmbbox_operation_term.currentText(),self.ui.cmbbox_operator_candidate.currentText(),self.year,self.ui.cmbbox_crop.currentText()))
        rows=cursor.fetchall()

        cursor2=db.cursor()
        query_string2='select material from material_master \
            where crop=? '
        cursor2.execute(query_string2,(self.ui.cmbbox_crop.currentText(),))
        rows2=cursor2.fetchall()


        proc.save_map_image()

        html=u"""<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


        <style>
            .cssHeaderCell {

                font-size: 16px;

            }
            .cssTableCell {
                font-size: 20px;

            }

        </style>

        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
         <script type="text/javascript">
         google.load("visualization", "1", {packages:["table"]});
         google.setOnLoadCallback(drawChart);
         function drawChart(){
        var data=google.visualization.arrayToDataTable([
        ["%s","%s","%s","%s","%s"],""" % (u'圃場名',u'作付面積(m2)',u'作業実施者',u'作業実施日',u'作業状況')
        for row in rows:
            #print row[0]
            if row[4]==u"完了":
                html+='["%s","%s","%s","%s","%s"],' % (row[0],str(round(row[1],1)),row[2],row[3],row[4])
            else:
                html+='["%s","%s","%s","%s","%s"],' % (row[0],str(round(row[1],1)),"","","")
        html+=u"""]);
        var cssClassNames = {
                    'headerCell': 'cssHeaderCell',
                    'tableCell': 'cssTableCell'
                };
        var options ={
        title: "圃場一覧",
        width:800,
        cssClassNames: cssClassNames
        };
        var chart =new google.visualization.Table(
        document.getElementById("table1"));
        chart.draw(data,options);}</script>


        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
         <script type="text/javascript">
         google.load("visualization", "1", {packages:["table"]});
         google.setOnLoadCallback(drawChart);
        function drawChart(){
        var data=google.visualization.arrayToDataTable([
        ["%s"],""" % (u'資材名')
        for row in rows2:
            #print row[0]
            html+='["%s"],' % (row[0])
        html+=u"""]);
        var cssClassNames = {
                    'headerCell': 'cssHeaderCell',
                    'tableCell': 'cssTableCell'
                };
        var options ={
        title: "使用可能資材",
        width:800,
        cssClassNames: cssClassNames
        };
        var chart =new google.visualization.Table(
        document.getElementById("table2"));
        chart.draw(data,options);}</script>

         </script></head>
         <body>
         <h1><img src="%s"  """  % ("map.png")
        html+=u"""width="100%" ></h1>"""

        #2018/10、QRコードの出力を追記
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        operation_term=self.ui.cmbbox_operation_term.currentText()
        operator=self.ui.cmbbox_operator_candidate.currentText()
        qr_string=str(year) +"," + crop +"," + operation + "," +operation_term +"," +operator
        html+=u"""<table border="1" width="100%" height="60" ><tr>
                <td width="50%"  valign="top"><img src="http://chart.apis.google.com/chart?chs=130x130&cht=qr&chl="""
        html+=qr_string
        html+=u""" " alt="QRコード" align="left">"""
        html+="""</td>"""

        html+=u""" <form><table border="3" width="100%" ><tr>
        <td width="50%" height="180" valign="top">
            <textarea style=" margin: 0px; padding: 0px; width: 100%; height: 100%; box-sizing: border-box; font-size:14pt;" >作業者：</textarea>
        </td>
        <td width="50%" height="180" valign="top">
            <textarea style=" margin: 0px; padding: 0px; width: 100%; height: 100%; box-sizing: border-box; font-size:14pt;" >使用機材：</textarea>
        </td>
        </tr></table>
        <table border="3" width="100%"><tr>
        <td width="50%" height="180" valign="top">
            <textarea style=" margin: 0px; padding: 0px; width: 100%; height: 100%; box-sizing: border-box; font-size:14pt;" >使用資材：</textarea>
        </td>
        <td width="50%" height="180" valign="top">
            <textarea style=" margin: 0px; padding: 0px; width: 100%; height: 100%; box-sizing: border-box; font-size:14pt;" >備考：</textarea>
        </td>
        </tr></table></form>"""


        if not os.path.exists(proc.get_prj_path() +"/mapimage"):
            os.mkdir(proc.get_prj_path() +"/mapimage")
        f = open(proc.get_prj_path() +"/mapimage/directions.html", 'w') # 書き込みモードで開く
        f.write(html.encode('utf-8')) # 引数の文字列をファイルに書き込む
        f.close() # ファイルを閉じる
        pbar.setValue(1)
        if sys.platform == "win32":
            os.startfile(proc.get_prj_path() +"/mapimage/directions.html")
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, proc.get_prj_path() +"/mapimage/directions.html"])




    def export_csv(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operation.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        if self.ui.cmbbox_operation_term.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業予定期間を選択してください")
            return
        if self.ui.cmbbox_operator_candidate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業予定者を選択してください")
            return
        crop=self.ui.cmbbox_crop.currentText()
        year=self.year
        operation=self.ui.cmbbox_operation.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        term_r=term.replace('/', '-')
        operator=self.ui.cmbbox_operator_candidate.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        if not os.path.exists(path+u"/作業指示"):
            os.mkdir(path+u"/作業指示")
        path+=u"/作業指示"
        filename= path + "/"+"%s.csv"  % (str(year)+'_'+crop+'_'+operation+'_'+ term_r +'_'+operator+  u'_作業圃場一覧')
        #print filename
        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1="pkuid"
        field_name2=u"地区名"
        field_name3=u"圃場名"
        field_name4=u"品種"
        field_name5=u"作業予定者"
        field_name6=u"作業予定期間"
        field_name7=u"作業状況"
        field_name8=u"作付面積"
        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),field_name7.encode('"cp932"'),field_name8.encode('"cp932"')])

        features=self.farmland_table.getFeatures()
        for feature in features:
            field1=feature["pkuid"]
            field2=pyqgis_processing.get_string(feature["district"])
            field3=feature["farmland_code"]
            field4=pyqgis_processing.get_string(feature["cropping_table_variety"])
            field5=pyqgis_processing.get_string(feature["operation_table_operator_candidate"])
            field6=pyqgis_processing.get_string(feature["operation_table_operation_schedule"])
            field7=pyqgis_processing.get_string(feature["operation_table_progress"])
            field8=feature["cropping_table_crop_area"]
            if feature["cropping_table_crop"]==crop and feature["operation_table_operation"]==operation and feature["operation_table_operation_schedule"]==term and feature["operation_table_operator_candidate"]==operator:
                list_csv.append([field1,field2.encode('"cp932"'),field3.encode('"cp932"'),
                             field4.encode('"cp932"'),field5.encode('"cp932"'),field6.encode('"cp932"'),field7.encode('"cp932"'),field8])


        import types

        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])






