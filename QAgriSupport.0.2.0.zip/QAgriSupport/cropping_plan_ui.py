# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'cropping_plan_ui.ui'
#
# Created: Thu Jan 17 09:08:09 2019
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(294, 461)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gbox_crop = QtGui.QGroupBox(Dialog)
        self.gbox_crop.setFlat(True)
        self.gbox_crop.setCheckable(True)
        self.gbox_crop.setObjectName(_fromUtf8("gbox_crop"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.gbox_crop)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.tableWidget_crop = QtGui.QTableWidget(self.gbox_crop)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tableWidget_crop.sizePolicy().hasHeightForWidth())
        self.tableWidget_crop.setSizePolicy(sizePolicy)
        self.tableWidget_crop.setObjectName(_fromUtf8("tableWidget_crop"))
        self.tableWidget_crop.setColumnCount(0)
        self.tableWidget_crop.setRowCount(0)
        self.verticalLayout_2.addWidget(self.tableWidget_crop)
        self.verticalLayout.addWidget(self.gbox_crop)
        self.gbox_sum = QtGui.QGroupBox(Dialog)
        self.gbox_sum.setFlat(True)
        self.gbox_sum.setCheckable(True)
        self.gbox_sum.setChecked(False)
        self.gbox_sum.setObjectName(_fromUtf8("gbox_sum"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.gbox_sum)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.tableWidget_sum = QtGui.QTableWidget(self.gbox_sum)
        self.tableWidget_sum.setObjectName(_fromUtf8("tableWidget_sum"))
        self.tableWidget_sum.setColumnCount(0)
        self.tableWidget_sum.setRowCount(0)
        self.verticalLayout_3.addWidget(self.tableWidget_sum)
        self.verticalLayout.addWidget(self.gbox_sum)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setInputMethodHints(QtCore.Qt.ImhNone)
        self.groupBox_2.setFlat(False)
        self.groupBox_2.setCheckable(False)
        self.groupBox_2.setChecked(False)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn_show_table = QtGui.QPushButton(self.groupBox_2)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout_3.addWidget(self.btn_show_table, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_2)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_4.addWidget(self.label_3, 0, 0, 1, 1)
        self.btn_copy_plan = QtGui.QPushButton(self.groupBox)
        self.btn_copy_plan.setObjectName(_fromUtf8("btn_copy_plan"))
        self.gridLayout_4.addWidget(self.btn_copy_plan, 1, 0, 1, 2)
        self.spbox_past_year = QtGui.QSpinBox(self.groupBox)
        self.spbox_past_year.setMaximum(10000)
        self.spbox_past_year.setObjectName(_fromUtf8("spbox_past_year"))
        self.gridLayout_4.addWidget(self.spbox_past_year, 0, 1, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.groupBox_3)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.cmbbox_crop = QtGui.QComboBox(self.groupBox_3)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.gridLayout.addWidget(self.cmbbox_crop, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox_3)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.cmbbox_variety = QtGui.QComboBox(self.groupBox_3)
        self.cmbbox_variety.setObjectName(_fromUtf8("cmbbox_variety"))
        self.gridLayout.addWidget(self.cmbbox_variety, 1, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox_3)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout.addWidget(self.btn_insert, 2, 1, 1, 1)
        self.lbl_area = QtGui.QLabel(self.groupBox_3)
        self.lbl_area.setText(_fromUtf8(""))
        self.lbl_area.setObjectName(_fromUtf8("lbl_area"))
        self.gridLayout.addWidget(self.lbl_area, 2, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_3)
        self.groupBox_5 = QtGui.QGroupBox(Dialog)
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_5)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_5)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_2.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_5)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作付計画", None))
        self.gbox_crop.setTitle(_translate("Dialog", "表示作物", None))
        self.gbox_sum.setTitle(_translate("Dialog", "作物・品種面積", None))
        self.groupBox_2.setTitle(_translate("Dialog", "テーブルの表示", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブルを表示する", None))
        self.groupBox.setTitle(_translate("Dialog", "過年度作付データのコピー", None))
        self.label_3.setText(_translate("Dialog", "コピー元の年度", None))
        self.btn_copy_plan.setText(_translate("Dialog", "作付データのコピー", None))
        self.groupBox_3.setTitle(_translate("Dialog", "選択行への作付登録", None))
        self.label.setText(_translate("Dialog", "作物", None))
        self.label_2.setText(_translate("Dialog", "品種", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox_5.setTitle(_translate("Dialog", "選択行の作付削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

