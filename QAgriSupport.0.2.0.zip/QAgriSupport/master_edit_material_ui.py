# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_material_ui.ui'
#
# Created: Wed Apr 12 15:04:13 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(382, 634)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout.addWidget(self.label_2)
        self.cmb_box_crop = QtGui.QComboBox(Dialog)
        self.cmb_box_crop.setObjectName(_fromUtf8("cmb_box_crop"))
        self.horizontalLayout.addWidget(self.cmb_box_crop)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.tableWidget_material = QtGui.QTableWidget(Dialog)
        self.tableWidget_material.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_material.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_material.setObjectName(_fromUtf8("tableWidget_material"))
        self.tableWidget_material.setColumnCount(0)
        self.tableWidget_material.setRowCount(0)
        self.verticalLayout.addWidget(self.tableWidget_material)
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.label_7 = QtGui.QLabel(self.groupBox)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout_2.addWidget(self.label_7, 3, 0, 1, 1)
        self.label_5 = QtGui.QLabel(self.groupBox)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout_2.addWidget(self.label_5, 1, 0, 1, 1)
        self.label_6 = QtGui.QLabel(self.groupBox)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout_2.addWidget(self.label_6, 2, 0, 1, 1)
        self.lineEdit_unit1 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_unit1.setObjectName(_fromUtf8("lineEdit_unit1"))
        self.gridLayout_2.addWidget(self.lineEdit_unit1, 1, 1, 1, 1)
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_2.addWidget(self.btn_insert, 4, 1, 1, 1)
        self.lineEdit_name1 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_name1.setObjectName(_fromUtf8("lineEdit_name1"))
        self.gridLayout_2.addWidget(self.lineEdit_name1, 0, 1, 1, 1)
        self.lineEdit_package1 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_package1.setObjectName(_fromUtf8("lineEdit_package1"))
        self.gridLayout_2.addWidget(self.lineEdit_package1, 2, 1, 1, 1)
        self.lineEdit_amount1 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_amount1.setObjectName(_fromUtf8("lineEdit_amount1"))
        self.gridLayout_2.addWidget(self.lineEdit_amount1, 3, 1, 1, 1)
        self.verticalLayout_2.addWidget(self.groupBox)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.label_3 = QtGui.QLabel(self.groupBox_2)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_3.addWidget(self.label_3, 0, 0, 1, 1)
        self.lineEdit_name2 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_name2.setObjectName(_fromUtf8("lineEdit_name2"))
        self.gridLayout_3.addWidget(self.lineEdit_name2, 0, 1, 1, 1)
        self.label_8 = QtGui.QLabel(self.groupBox_2)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.gridLayout_3.addWidget(self.label_8, 1, 0, 1, 1)
        self.label_9 = QtGui.QLabel(self.groupBox_2)
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.gridLayout_3.addWidget(self.label_9, 2, 0, 1, 1)
        self.label_10 = QtGui.QLabel(self.groupBox_2)
        self.label_10.setObjectName(_fromUtf8("label_10"))
        self.gridLayout_3.addWidget(self.label_10, 3, 0, 1, 1)
        self.lineEdit_unit2 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_unit2.setObjectName(_fromUtf8("lineEdit_unit2"))
        self.gridLayout_3.addWidget(self.lineEdit_unit2, 1, 1, 1, 1)
        self.lineEdit_package2 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_package2.setObjectName(_fromUtf8("lineEdit_package2"))
        self.gridLayout_3.addWidget(self.lineEdit_package2, 2, 1, 1, 1)
        self.lineEdit_amount2 = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_amount2.setObjectName(_fromUtf8("lineEdit_amount2"))
        self.gridLayout_3.addWidget(self.lineEdit_amount2, 3, 1, 1, 1)
        self.btn_update = QtGui.QPushButton(self.groupBox_2)
        self.btn_update.setObjectName(_fromUtf8("btn_update"))
        self.gridLayout_3.addWidget(self.btn_update, 4, 1, 1, 1)
        self.verticalLayout_2.addWidget(self.groupBox_2)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_5 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        self.btn_delete = QtGui.QPushButton(self.groupBox_3)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_5.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.verticalLayout_2.addWidget(self.groupBox_3)
        self.verticalLayout.addLayout(self.verticalLayout_2)
        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "資材登録", None))
        self.label_2.setText(_translate("Dialog", "対象作物", None))
        self.groupBox.setTitle(_translate("Dialog", "資材登録", None))
        self.label_7.setText(_translate("Dialog", "パッケージ当たり数量", None))
        self.label_5.setText(_translate("Dialog", "資材単位", None))
        self.label_6.setText(_translate("Dialog", "パッケージ単位", None))
        self.label.setText(_translate("Dialog", "資材名", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.groupBox_2.setTitle(_translate("Dialog", "選択行の編集", None))
        self.label_3.setText(_translate("Dialog", "資材名", None))
        self.label_8.setText(_translate("Dialog", "資材単位", None))
        self.label_9.setText(_translate("Dialog", "パッケージ単位", None))
        self.label_10.setText(_translate("Dialog", "パッケージ当たり数量", None))
        self.btn_update.setText(_translate("Dialog", "変更", None))
        self.groupBox_3.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

