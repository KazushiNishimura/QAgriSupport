# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from poly_importer_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import os, sys, subprocess
import csv

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
#         self.year=y
        proc=pyqgis_processing
        self.populate_cmbbox()

        self.connect(self.ui.btn_choose_poly, SIGNAL("clicked()"),self.choose_folder_poly)
        self.connect(self.ui.btn_choose_aza, SIGNAL("clicked()"),self.choose_folder_aza)
        self.connect(self.ui.cmbbox_city,SIGNAL("currentIndexChanged(const QString&)"),self.populate_tablewidget_aza)
        self.connect(self.ui.btn_import,SIGNAL("clicked()"),self.import_polygon)
#         self.farmland_table=proc.get_farmland_table()
#         self.operation_table=proc.get_operation_table()
#         self.cropping_table=proc.get_cropping_table()
#         self.contract_table=proc.get_contract_table()
#         self.ui.spbox_year.setValue(y)

        #proc.remove_join()
#         proc.clear_query(self.farmland_table)
#         proc.clear_query(self.operation_table)
#         proc.clear_query(self.cropping_table)
#         proc.clear_query(self.contract_table)
#         proc.set_query(self.farmland_table,u'"kind"=\'受託地\'')
#         proc.set_query(self.cropping_table,'"year"='+ str(self.year))
#         proc.set_query(self.operation_table,'"year"='+ str(self.year))
#         proc.set_query(self.contract_table,'"year"='+ str(self.year))

        #proc.add_join_cropping_table()
        #proc.add_join_operation_table()

#         proc.hide_all_columns(self.farmland_table)
#         proc.show_columns_farmland_table(self.farmland_table)
#         proc.show_columns_contract_table(self.farmland_table)
#         #proc.show_columns_operation_table(self.farmland_table)
#         proc.set_alias_farmland_table(self.farmland_table)
#         proc.set_alias_contract_table(self.farmland_table)
# #         proc.set_alias_operation_table(self.farmland_table)
#
#         self.populate_cmbbox_operate()
# #
# #
# #         self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
#         self.connect(self.ui.cmbbox_operate,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operate_change)
#         self.connect(self.ui.spbox_year, SIGNAL("valueChanged (int)"),self.spbox_change)
# #
#         self.connect(self.ui.btn_export_csv,SIGNAL("clicked()"),self.export_csv)
#         self.connect(self.ui.btn_show_table,SIGNAL("clicked()"),self.show_attribute_table)
# #         self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
#         #self.ui.tablewidget_contract.itemClicked.connect(self.select_landfields)
#         self.ui.tablewidget_contract.itemSelectionChanged.connect(self.select_landfields)

    def populate_cmbbox(self):
        for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer):
                self.ui.cmbbox_import_to.addItem(lyr.name())

    def choose_folder_poly(self):
    # ファイル選択ダイアログ
        self.fil = QFileDialog.getOpenFileName(None, "Open Shapefile", ".", "Shapefiles (*.shp)")
        self.filInfo = QFileInfo(self.fil)
        self.ui.lineedit_poly_datasource.setText(self.filInfo.filePath())

    def choose_folder_aza(self):
    # ファイル選択ダイアログ
        self.fil = QFileDialog.getOpenFileName(None, "Open Shapefile", ".", "Shapefiles (*.shp)")
        self.filInfo = QFileInfo(self.fil)
        self.ui.lineedit_aza_datasource.setText(self.filInfo.filePath())
        self.populate_cmbbox_city()

    def populate_cmbbox_city(self):
        self.ui.cmbbox_city.addItem(u"全件表示")

        layer=self.get_layer(self.ui.lineedit_aza_datasource.text())
        features=layer.getFeatures()
        city_list=[]
        for feature in features:
            if not feature[feature.fieldNameIndex('CITY_NAME')] in city_list:
                city_list.append(feature[feature.fieldNameIndex('CITY_NAME')])
                self.ui.cmbbox_city.addItem(feature[feature.fieldNameIndex('CITY_NAME')])

    def populate_tablewidget_aza(self):
        self.ui.tablewidget_aza.clear()
        self.ui.tablewidget_aza.setRowCount(0)
        self.ui.tablewidget_aza.setSortingEnabled(True)
        #self.ui.tableWidget_crop.setRowCount(row_count)
        headers=[u"選択",u"市町村名",u"字名"]
        self.ui.tablewidget_aza.setColumnCount(len(headers))
        self.ui.tablewidget_aza.setHorizontalHeaderLabels(headers)

        layer=self.get_layer(self.ui.lineedit_aza_datasource.text())
        features=layer.getFeatures()
        aza_list=[]
        i=0

        for feature in features:
            if self.ui.cmbbox_city.currentText()==u"全件表示":
                if not feature[feature.fieldNameIndex('S_NAME')] in aza_list:
                    try:
                        aza_list.append(feature[feature.fieldNameIndex('S_NAME')])
                        chk =QTableWidgetItem()
                        chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                        chk.setCheckState(Qt.Unchecked)
                        #print farmer[0]
                        #print farmer[1]
                        self.ui.tablewidget_aza.insertRow(i)
                        self.ui.tablewidget_aza.setItem(i,0,chk)
                        self.ui.tablewidget_aza.setItem(i,1,QTableWidgetItem(feature[feature.fieldNameIndex('CITY_NAME')]))
                        self.ui.tablewidget_aza.setItem(i,2,QTableWidgetItem(feature[feature.fieldNameIndex('S_NAME')]))
                        i=i+1
                    except:
                        pass

            else:
                if not feature[feature.fieldNameIndex('S_NAME')] in aza_list:
                    if feature[feature.fieldNameIndex('CITY_NAME')]==self.ui.cmbbox_city.currentText():
                        try:
                            aza_list.append(feature[feature.fieldNameIndex('S_NAME')])
                            chk =QTableWidgetItem()
                            chk.setFlags(Qt.ItemIsUserCheckable |Qt.ItemIsEnabled)
                            chk.setCheckState(Qt.Unchecked)
                            #print farmer[0]
                            #print farmer[1]
                            self.ui.tablewidget_aza.insertRow(i)
                            self.ui.tablewidget_aza.setItem(i,0,chk)
                            self.ui.tablewidget_aza.setItem(i,1,QTableWidgetItem(feature[feature.fieldNameIndex('CITY_NAME')]))
                            self.ui.tablewidget_aza.setItem(i,2,QTableWidgetItem(feature[feature.fieldNameIndex('S_NAME')]))
                            i=i+1
                        except:
                            pass


        self.ui.tablewidget_aza.resizeColumnsToContents()


    def get_layer(self,file_path):

        layer=QgsVectorLayer(file_path,"","ogr")
        return layer

    def get_selected_aza(self):
        #選択字をリストに格納
        aza_list=[]
        row_count=self.ui.tablewidget_aza.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_aza.item(i,0).checkState()==Qt.Checked:
                aza_list.append(self.ui.tablewidget_aza.item(i,2).text())

        return aza_list

    def import_polygon(self):

        aza_list=self.get_selected_aza()

        for aza in aza_list:
            print aza



