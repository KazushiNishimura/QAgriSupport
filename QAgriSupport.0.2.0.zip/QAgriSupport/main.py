# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic
import os
import shutil
from QAgriSupport import pyqgis_processing


# リソース読み込み
try:
  from . import resource
except ImportError:
  pass



class main:

  def __init__(self, iface):
    self.iface = iface

  # QGISのメニューに表示するときに呼ばれるやつ
  def initGui(self):
    # 小メニューを作る
    self.action1 = QAction(QIcon(":/icon/marubatu32.png"), u"ファイルを開く", self.iface.mainWindow())
    self.action1.setObjectName("sample1")
    self.action2 = QAction(u"ダイアログを開く", self.iface.mainWindow())
    self.action2.setObjectName("sample2")
    self.action3=QAction(u"生産管理システム",self.iface.mainWindow())
    self.action3.setObjectName("open_dock")
    self.action4=QAction(u"筆ポリゴンインポーター",self.iface.mainWindow())
    self.action4.setObjectName("open_importer")
    self.action_gpx_renderer=QAction(u"gpxのレンダリング",self.iface.mainWindow())
    self.action_gpx_renderer.setObjectName("gpx_renderer")
    self.start_land_management=QAction(u"地域営農計画システム",self.iface.mainWindow())
    self.start_land_management.setObjectName("start_land_management")

    self.load_sample_data=QAction(u"サンプルデータ",self.iface.mainWindow())
    self.load_sample_data.setObjectName("load_sample_data")

    # 大メニューを作る
    self.menu = QMenu(self.iface.mainWindow())
    self.menu.setObjectName("QAgriSupport")
    self.menu.setTitle("QAgriSupport")
    #self.menu.addAction(self.action1)
    #self.menu.addAction(self.action2)
    self.menu.addAction(self.action3)
    #self.menu.addAction(self.action4)
    #self.menu.addAction(self.action_gpx_renderer)
    self.menu.addAction(self.load_sample_data)


    # 大メニューをメニューバーに挿入する
    menuBar = self.iface.mainWindow().menuBar()
    menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)

    # 小メニューを押したとき実行するよう、トリガーをセット
    QObject.connect(self.action3,SIGNAL("triggered()"),self.run3)
    QObject.connect(self.action4,SIGNAL("triggered()"),self.open_importer)
    QObject.connect(self.action_gpx_renderer,SIGNAL("triggered()"),self.run_gpx)
    QObject.connect(self.load_sample_data,SIGNAL("triggered()"),self.load_data)

  def load_data(self):

    ret = QMessageBox.information(None, u"確認", u"サンプルデータをセットアップしますか？", QMessageBox.Yes, QMessageBox.No)
    if ret == QMessageBox.Yes:
        folder_path=QFileDialog.getExistingDirectory()
        if folder_path !="":
            path_from=os.path.expanduser('~/.qgis2/python/plugins/QAgriSupport/resource/demo')
            file1=path_from+"/agrimanagement.qgs"
            file2=path_from+"/management_db.sqlite"
#             file3=path_from+u"/メールリスト.csv"
#             file4=path_from+u"/農地台帳.csv"
#             file5=path_from+u"/品種RM.csv"
            #shutil.copytree(copy_from,copy_to)
            shutil.copy(file1, folder_path+"/agrimanagement.qgs")
            shutil.copy(file2, folder_path+"/management_db.sqlite")
#             shutil.copy(file3, folder_path+u"/メールリスト.csv")
#             shutil.copy(file4, folder_path+u"/農地台帳.csv")
#             shutil.copy(file5, folder_path+u"/品種RM.csv")

            pyqgis_processing.show_msgbox(u"セットアップが完了しました。"+ folder_path+"/demo/agrimanagement.qgs" +u"から再起動してください")


  def unload(self):
    self.menu.deleteLater()

  def run3(self):
    #path = os.path.dirname(os.path.abspath(__file__))
    #self.dock = uic.loadUi(os.path.join(path, "dockwidgetui.ui"))
    from dockwidget import DockWidget
    self.doc=DockWidget(self.iface)
    self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.doc)
    #self.dlg=DockWidget(self.iface)
    #self.dlg.show()

  def run_gpx(self):
      from gpx_renderer import Dialog
      self.dlg=Dialog(self.iface)
      self.dlg.show()
      self.dlg.exec_()

  def open_importer(self):
    from poly_importer import Dialog
    self.dlg = Dialog(self.iface)

    # 表示
    self.dlg.show()

    # 実行
    self.dlg.exec_()





