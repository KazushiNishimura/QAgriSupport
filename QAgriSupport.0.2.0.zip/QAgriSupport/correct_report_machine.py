# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from correct_report_machine_ui import Ui_Dialog
from QAgriSupport import  pyqgis_processing
import sqlite3
import datetime

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,dlg):
        QDialog.__init__(self)
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.dlg=dlg
        self.populate_tablewidget_machine()

        self.connect(self.ui.btn_ok,SIGNAL("clicked()"),self.ok)
        self.connect(self.ui.btn_cancel,SIGNAL("clicked()"),self.cancel)

    def populate_tablewidget_machine(self):
        proc =pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select machine from machine_master")
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.tablewidget_machine.clear()
        self.ui.tablewidget_machine.setSortingEnabled(True)
        self.ui.tablewidget_machine.setRowCount(row_count)
        headers=[u"選択",u"機械名"]
        self.ui.tablewidget_machine.setColumnCount(len(headers))
        self.ui.tablewidget_machine.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            chk=QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tablewidget_machine.setItem(i,0,chk)
            self.ui.tablewidget_machine.setItem(i,1,QTableWidgetItem(row[0]))
            i=i+1
        self.ui.tablewidget_machine.resizeColumnsToContents()

        db.close()

    def ok(self):

        self.dlg.list_machine=[]
        row_count=self.ui.tablewidget_machine.rowCount()

        for i in range(row_count):
            if self.ui.tablewidget_machine.item(i,0).checkState()==Qt.Checked:
                self.dlg.list_machine.append(self.ui.tablewidget_machine.item(i,1).text())

        self.close()

    def cancel(self):
        self.dlg.list_machine=[]
        self.close()