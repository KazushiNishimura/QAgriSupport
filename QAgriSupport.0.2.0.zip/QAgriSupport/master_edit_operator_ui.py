# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'master_edit_operator_ui.ui'
#
# Created: Wed Apr 12 14:22:54 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(288, 399)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.tableWidget_operator = QtGui.QTableWidget(Dialog)
        self.tableWidget_operator.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tableWidget_operator.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tableWidget_operator.setObjectName(_fromUtf8("tableWidget_operator"))
        self.tableWidget_operator.setColumnCount(0)
        self.tableWidget_operator.setRowCount(0)
        self.verticalLayout.addWidget(self.tableWidget_operator)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setEnabled(True)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.lineEdit_operator = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit_operator.setObjectName(_fromUtf8("lineEdit_operator"))
        self.gridLayout_2.addWidget(self.lineEdit_operator, 0, 1, 1, 1)
        self.btn_insert = QtGui.QPushButton(self.groupBox_2)
        self.btn_insert.setObjectName(_fromUtf8("btn_insert"))
        self.gridLayout_2.addWidget(self.btn_insert, 2, 1, 1, 1)
        self.label = QtGui.QLabel(self.groupBox_2)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox_2)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn_delete = QtGui.QPushButton(self.groupBox)
        self.btn_delete.setObjectName(_fromUtf8("btn_delete"))
        self.gridLayout_3.addWidget(self.btn_delete, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業者登録", None))
        self.groupBox_2.setTitle(_translate("Dialog", "作業者登録", None))
        self.btn_insert.setText(_translate("Dialog", "登録", None))
        self.label.setText(_translate("Dialog", "作業者名", None))
        self.groupBox.setTitle(_translate("Dialog", "選択行の削除", None))
        self.btn_delete.setText(_translate("Dialog", "削除", None))

