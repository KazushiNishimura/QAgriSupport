# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'renderer_operation_progress_ui.ui'
#
# Created: Tue Jun 20 10:55:24 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(319, 310)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout.addWidget(self.label)
        self.cmbbox_crop = QtGui.QComboBox(Dialog)
        self.cmbbox_crop.setObjectName(_fromUtf8("cmbbox_crop"))
        self.horizontalLayout.addWidget(self.cmbbox_crop)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout_2.addWidget(self.label_2)
        self.cmbbox_operate = QtGui.QComboBox(Dialog)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.horizontalLayout_2.addWidget(self.cmbbox_operate)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.tablewidget_sum = QtGui.QTableWidget(Dialog)
        self.tablewidget_sum.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_sum.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_sum.setObjectName(_fromUtf8("tablewidget_sum"))
        self.tablewidget_sum.setColumnCount(0)
        self.tablewidget_sum.setRowCount(0)
        self.verticalLayout.addWidget(self.tablewidget_sum)
        self.btn_show_attributetable = QtGui.QPushButton(Dialog)
        self.btn_show_attributetable.setObjectName(_fromUtf8("btn_show_attributetable"))
        self.verticalLayout.addWidget(self.btn_show_attributetable)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.verticalLayout.addWidget(self.btn_export_csv)
        self.btn_export_all_csv = QtGui.QPushButton(Dialog)
        self.btn_export_all_csv.setObjectName(_fromUtf8("btn_export_all_csv"))
        self.verticalLayout.addWidget(self.btn_export_all_csv)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業進捗状況", None))
        self.label.setText(_translate("Dialog", "対象作物", None))
        self.label_2.setText(_translate("Dialog", "対象作業", None))
        self.btn_show_attributetable.setText(_translate("Dialog", "テーブルを表示", None))
        self.btn_export_csv.setText(_translate("Dialog", "CSVに対象作業の圃場別作業状況を出力", None))
        self.btn_export_all_csv.setText(_translate("Dialog", "CSVに全作業進捗状況を出力", None))

