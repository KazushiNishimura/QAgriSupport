# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtSql import QSqlQueryModel,QSqlDatabase,QSqlQuery,QSqlTableModel
from master_edit_crop_ui import Ui_Dialog
from qgis.core import *
from qgis.gui import *
import sqlite3
import pyqgis_processing


# ダイアログクラス
class Dialog(QDialog, Ui_Dialog):


    def __init__(self, iface):
        QDialog.__init__(self)
        self.iface = iface
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_table()

        QObject.connect(self.ui.btn_register_crop, SIGNAL("clicked()"),self.insert_row)
        QObject.connect(self.ui.btn_delete_crop,SIGNAL("clicked()"),self.delete_row)

    def insert_row(self):
        if self.ui.lineedit_crop.text()=="":
            pyqgis_processing.show_msgbox(u"作物名を入力してください")
            return
        if self.ui.lineedit_variety.text()==u"":
            pyqgis_processing.show_msgbox(u"品種名を入力してください")
            return

        path=pyqgis_processing.get_prj_path()
        connect_db = sqlite3.connect(path+"/"+"management_db.sqlite")
        crop = self.ui.lineedit_crop.text()
        variety=self.ui.lineedit_variety.text()
        new_row=(crop,variety)

        connect_db.execute('insert into crop_master (crop,variety) values (?,?)', new_row)
        connect_db.commit()
        self.ui.lineedit_crop.clear()
        self.ui.lineedit_variety.clear()
        self.populate_table()

    def delete_row(self):

        path=pyqgis_processing.get_prj_path()
        db=sqlite3.connect(path+"/"+"management_db.sqlite")

        for i in range(0,self.ui.table_widget_crop.rowCount()):
            if self.ui.table_widget_crop.item(i,0).isSelected()==True:
                db.execute("delete from crop_master where id ="+self.ui.table_widget_crop.item(i,0).text())

        db.commit()
        db.close()

        self.populate_table()



    #データのウィジェットへの表示
    def populate_table(self):

        path=pyqgis_processing.get_prj_path()

        db=sqlite3.connect(path+"/"+"management_db.sqlite")

        cursor=db.cursor()
        cursor.execute("SELECT id,crop,variety FROM crop_master")
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.table_widget_crop.clear()
        self.ui.table_widget_crop.setSortingEnabled(True)
        self.ui.table_widget_crop.setRowCount(row_count)
        headers=["id",u"作物名",u"品種名"]
        self.ui.table_widget_crop.setColumnCount(len(headers))
        self.ui.table_widget_crop.setHorizontalHeaderLabels(headers)
        self.ui.table_widget_crop.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.table_widget_crop.setSelectionBehavior(QAbstractItemView.SelectRows)
        #データの表示
        i=0
        for row in rows:
            self.ui.table_widget_crop.setItem(i,0,QTableWidgetItem(str(row[0])))
            self.ui.table_widget_crop.setItem(i,1,QTableWidgetItem(row[1]))
            self.ui.table_widget_crop.setItem(i,2,QTableWidgetItem(row[2]))
            i=i+1

        self.ui.table_widget_crop.resizeColumnsToContents()
        self.ui.table_widget_crop.hideColumn(0)

        cursor.close()
        db.close()


    def count_data_crop_master(self):
        path=pyqgis_processing.get_prj_path()
        connect_db = sqlite3.connect(path+"/"+"management_db.sqlite")
        return connect_db.execute('select count(*) from crop_master')

