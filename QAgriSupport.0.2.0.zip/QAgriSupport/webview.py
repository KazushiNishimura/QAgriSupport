# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from webview_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
from time import sleep
import os.path

from PyQt4.QtWebKit import  *

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        proc=pyqgis_processing

        QWebSettings.clearMemoryCaches()

        if os.path.exists(proc.get_prj_path()+"\mapimage\map.jpg"):
            os.remove(proc.get_prj_path()+"\mapimage\map.jpg")

        if os.path.exists(proc.get_prj_path()+"\mapimage\directions.pdf"):
            os.remove(proc.get_prj_path()+"\mapimage\directions.pdf")

        self.view_map()

        self.connect(self.ui.btn_pdf,SIGNAL("clicked()"),self.topdf)



    def view_map(self):
        proc=pyqgis_processing

#         if os.path.exists(proc.get_prj_path()+"\mapimage\map.jpg"):
#             os.remove(proc.get_prj_path()+"\mapimage\map.jpg")
        sleep(5)

#         layer = proc.get_farmland_table()
#         values=[]
#         features=layer.getFeatures()
#         for f in features:
#             values.append(f['land_area'])

        proc.save_map_image()
        sleep(5)
        #myWV=self.ui.webView(None)
        html="""<html><head>"""
#         <script type="text/javascript" src="https://www.google.com/jsapi"></script>
#          <script type="text/javascript">
#          google.load("visualization", "1", {packages:["table"]});
#          google.setOnLoadCallback(drawChart);
#          function drawChart(){
#         var data=google.visualization.arrayToDataTable([
#         ["%s"],""" % ('land_area')
#         for value in values:
#             html+='[%f],' %  (value)
#         html+=u"""]);
#         var options ={
#         title: "圃場一覧",
#         width:250
#         };
#         var chart =new google.visualization.Table(
#         document.getElementById("table1"));
#         chart.draw(data,options);}</script>
        #</script>
        html+=""" </head>
         <body>
         <h1><img src="%s"  """  % (proc.get_prj_path() +"\mapimage\map.jpg")
        html+="""width="90%" ></h1>"""
#         html+=u""" <table border="3" width="100%" ><tr>
#         <td width="50%" height="250" valign="top">作業者：</td><td width="50%" height="250" valign="top">使用機材：</td>
#         </tr></table>
#         <table border="3" width="100%"><tr>
#         <td width="50%" height="250" valign="top">使用資材：</td><td width="50%" height="250" valign="top">備考：</td>
#         </tr></table>
#         <h2>　</h2>
#         <h2>　</h2>
#         <h2>　</h2>
#         <h2>　</h2>
#         <h2>圃場一覧</h2>
#
#         <div id="table1" ></div>


        html+="""</body></html>"""
        self.ui.webView.setHtml(html)

    def topdf(self):
        proc=pyqgis_processing

#         if os.path.exists(proc.get_prj_path()+"\mapimage\directions.pdf"):
#             os.remove(proc.get_prj_path()+"\mapimage\directions.pdf")
        #sleep(5)
        printer = QPrinter()
        printer.setPageSize(QPrinter.A4)
        printer.setColorMode(QPrinter.Color)
        printer.setOrientation( QPrinter.Landscape)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName((proc.get_prj_path() +"\mapimage\directions.pdf"))
        self.ui.webView.page().mainFrame().print_(printer)

        os.startfile(proc.get_prj_path() +"\mapimage\directions.pdf")
