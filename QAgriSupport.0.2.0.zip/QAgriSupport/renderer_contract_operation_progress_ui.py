# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'renderer_contract_operation_progress_ui.ui'
#
# Created: Wed May 24 16:35:56 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(337, 463)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.cmbbox_operate = QtGui.QComboBox(Dialog)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout.addWidget(self.cmbbox_operate, 0, 1, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.tablewidget_client = QtGui.QTableWidget(self.groupBox_2)
        self.tablewidget_client.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_client.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_client.setObjectName(_fromUtf8("tablewidget_client"))
        self.tablewidget_client.setColumnCount(0)
        self.tablewidget_client.setRowCount(0)
        self.gridLayout_3.addWidget(self.tablewidget_client, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_2, 1, 0, 1, 2)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tablewidget_plan = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_plan.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_plan.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_plan.setObjectName(_fromUtf8("tablewidget_plan"))
        self.tablewidget_plan.setColumnCount(0)
        self.tablewidget_plan.setRowCount(0)
        self.gridLayout_4.addWidget(self.tablewidget_plan, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_3, 2, 0, 1, 2)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.rbtn_plan = QtGui.QRadioButton(self.groupBox)
        self.rbtn_plan.setChecked(True)
        self.rbtn_plan.setObjectName(_fromUtf8("rbtn_plan"))
        self.horizontalLayout_2.addWidget(self.rbtn_plan)
        self.rbtn_client = QtGui.QRadioButton(self.groupBox)
        self.rbtn_client.setObjectName(_fromUtf8("rbtn_client"))
        self.horizontalLayout_2.addWidget(self.rbtn_client)
        self.gridLayout.addWidget(self.groupBox, 3, 0, 1, 2)
        self.btn_show_attributetable = QtGui.QPushButton(Dialog)
        self.btn_show_attributetable.setObjectName(_fromUtf8("btn_show_attributetable"))
        self.gridLayout.addWidget(self.btn_show_attributetable, 5, 0, 1, 2)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.gridLayout.addWidget(self.btn_export_csv, 7, 0, 1, 2)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業進捗状況（受託作業）", None))
        self.label.setText(_translate("Dialog", "対象作業", None))
        self.groupBox_2.setTitle(_translate("Dialog", "受託一覧", None))
        self.groupBox_3.setTitle(_translate("Dialog", "計画一覧", None))
        self.groupBox.setTitle(_translate("Dialog", "色分けのルール", None))
        self.rbtn_plan.setText(_translate("Dialog", "作業日程ごとに色分け", None))
        self.rbtn_client.setText(_translate("Dialog", "依頼者毎に色分け", None))
        self.btn_show_attributetable.setText(_translate("Dialog", "テーブル表示", None))
        self.btn_export_csv.setText(_translate("Dialog", "CSVに作業対象作業の作業状況を出力", None))

