# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from rm_plan_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime
import copy
import csv
import os, sys, subprocess

class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.year=y
        self.list_rm=[]
        self.load_rm()
        self.farmland_table=pyqgis_processing.get_farmland_table()
        self.contract_table=pyqgis_processing.get_contract_table()
        self.operation_table=pyqgis_processing.get_operation_table()

        proc=pyqgis_processing
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.contract_table)
        proc.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        proc.set_query(self.contract_table, '"year"='+ str(self.year) )

        proc.hide_all_columns(self.farmland_table)
        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_contract_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_column_visibility(self.farmland_table, "operation_table_progress", True)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_contract_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)





        proc=pyqgis_processing

        self.check_tables()




        proc.clear_query(self.farmland_table)
        proc.clear_query(self.contract_table)
        proc.set_query(self.farmland_table, u'"kind"=\'受託地\'')
        proc.set_query(self.contract_table, '"year"='+ str(self.year) )



        self.setWindowFlags(Qt.WindowStaysOnTopHint)

        self.populate_cmbbox_operate()
#         self.populate_cmbbox_client()



        pyqgis_processing.hide_all_columns(self.farmland_table)
        pyqgis_processing.show_columns_farmland_table(self.farmland_table)
        pyqgis_processing.show_columns_contract_table(self.farmland_table)
        pyqgis_processing.set_alias_farmland_table(self.farmland_table)
        pyqgis_processing.set_alias_contract_table(self.farmland_table)

        self.connect(self.ui.cmbbox_operation,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operation_changed)
        self.ui.tablewidget_plan.itemSelectionChanged.connect(self.select_landfields)
        self.connect(self.ui.btn_update,SIGNAL("clicked()"),self.update_plan)
        self.connect(self.ui.btn_export_csv,SIGNAL("clicked()"),self.export_csv)
#         self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
#         self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)
#         self.farmland_table.selectionChanged.connect(self.sum_selected_area)
#         #self.ui.tablewidget_contract.itemClicked.connect(self.select_landfields)
#         self.ui.tablewidget_contract.itemSelectionChanged.connect(self.select_landfields)
        #self.ui.tablewidget_plan.cellChanged.connect(self.cellchanged)


    def update_plan(self):
        self.update_row_operation_table()

    def cmbbox_operation_changed(self):
        self.populate_tablewidget()

        self.set_query_contract_table()
        self.set_query_operation_table()
        operation=self.ui.cmbbox_operation.currentText()
        #作業が全て完了している依頼者は跳ねれるようにする
#         list_client=self.make_list_clietnt()
#         list_client_area=self.sum_contract_area(operation,list_client)
#         self.populate_tablewidget_contract(list_client_area)
#         self.populate_sum_table()
        self.renderer_map()




    def create_renderer_rule_string(self):
        list_rule=[]
#         operation=self.ui.cmbbox_operation.currentText()
#         row_count=self.ui.tablewidget_plan.rowCount()
#         for i in xrange(row_count):
#             term=self.ui.tablewidget_plan.item(i,5).text() #+"-"+self.ui.tablewidget_plan.item(i,5).text()
#             operator=self.ui.tablewidget_plan.cellWidget(i,7).currentText()
#             label_string=term+ ':'+operator
#             query_string=""" "contract_table_operation" = '%s' and "operation_table_crop" ='%s' and "operation_table_operation" ='%s' and "operation_table_operation_schedule" = '%s'
#              and "operation_table_operator_candidate" ='%s'"""     %(operation,u"受託",operation,term,operator)
#             list_rule.append([label_string,query_string])
        #対象作物で、作業名がないレコードを設定
        year=self.year
        crop=u"受託"
        operation=self.ui.cmbbox_operation.currentText()
        proc=pyqgis_processing
        query_string=proc.create_sql_string_plan_contract()
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute(query_string,(year,crop,operation,year,operation))
        rows=cursor.fetchall()
        for row in rows:
            term=row[0]
            operator=row[1]
            label_string=term+ ':'+operator
            query_string=""" "contract_table_operation" = '%s' and "operation_table_crop" ='%s' and "operation_table_operation" ='%s' and "operation_table_operation_schedule" = '%s'
             and "operation_table_operator_candidate" ='%s'"""     %(operation,u"受託",operation,term,operator)
            list_rule.append([label_string,query_string])
            #print query_string

        return list_rule

    def renderer_map(self):
        layer=self.farmland_table

        list_rule=self.create_renderer_rule_string()
        rule_count=len(list_rule)
        if rule_count>0:
            hsv_delta=240/rule_count
        else:
            hsv_delta=0
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        query_label=u"未設定"
        query_string= '\"contract_table_operation\" ='+ '\''+ self.ui.cmbbox_operation.currentText() +'\''+' and ' '\"operation_table_operation\" is None'
        root_rule.children()[0].setLabel(query_label)
        root_rule.children()[0].setFilterExpression(query_string)
        i=0
        for rule_string in list_rule:
            rule=root_rule.children()[0].clone()
            rule.setLabel(rule_string[0])
            rule.setFilterExpression(rule_string[1])
            color=QColor()
            color.setHsv(240-(i*hsv_delta),255,255)
            rule.symbol().setColor(color)
            root_rule.appendChild(rule)
            i=i+1

        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def create_query_string_operation(self):
        operation=self.ui.cmbbox_operation.currentText()
        query_string=""" "year"=%d and "crop"='%s' and  "operation"='%s' """  %(self.year,u"受託",operation)
        return query_string

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table, self.create_query_string_operation())

    def create_query_string_operate(self):
        operate=self.ui.cmbbox_operation.currentText()
        query_string=""" "year"=%d  and  "operation"='%s' """ %(self.year,operate)
        return query_string

    def set_query_contract_table(self):
        pyqgis_processing.set_query(self.contract_table,self.create_query_string_operate())

    def cellchanged(self):
        try:
            #pyqgis_processing.show_msgbox(u"日付変更")
            print self.ui.tablewidget_plan.currentRow()
        except:
            #pyqgis_processing.show_msgbox(u"エラー")
            print "error"
            pass

    def populate_cmbbox_operate(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operation from contract_operation_master")
        rows=cursor.fetchall()


        self.ui.cmbbox_operation.clear()
        self.ui.cmbbox_operation.addItem("")

        for row in rows:

            self.ui.cmbbox_operation.addItem(row[0])
        db.close()

    def populate_tablewidget(self):
        self.ui.tablewidget_plan.clear()
        self.ui.tablewidget_plan.setSortingEnabled(True)
        headers=[u"依頼者",u"面積",u"播種日",u"品種","RM",u"収穫予定日",u"収穫確認日",u"作業予定者",u"昨年品種"]
        self.ui.tablewidget_plan.setColumnCount(len(headers))
        self.ui.tablewidget_plan.setHorizontalHeaderLabels(headers)
        self.ui.tablewidget_plan.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tablewidget_plan.setRowCount(0)
        row=0
#         dtp1=custome_dtp(0)
#         dtp1.setCalendarPopup(True)
#         dtp1.setDate(datetime.date.today())
#         dtp1.dateChanged.connect(lambda: self.date_changed(dtp1))
        for item in self.make_list_client():
            sub_item=self.get_current_plan(self.year, self.ui.cmbbox_operation.currentText(), item[0])
            if sub_item:
                date_plant=datetime.datetime.strptime(sub_item[0], '%Y/%m/%d')
                variety=sub_item[1]
                rm=sub_item[2]
                date_harvest=sub_item[3]
                date_check=datetime.datetime.strptime(sub_item[4], '%Y/%m/%d')
                operator=sub_item[5]
            else:
                date_plant=datetime.date.today()
                variety=""
                rm=0
                date_harvest=datetime.date.today().strftime('%Y/%m/%d')
                #print date_harvest
                date_check=datetime.date.today()
                operator=""
            self.ui.tablewidget_plan.insertRow(row)
            #依頼者
            self.ui.tablewidget_plan.setItem(row,0,QTableWidgetItem(item[0]))
            #面積
            self.ui.tablewidget_plan.setItem(row,1,QTableWidgetItem(str(round(item[1],1),1)))
            #播種日
            dtp1=custome_dtp(copy.deepcopy(row))
            dtp1.setCalendarPopup(True)
            dtp1.setDate(date_plant)
            dtp1.dateChanged.connect(lambda: self.date_plant_changed())
            self.ui.tablewidget_plan.setCellWidget(row,2,dtp1)
            #品種RM
            cmbbox_variety=QComboBox()
            for item1 in self.list_rm:
                cmbbox_variety.addItem(item1[0])
            int_variety = cmbbox_variety.findText(variety, Qt.MatchFixedString)
            #print int_variety
#             cmbbox_variety.setCurrentIndex(int_variety)
#             print cmbbox_variety.currentText()
            cmbbox_variety.currentIndexChanged.connect(lambda: self.variety_changed())
            self.ui.tablewidget_plan.setCellWidget(row,3,cmbbox_variety)
            self.ui.tablewidget_plan.cellWidget(row,3).setCurrentIndex(int_variety)
            #RM
#             cmbbox_rm=QComboBox()
#             cmbbox_rm.addItem("100")
#             cmbbox_rm.addItem("110")
#             cmbbox_rm.addItem("120")
            self.ui.tablewidget_plan.setItem(row,4,QTableWidgetItem(str(rm)))
            #収穫予定日
#             dtp2 =QDateEdit()
#             dtp2.setCalendarPopup(True)
            #dtp2.dateChanged.connect(self.date_change)
            #QObject.connect(dtp2,SIGNAL("dateChanged()"),self.date_change)
            #print date_harvest
            self.ui.tablewidget_plan.setItem(row,5,QTableWidgetItem(date_harvest))
            #収穫確認日
            dtp3 =QDateEdit()
            dtp3.setCalendarPopup(True)
            dtp3.setDate(date_check)
            self.ui.tablewidget_plan.setCellWidget(row,6,dtp3)
            #作業者
            cmbbox_operator=QComboBox()
            db=pyqgis_processing.connect_db()
            cursor=db.cursor()
            cursor.execute("select operator from operator_master ")
            rows=cursor.fetchall()
            for item2 in rows:
                cmbbox_operator.addItem(item2[0])
            int_operator = cmbbox_operator.findText(operator, Qt.MatchFixedString)
#             print int_operator
#             if operator!="":
#                 cmbbox_variety.setCurrentIndex(int_operator)
#             print cmbbox_operator.currentText()
            self.ui.tablewidget_plan.setCellWidget(row,7,cmbbox_operator)
            self.ui.tablewidget_plan.cellWidget(row,7).setCurrentIndex(int_operator)
            #昨年品種
            last_variety=self.get_last_variety(self.year, self.ui.cmbbox_operation.currentText(), item[0])
            if last_variety:
                self.ui.tablewidget_plan.setItem(row,8,QTableWidgetItem(last_variety[0]))
            row=row+1

    def select_landfields(self):
        proc=pyqgis_processing
        try:
            query=""" "contract_table_operation"= '%s' and "contract_table_client" = '%s'"""  %(self.return_key_value())
            selection=self.farmland_table.getFeatures(QgsFeatureRequest().setFilterExpression(query))
            self.farmland_table.setSelectedFeatures([s.id() for s in selection])
        except:
            pass

    def return_key_value(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_plan.item(i,0).isSelected()==True:
                client=self.ui.tablewidget_plan.item(i,0).text()

                break
        key_value=(self.ui.cmbbox_operation.currentText(),client)

        return key_value

    def get_date_harvest(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_plan.item(i,0).isSelected()==True:
                date_harvest=self.ui.tablewidget_plan.item(i,5).text()
                operator=self.ui.tablewidget_plan.cellWidget(i,7).currentText()

                break


        return (date_harvest,operator)


    def return_record(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for i in range(row_count):
            if self.ui.tablewidget_plan.item(i,0).isSelected()==True:
                client=self.ui.tablewidget_plan.item(i,0).text()
                date_plant=self.ui.tablewidget_plan.cellWidget(i,2).date().toString("yyyy/MM/dd")
                variety=self.ui.tablewidget_plan.cellWidget(i,3).currentText()
                rm=int(self.ui.tablewidget_plan.item(i,4).text())
                date_harvest=self.ui.tablewidget_plan.item(i,5).text()
                date_check=self.ui.tablewidget_plan.cellWidget(i,6).date().toString("yyyy/MM/dd")
                operator=self.ui.tablewidget_plan.cellWidget(i,7).currentText()

                break
        key_value=(self.year,self.ui.cmbbox_operation.currentText(),client,date_plant,variety,rm,date_harvest,date_check,operator)

        return key_value

    def update_row_operation_table(self):
        crop=u"受託"
        operation=self.ui.cmbbox_operation.currentText()
#         term_start=self.ui.dateEdit_start.dateTime().toString("yyyy/MM/dd")
#         term_end=self.ui.dateEdit_end.dateTime().toString("yyyy/MM/dd")
#         term_start_= "{0:02d}".format(self.ui.dateEdit_start.date().month())+ "/"  +"{0:02d}".format(self.ui.dateEdit_start.date().day())
#         term_end_="{0:02d}".format(self.ui.dateEdit_end.date().month())+"/"+"{0:02d}".format(self.ui.dateEdit_end.date().day())

        db=pyqgis_processing.connect_db()
        year=self.year
        list_farmland=pyqgis_processing.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象委託者を選択してください")
            return

        plan=self.get_date_harvest()
        term=plan[0]
        operator=plan[1]

        for farmland in list_farmland:
            farmland_id=farmland[0]
            farmland_code=farmland[1]


            request=QgsFeatureRequest().setFilterFid(farmland_id)
            feature=self.farmland_table.getFeatures(request).next()
            #既存計画値のチェック
            if feature[u'operation_table_operation_schedule'] is not None:
                if feature[u'operation_table_progress'] ==u"未完了":
                    exist_row=(year,farmland_code,crop,operation)
                    db.execute('delete from operation_table where year=? and farmland_code=? and crop=? and operation=?',exist_row)
                    db.commit()
                    new_row=(year,farmland_code,crop,operation,term,term,term,operator,u"未完了")
                    #ここで作業状況のデフォルト値「未完了」を入れておく
                    db.execute('insert into operation_table (year,farmland_code,crop,operation,schedule_start,schedule_end,operation_schedule,operator_candidate,progress) values (?,?,?,?,?,?,?,?,?)',new_row)
                    db.commit()
            else:
                new_row=(year,farmland_code,crop,operation,term,term,term,operator,u"未完了")
                #ここで作業状況のデフォルト値「未完了」を入れておく
                db.execute('insert into operation_table (year,farmland_code,crop,operation,schedule_start,schedule_end,operation_schedule,operator_candidate,progress) values (?,?,?,?,?,?,?,?,?)',new_row)
                db.commit()
        client=self.return_key_value()[1]
        db=pyqgis_processing.connect_db()
        if self.get_current_plan(year, operation, client):
            delete_row=(year, operation, client)
            db.execute('delete from variety_rm_plan_table where year=? and operation=? and client = ? ',delete_row)
            db.commit()
        new_row=self.return_record()
        db.execute('insert into variety_rm_plan_table (year,operation,client,date_plant,variety,rm,date_harvest,date_check,operator) values (?,?,?,?,?,?,?,?,?)',new_row)
        db.commit()




        self.renderer_map()


    def calc_date_harvest(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for row in range(row_count):
            date_plant=self.ui.tablewidget_plan.cellWidget(row,2).dateTime().toPyDate()
            rm=int(self.ui.tablewidget_plan.item(row,4))
            date_harvest=date_plant+datetime.timedelta(days=rm)
            self.ui.tablewidget_plan.setItem(row,5,QTableWidgetItem(date_harvest.strftime('%Y/%m/%d')))

    def get_rm(self,variety):
        for item in self.list_rm:
            if item[0]==variety:
                rm=item[1]
                break
        return rm


    #20181226ここまで
    def variety_changed(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for i in range(row_count):
            variety=self.ui.tablewidget_plan.cellWidget(i,3).currentText()
            for item in self.list_rm:
                if item[0]==variety:
                    rm=item[1]
                    self.ui.tablewidget_plan.setItem(i,4,QTableWidgetItem(str(rm)))
                    break
        row_count=self.ui.tablewidget_plan.rowCount()
        for row in range(row_count):
            date_plant=self.ui.tablewidget_plan.cellWidget(row,2).dateTime().toPyDateTime()
            try:
                rm=int(self.ui.tablewidget_plan.item(row,4).text())
                date_harvest=date_plant+datetime.timedelta(days=rm)
                self.ui.tablewidget_plan.setItem(row,5,QTableWidgetItem(date_harvest.strftime('%Y/%m/%d')))
            except:
                pass

    def date_plant_changed(self):
        row_count=self.ui.tablewidget_plan.rowCount()
        for row in range(row_count):
            date_plant=self.ui.tablewidget_plan.cellWidget(row,2).dateTime().toPyDateTime()
            rm=int(self.ui.tablewidget_plan.item(row,4).text())
            date_harvest=date_plant+datetime.timedelta(days=rm)
            self.ui.tablewidget_plan.setItem(row,5,QTableWidgetItem(date_harvest.strftime('%Y/%m/%d')))





    def get_current_plan(self,year,operation,client):
        proc=pyqgis_processing
        db=proc.connect_db()
        query=""" select date_plant,variety,rm,date_harvest,date_check,operator from variety_rm_plan_table where year=? and operation=? and client=?"""
        key=(year,operation,client)
        cursor=db.cursor()
        cursor.execute(query,key)
        rows=cursor.fetchone()
        return rows

    def get_last_variety(self,year,operation,client):
        proc=pyqgis_processing
        db=proc.connect_db()
        query=""" select variety from variety_rm_plan_table where year=? and operation=? and client=?"""
        key=(year-1,operation,client)
#         print operation,client
        cursor=db.cursor()
        cursor.execute(query,key)
        row=cursor.fetchone()
        return row

    def date_changed(self,dtp):
        print dtp.return_row()
        print self.ui.tablewidget_plan.currentRow()

    def make_list_client(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        query=""" select client, total (operation_area) from contract_table where year=? and operation=? group by client"""
        key=(self.year,self.ui.cmbbox_operation.currentText())
        cursor=db.cursor()
        cursor.execute(query,key)
        rows=cursor.fetchall()
        return rows

    #テーブルの存在を確認、無ければ追加
    def check_tables(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        #variety_rm_plan_table
        cursor = db.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % "variety_rm_plan_table")
        if cursor.fetchone() == None: #存在してないので作る
            db.execute("""CREATE TABLE %s(id  integer NOT NULL PRIMARY KEY,
                                          year integer,
                                          operation TEXT,
                                          client text,
                                          date_plant text,
                                          variety text,
                                          rm integer,
                                          date_harvest text,
                                          date_check text,
                                          operator text,
                                          variety_last_year text)""" % "variety_rm_plan_table")
            db.commit()



        db.close()

    def load_rm(self):
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()
        table_csv=open(path + "/"+u"品種RM.csv")
        data=csv.reader(table_csv)
        header = data.next()

        for row in data:
            self.list_rm.append([row[0].decode("cp932"),row[1].decode("cp932")])

   # def variety_changed(self):

    def export_csv(self):

        if self.ui.cmbbox_operation.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return


        crop=u"受託"
        year=self.year
        operation=self.ui.cmbbox_operation.currentText()



#         client=self.return_key_value_contract()[1]
#         term=self.ui.cmbbox_operation_term.currentText()
#         term_r=term.replace('/', '-')
#         operator=self.ui.cmbbox_operator.currentText()
        prj_file=QFileInfo(QgsProject.instance().fileName())
        path=prj_file.absolutePath()

        if not os.path.exists(path+u"/播種・品種・収穫計画"):
            os.mkdir(path+u"/播種・品種・収穫計画")
        path+=u"/播種・品種・収穫計画"

        filename= path + "/"+"%s.csv"  % (str(year)+'_'+ operation +  u'_播種・品種・収穫計画')

        table_csv=open(filename, 'w')
        dataWriter = csv.writer(table_csv,delimiter=',',lineterminator="\n")
        list_csv=[]
        field_name1=u"依頼者"
        field_name2=u"面積"
        field_name3=u"播種日"
        field_name4=u"品種"
        field_name5="RM"
        field_name6=u"収穫予定日"
        field_name7=u"収穫確認日"
        field_name8=u"作業予定者"
        field_name9=u"昨年品種"

        list_csv.append([field_name1.encode('"cp932"'),field_name2.encode('"cp932"'),field_name3.encode('"cp932"'),
                         field_name4.encode('"cp932"'),field_name5.encode('"cp932"'),field_name6.encode('"cp932"'),field_name7.encode('"cp932"'),field_name8.encode('"cp932"'),field_name9.encode('"cp932"')])


        row_count=self.ui.tablewidget_plan.rowCount()
        for i in range(row_count):

            client=self.ui.tablewidget_plan.item(i,0).text()
            area=float(self.ui.tablewidget_plan.item(i,1).text())
            date_plant=self.ui.tablewidget_plan.cellWidget(i,2).date().toString("yyyy/MM/dd")
            try:
                variety=self.ui.tablewidget_plan.cellWidget(i,3).currentText()
            except:
                variety=u"未定"
            rm=int(self.ui.tablewidget_plan.item(i,4).text())
            date_harvest=self.ui.tablewidget_plan.item(i,5).text()
            date_check=self.ui.tablewidget_plan.cellWidget(i,6).date().toString("yyyy/MM/dd")
            try:
                operator=self.ui.tablewidget_plan.cellWidget(i,7).currentText()
            except:
                operator=u"未定"
            try:
                last_variety=self.ui.tablewidget_plan.item(i,8).text()
            except:
                last_variety=u""

            list_csv.append([client.encode('"cp932"'),area,date_plant.encode('"cp932"'),
                                 variety.encode('"cp932"'),rm,date_harvest.encode('"cp932"'),date_check.encode('"cp932"'),operator.encode('"cp932"'),last_variety.encode('"cp932"')])




        dataWriter.writerows(list_csv)
        table_csv.close()

        if sys.platform == "win32":
            os.startfile(filename)
        else:
            opener ="open" if sys.platform == "darwin" else "xdg-open"
            subprocess.call([opener, filename])


class custome_dtp(QDateEdit):
    #currentRow=-1
    def __init__(self,row_index,parent=None):
        QDateEdit.__init__(self,parent)

        self.currentRow=row_index

    def return_row(self):
        return self.currentRow

















