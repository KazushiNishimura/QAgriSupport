# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'update_area_ui.ui'
#
# Created: Mon Apr 24 15:28:23 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(577, 521)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.groupBox_2)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.btn_write_geom = QtGui.QPushButton(self.groupBox_2)
        self.btn_write_geom.setObjectName(_fromUtf8("btn_write_geom"))
        self.horizontalLayout.addWidget(self.btn_write_geom)
        self.gridLayout.addWidget(self.groupBox_2, 7, 0, 1, 2)
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.lbl_landfield = QtGui.QLabel(Dialog)
        self.lbl_landfield.setText(_fromUtf8(""))
        self.lbl_landfield.setObjectName(_fromUtf8("lbl_landfield"))
        self.gridLayout.addWidget(self.lbl_landfield, 1, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.btn_update_area_selected = QtGui.QPushButton(self.groupBox_3)
        self.btn_update_area_selected.setObjectName(_fromUtf8("btn_update_area_selected"))
        self.gridLayout_3.addWidget(self.btn_update_area_selected, 3, 1, 1, 1)
        self.btn_update_all = QtGui.QPushButton(self.groupBox_3)
        self.btn_update_all.setObjectName(_fromUtf8("btn_update_all"))
        self.gridLayout_3.addWidget(self.btn_update_all, 4, 1, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_3.addItem(spacerItem1, 1, 1, 1, 1)
        self.label_3 = QtGui.QLabel(self.groupBox_3)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_3.addWidget(self.label_3, 1, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(self.groupBox_3)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.tablewidget_land = QtGui.QTableWidget(self.groupBox)
        self.tablewidget_land.setObjectName(_fromUtf8("tablewidget_land"))
        self.tablewidget_land.setColumnCount(0)
        self.tablewidget_land.setRowCount(0)
        self.gridLayout_2.addWidget(self.tablewidget_land, 0, 0, 1, 1)
        self.gridLayout_3.addWidget(self.groupBox, 0, 0, 1, 2)
        self.lbl_area = QtGui.QLabel(self.groupBox_3)
        self.lbl_area.setText(_fromUtf8(""))
        self.lbl_area.setObjectName(_fromUtf8("lbl_area"))
        self.gridLayout_3.addWidget(self.lbl_area, 2, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_3, 4, 0, 1, 2)
        self.groupBox_4 = QtGui.QGroupBox(Dialog)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_4)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.label_6 = QtGui.QLabel(self.groupBox_4)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout_4.addWidget(self.label_6, 0, 0, 1, 1)
        self.btn_area = QtGui.QPushButton(self.groupBox_4)
        self.btn_area.setObjectName(_fromUtf8("btn_area"))
        self.gridLayout_4.addWidget(self.btn_area, 3, 3, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox_4)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_4.addWidget(self.label_2, 2, 0, 1, 1)
        self.cmbbox_kind = QtGui.QComboBox(self.groupBox_4)
        self.cmbbox_kind.setObjectName(_fromUtf8("cmbbox_kind"))
        self.gridLayout_4.addWidget(self.cmbbox_kind, 2, 2, 1, 1)
        self.label_4 = QtGui.QLabel(self.groupBox_4)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout_4.addWidget(self.label_4, 1, 0, 1, 1)
        self.lineEdit_district = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit_district.setObjectName(_fromUtf8("lineEdit_district"))
        self.gridLayout_4.addWidget(self.lineEdit_district, 1, 2, 1, 1)
        self.label_5 = QtGui.QLabel(self.groupBox_4)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout_4.addWidget(self.label_5, 3, 0, 1, 1)
        self.lineEdit_area = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit_area.setObjectName(_fromUtf8("lineEdit_area"))
        self.gridLayout_4.addWidget(self.lineEdit_area, 3, 2, 1, 1)
        self.btn_district = QtGui.QPushButton(self.groupBox_4)
        self.btn_district.setObjectName(_fromUtf8("btn_district"))
        self.gridLayout_4.addWidget(self.btn_district, 1, 3, 1, 1)
        self.btn_kind = QtGui.QPushButton(self.groupBox_4)
        self.btn_kind.setObjectName(_fromUtf8("btn_kind"))
        self.gridLayout_4.addWidget(self.btn_kind, 2, 3, 1, 1)
        self.lineEdit_farmland_code = QtGui.QLineEdit(self.groupBox_4)
        self.lineEdit_farmland_code.setObjectName(_fromUtf8("lineEdit_farmland_code"))
        self.gridLayout_4.addWidget(self.lineEdit_farmland_code, 0, 2, 1, 1)
        self.btn_farmland_code = QtGui.QPushButton(self.groupBox_4)
        self.btn_farmland_code.setObjectName(_fromUtf8("btn_farmland_code"))
        self.gridLayout_4.addWidget(self.btn_farmland_code, 0, 3, 1, 1)
        self.gridLayout.addWidget(self.groupBox_4, 2, 0, 1, 2)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "圃場基本情報", None))
        self.groupBox_2.setTitle(_translate("Dialog", "位置情報の算出・書込み（モバイルアプリとの連携に必要）", None))
        self.btn_write_geom.setText(_translate("Dialog", "位置情報を算出・書き込む", None))
        self.label.setText(_translate("Dialog", "選択中圃場", None))
        self.groupBox_3.setTitle(_translate("Dialog", "農地台帳連携", None))
        self.btn_update_area_selected.setText(_translate("Dialog", "選択中圃場の面積を更新", None))
        self.btn_update_all.setText(_translate("Dialog", "全圃場の面積を更新", None))
        self.label_3.setText(_translate("Dialog", "実利用面積計(m2)", None))
        self.groupBox.setTitle(_translate("Dialog", "選択圃場構成農地", None))
        self.groupBox_4.setTitle(_translate("Dialog", "圃場基本データ", None))
        self.label_6.setText(_translate("Dialog", "圃場名", None))
        self.btn_area.setText(_translate("Dialog", "更新", None))
        self.label_2.setText(_translate("Dialog", "種別", None))
        self.label_4.setText(_translate("Dialog", "地区名", None))
        self.label_5.setText(_translate("Dialog", "面積", None))
        self.btn_district.setText(_translate("Dialog", "更新", None))
        self.btn_kind.setText(_translate("Dialog", "更新", None))
        self.btn_farmland_code.setText(_translate("Dialog", "更新", None))

