# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from register_report_ui import Ui_Dialog
from QAgriSupport import pyqgis_processing
import sqlite3
import datetime


class Dialog(QDialog,Ui_Dialog):
    def __init__(self,iface,y):
        QDialog.__init__(self)
        self.iface=iface
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.year=y
        self.attribute_table=None
        proc=pyqgis_processing
        self.farmland_table=proc.get_farmland_table()
        self.operation_table=proc.get_operation_table()

        #proc.remove_join()
        proc.clear_query(self.farmland_table)
        proc.clear_query(self.operation_table)
        proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\' or "kind"=\'受託地\'')
        proc.set_query(self.operation_table,'"year"='+str(self.year))

        #proc.add_join_operation_table()
        #proc.set_query(self.farmland_table,u'"kind"=\'経営耕地\'  and  "operation_table_progress" =\'未完了\' ')

        proc.hide_all_columns(self.farmland_table)
        proc.set_column_visibility(self.farmland_table, 'operation_table_operator', True)
        proc.set_column_visibility(self.farmland_table, 'operation_table_operation_day', True)
        proc.set_column_visibility(self.farmland_table, 'operation_table_progress', True)


        proc.show_columns_farmland_table(self.farmland_table)
        proc.show_columns_operation_table(self.farmland_table)
        proc.set_alias_farmland_table(self.farmland_table)
        proc.set_alias_operation_table(self.farmland_table)

        self.ui.dateEdit_operation_day.setDate(datetime.date.today())
        self.populate_cmbbox_crop()
        self.populate_cmbbox_operator()
        self.populate_table_suboperator()
        self.populate_table_machine()



        self.connect(self.ui.cmbbox_crop,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_crop_change)
        self.connect(self.ui.cmbbox_operation,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_operation_change)
        self.connect(self.ui.cmbbox_operation_term,SIGNAL("currentIndexChanged(const QString&)"),self.cmbbox_term_change)
        self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.render_map)
        self.connect(self.ui.cmbbox_operator_candidate,SIGNAL("currentIndexChanged(const QString&)"),self.check_variety)
        self.connect(self.ui.btn_insert,SIGNAL("clicked()"),self.insert_row)
        self.connect(self.ui.btn_show_attribute_table,SIGNAL("clicked()"),self.show_attribute_table)
        self.connect(self.ui.chkbox_variety,SIGNAL("stateChanged (int)"),self.check_variety)
        self.connect(self.ui.btn_add,SIGNAL("clicked()"),self.add_row)
        self.connect(self.ui.btn_delete,SIGNAL("clicked()"),self.delete_row)

    def check_variety(self):
        if self.ui.chkbox_variety.checkState()==Qt.Checked:
            #self.add_rule_variety()
            pyqgis_processing.add_rule_variety(self.ui.cmbbox_crop.currentText())
            #print self.ui.chkbox_variety.checkState()
        elif self.ui.chkbox_variety.checkState()==Qt.Unchecked:
            #self.remove_variety()
            self.render_map()
           # print self.ui.chkbox_variety.checkState()


    def populate_cmbbox_operator(self):

        proc = pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operator from operator_master")
        rows=cursor.fetchall()
        self.ui.cmbbox_operator.clear()
        #self.ui.cmbbox_operator.addItem("")
        for row in rows:
            self.ui.cmbbox_operator.addItem(row[0])
        db.close()

    def populate_cmbbox_crop(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select crop from crop_master")
        rows=cursor.fetchall()

        self.ui.cmbbox_crop.clear()
        self.ui.cmbbox_crop.addItem("")
        list_crop=[]
        for row in rows:
            if row[0] not in list_crop:
                list_crop.append(row[0])
                self.ui.cmbbox_crop.addItem(row[0])

        db.close()
        self.ui.cmbbox_crop.addItem(u"受託")

    def populate_cmbbox_operation(self):
        proc=pyqgis_processing
        if self.ui.cmbbox_crop.currentText()==u"受託":
            db=proc.connect_db()
            #crop=self.ui.cmbbox_crop.currentText()
            cursor=db.cursor()
            cursor.execute("select operation from contract_operation_master")
            rows=cursor.fetchall()
            self.ui.cmbbox_operation.clear()
            for row in rows:
                self.ui.cmbbox_operation.addItem(row[0])
            db.close()
        else:
            db=proc.connect_db()
            crop=self.ui.cmbbox_crop.currentText()
            cursor=db.cursor()
            cursor.execute("select operation from cultivation_calendar_master where crop = ?",(crop,))
            rows=cursor.fetchall()
            self.ui.cmbbox_operation.clear()
            for row in rows:
                self.ui.cmbbox_operation.addItem(row[0])
            db.close()

    def cmbbox_crop_change(self):
        self.populate_cmbbox_operation()
        self.populate_table_material()

    def cmbbox_operation_change(self):
        self.populate_cmbbox_term()
        self.set_query_operation_table()

    def cmbbox_term_change(self):
        self.populate_cmbbox_operator_candidate()

    def populate_cmbbox_term(self):
        self.ui.cmbbox_operation_term.clear()
        list_schedule=[]
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        cursor.execute("select operation_schedule from operation_table where year=? and crop=? and operation=?",(year,crop,operation,))
        rows=cursor.fetchall()
        for row in rows:
            if row[0] not in list_schedule:
                list_schedule.append(row[0])

        for item in list_schedule:
            self.ui.cmbbox_operation_term.addItem(item)

        db.close()

    def populate_cmbbox_operator_candidate(self):
        self.ui.cmbbox_operator_candidate.clear()
        proc=pyqgis_processing
        db=proc.connect_db()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        cursor=db.cursor()
        cursor.execute("select operator_candidate from operation_table where year=? and crop = ? and operation=? and operation_schedule=?",(year,crop,operation,term,))
        rows=cursor.fetchall()
        list_operator=[]
        for row in rows:
            if row[0] not in list_operator:
                list_operator.append(row[0])

        for item in list_operator:
            self.ui.cmbbox_operator_candidate.addItem(item)

        db.close()

    def populate_table_suboperator(self):
        proc =pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select operator from operator_master")
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.tableWidget_suboperator.clear()
        self.ui.tableWidget_suboperator.setSortingEnabled(True)
        self.ui.tableWidget_suboperator.setRowCount(row_count)
        headers=[u"選択",u"作業者名"]
        self.ui.tableWidget_suboperator.setColumnCount(len(headers))
        self.ui.tableWidget_suboperator.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            chk=QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tableWidget_suboperator.setItem(i,0,chk)
            self.ui.tableWidget_suboperator.setItem(i,1,QTableWidgetItem(row[0]))
            i=i+1
        self.ui.tableWidget_suboperator.resizeColumnsToContents()

        db.close()

    def populate_table_machine(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        cursor.execute("select machine from machine_master")
        rows=cursor.fetchall()
        row_count=len(rows)
        self.ui.tableWidget_machine.clear()
        self.ui.tableWidget_machine.setSortingEnabled(True)
        self.ui.tableWidget_machine.setRowCount(row_count)
        headers=[u"選択",u"機械名"]
        self.ui.tableWidget_machine.setColumnCount(len(headers))
        self.ui.tableWidget_machine.setHorizontalHeaderLabels(headers)


        i=0
        for row in rows:
            chk=QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tableWidget_machine.setItem(i,0,chk)
            self.ui.tableWidget_machine.setItem(i,1,QTableWidgetItem(row[0]))
            i=i+1
        self.ui.tableWidget_machine.resizeColumnsToContents()
        db.close()

    def populate_table_material(self):
        proc=pyqgis_processing
        db=proc.connect_db()
        cursor=db.cursor()
        crop=self.ui.cmbbox_crop.currentText()
        cursor.execute("select material ,package_unit from material_master where crop= ?",(crop,))
        rows=cursor.fetchall()
        row_count=len(rows)

        self.ui.tableWidget_material.clear()
        self.ui.tableWidget_material.setSortingEnabled(True)
        self.ui.tableWidget_material.setRowCount(row_count)
        headers=[u"選択",u"資材名",u"使用量",u"単位"]
        self.ui.tableWidget_material.setColumnCount(len(headers))
        self.ui.tableWidget_material.setHorizontalHeaderLabels(headers)
        i=0
        for row in rows:
            spbox=QDoubleSpinBox()
            spbox.setSingleStep(0.5)
            chk=QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Unchecked)
            self.ui.tableWidget_material.setItem(i,0,chk)
            self.ui.tableWidget_material.setItem(i,1,QTableWidgetItem(row[0]))
            self.ui.tableWidget_material.setCellWidget(i,2,spbox)
            self.ui.tableWidget_material.setItem(i,3,QTableWidgetItem(row[1]))
            i=i+1
        self.ui.tableWidget_material.resizeColumnsToContents()
        db.close()


    def render_map(self):

        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        term=self.ui.cmbbox_operation_term.currentText()
        operator=self.ui.cmbbox_operator_candidate.currentText()
        label_string=crop+":"+ operation+":"+term+":"+operator+u":未完了"
        query_string='\"operation_table_crop\" = '+ '\''+ crop + '\'' + 'and '+ '\"operation_table_operation\" =' + '\''+operation + '\'' \
        + ' and ' + '\"operation_table_operation_schedule\" =' + '\''+ term + '\''+ ' and ' + '\"operation_table_operator_candidate\" ='+ '\'' +operator + '\'' + \
        ' and ' + u'\"operation_table_progress\" =  \'未完了\''

        layer=self.farmland_table
        symbol=QgsSymbolV2.defaultSymbol(layer.geometryType())
        renderer=QgsRuleBasedRendererV2(symbol)
        root_rule=renderer.rootRule()
        default_color=QColor()
        default_color.setHsv(0,255,255)
        root_rule.children()[0].symbol().setColor(default_color)
        root_rule.children()[0].setLabel(label_string)
        root_rule.children()[0].setFilterExpression(query_string)


        label_string=crop+":"+ operation+":"+term+":"+operator+u":完了"
        query_string='\"operation_table_crop\" = '+ '\''+ crop + '\'' + 'and '+ '\"operation_table_operation\" =' + '\''+operation + '\'' \
        + ' and ' + '\"operation_table_operation_schedule\" =' + '\''+ term + '\''+ ' and ' + '\"operation_table_operator_candidate\" ='+ '\'' +operator + '\'' + \
        ' and ' + u'\"operation_table_progress\" =  \'完了\''

        rule=root_rule.children()[0].clone()
        rule.setLabel(label_string)
        rule.setFilterExpression(query_string)
        color=QColor()
        color.setHsv(240,255,255)
        rule.symbol().setColor(color)
        root_rule.appendChild(rule)

        layer.setRendererV2(renderer)
        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def create_query_string_operation(self):
        query_string='\"year\" ='+str(self.year)+ ' and ('
        operation=self.ui.cmbbox_operation.currentText()
        crop=self.ui.cmbbox_crop.currentText()
        query_string=query_string+'\"crop\" =' + '\''+ crop + '\' and ' +'\"operation\" =' + '\''+ operation + '\'' + ')'
        return query_string

    def set_query_operation_table(self):
        pyqgis_processing.set_query(self.operation_table, self.create_query_string_operation())

    def insert_row(self):
        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        operator=self.ui.cmbbox_operator.currentText()
        operation_day=self.ui.dateEdit_operation_day.date().toString("yyyy/MM/dd")
        #入力すべき補助者リストを作成
        suboperator=[]
        row_count=self.ui.tableWidget_suboperator.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_suboperator.item(i,0).checkState()==Qt.Checked:
                suboperator.append(self.ui.tableWidget_suboperator.item(i,1).text())

        #入力すべき機械リストを作成
        machine=[]
        row_count=self.ui.tableWidget_machine.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_machine.item(i,0).checkState()==Qt.Checked:
                machine.append(self.ui.tableWidget_machine.item(i,1).text())

        #入力すべき資材・使用量リストを作成
        material=[]
        row_count=self.ui.tableWidget_material.rowCount()
        for i in range(row_count):
            if self.ui.tableWidget_material.item(i,0).checkState()==Qt.Checked:
                name=self.ui.tableWidget_material.item(i,1).text()
                #print name
                amount=str(self.ui.tableWidget_material.cellWidget(i,2).value())
                #amount=str(self.ui.tableWidget_material.item(i,2).value())
                #print amount
                material.append([name,amount])
        #print material



        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]
            sql=u""" update operation_table set  operator=?,operation_day=?, progress = '完了'
            where year=? and crop = ? and operation =? and farmland_code=?"""
            update_row=(operator,operation_day,year,crop,operation,farmland_code)
            db.execute(sql,update_row)
        db.commit()


        #作業者実績台帳に作業者一覧を挿入
        #まずは既存レコードがあれば、全削除
        delete_row=(year,crop,operation,operator,operation_day)
        sql="""delete from operator_record_table where year=? and crop=? and operation=?  and operator_main=? and operation_day=?"""
        db.execute(sql,delete_row)
        #メイン作業者を登録
        insert_row=(year,crop,operation,operator,operator,operation_day)
        sql=u"""insert into operator_record_table (year,crop,operation,operator_main,operator,operator_class,operation_day) values(?,?,?,?,?,'オペレータ',?)"""
        db.execute(sql,insert_row)
        db.commit()
        #補助者を登録→補助者gboxが有効な時のみ
        if self.ui.gbox_operator_sub.isChecked()==True:
            for sub in suboperator:
                insert_row=(year,crop,operation,operator,sub,operation_day)
                sql=u"""insert into operator_record_table (year,crop,operation,operator_main,operator,operator_class,operation_day) values(?,?,?,?,?,'補助者',?)"""
                db.execute(sql,insert_row)
            db.commit()

        #使用機材の登録
        #まずは既存レコードがあれば、全削除
        delete_row=(year,crop,operation,operator,operation_day)
        sql="""delete from machine_use_table where year=? and crop=? and operation=?  and operator_main=? and operation_day=?"""
        db.execute(sql,delete_row)
        db.commit()
        #機材の追加→機材gboxが有効な時のみ
        if self.ui.gbox_machine.isChecked()==True:
            for item in machine:
                insert_row=(year,crop,operation,operator,item,operation_day)
                sql=u"""insert into machine_use_table (year,crop,operation,operator_main,machine,operation_day) values(?,?,?,?,?,?)"""
                db.execute(sql,insert_row)
            db.commit()

        #使用資材の登録
        #既存レコードの削除
        delete_row=(year,crop,operation,operator,operation_day)
        sql="""delete from material_use_table where year=? and crop=? and operation=?  and operator_main=? and operation_day=?"""
        db.execute(sql,delete_row)
        db.commit()
        #使用資材の登録→→資材gboxが有効な時のみ
        if self.ui.gbox_material.isChecked():
            for item in material:
                #print item[0]
                #print item[1]
                insert_row=(year,crop,operation,operator,item[0],item[1],operation_day)
                sql=u"""insert into material_use_table (year,crop,operation,operator_main,material,material_use_amount,operation_day) values(?,?,?,?,?,?,?)"""
                db.execute(sql,insert_row)
            db.commit()

        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

        #台帳テーブルへの登録
        #既存レコードの削除
        delete_row=(crop,operation,operator,operation_day)
        sql="""delete from report_table where crop=? and operation=?  and operator=? and operation_day=?"""
        db.execute(sql,delete_row)
        db.commit()
        #登録
        insert_row=(crop,operation,operator,operation_day)
        sql=u"""insert into report_table (crop,operation,operator,operation_day) values(?,?,?,?)"""
        db.execute(sql,insert_row)
        db.commit()
        db.close()

    def show_attribute_table(self):
        if self.ui.cmbbox_crop.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作物を選択してください")
            return
        if self.ui.cmbbox_operation.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業を選択してください")
            return
        if self.ui.cmbbox_operation_term.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象予定期間を選択してください")
            return
        if self.ui.cmbbox_operator_candidate.currentText()=="":
            pyqgis_processing.show_msgbox(u"対象作業予定者を選択してください")
            return
        pyqgis_processing.clear_attributetable()
        pyqgis_processing.clear_attributetable()
        layer=self.farmland_table
        term=self.ui.cmbbox_operation_term.currentText()
        operator=self.ui.cmbbox_operator_candidate.currentText()
        query= """ "operation_table_operation_schedule"= """ + "\'" + term + "\' and " +""" "operation_table_operator_candidate"= """ + "\'" + operator + "\'"

        self.attribute_table=iface.showAttributeTable(layer,query)

    def none_attribute_table(self):
        self.attribute_table=None

    def add_row(self):
        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        operator=self.ui.cmbbox_operator.currentText()
        operation_day=self.ui.dateEdit_operation_day.date().toString("yyyy/MM/dd")

        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]
            sql=u""" update operation_table set  operator=?,operation_day=?, progress = '完了'
            where year=? and crop = ? and operation =? and farmland_code=?"""
            update_row=(operator,operation_day,year,crop,operation,farmland_code)
            db.execute(sql,update_row)
        db.commit()

        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()

    def delete_row(self):
        #print self.ui.tableWidget_material.item(0,2)
        proc=pyqgis_processing
        db=proc.connect_db()
        year=self.year
        crop=self.ui.cmbbox_crop.currentText()
        operation=self.ui.cmbbox_operation.currentText()
        operator=self.ui.cmbbox_operator.currentText()
        operation_day=self.ui.dateEdit_operation_day.date().toString("yyyy/MM/dd")

        #選択圃場を取得
        list_farmland=proc.get_selected_features_farmland_code(self.farmland_table)
        if len(list_farmland)==0:
            pyqgis_processing.show_msgbox(u"対象圃場を選択してください")
            return
        #選択圃場に完了値を入力
        for farmland in list_farmland:
            farmland_code=farmland[1]
            sql=u""" update operation_table set  operator=?,operation_day=?, progress = '未完了'
            where year=? and crop = ? and operation =? and farmland_code=?"""
            update_row=(None,None,year,crop,operation,farmland_code)
            db.execute(sql,update_row)
        db.commit()

        self.farmland_table.dataProvider().forceReload()
        self.farmland_table.triggerRepaint()










