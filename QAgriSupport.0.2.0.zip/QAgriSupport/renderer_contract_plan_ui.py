# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'renderer_contract_plan_ui.ui'
#
# Created: Tue Jun 20 11:06:16 2017
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(309, 376)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.spbox_year = QtGui.QSpinBox(self.groupBox)
        self.spbox_year.setMaximum(3000)
        self.spbox_year.setObjectName(_fromUtf8("spbox_year"))
        self.gridLayout_2.addWidget(self.spbox_year, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridLayout_3 = QtGui.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.cmbbox_operate = QtGui.QComboBox(self.groupBox_2)
        self.cmbbox_operate.setObjectName(_fromUtf8("cmbbox_operate"))
        self.gridLayout_3.addWidget(self.cmbbox_operate, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_2, 1, 0, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(Dialog)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.gridLayout_4 = QtGui.QGridLayout(self.groupBox_3)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tablewidget_contract = QtGui.QTableWidget(self.groupBox_3)
        self.tablewidget_contract.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.tablewidget_contract.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.tablewidget_contract.setObjectName(_fromUtf8("tablewidget_contract"))
        self.tablewidget_contract.setColumnCount(0)
        self.tablewidget_contract.setRowCount(0)
        self.gridLayout_4.addWidget(self.tablewidget_contract, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_3, 2, 0, 1, 1)
        self.btn_show_table = QtGui.QPushButton(Dialog)
        self.btn_show_table.setObjectName(_fromUtf8("btn_show_table"))
        self.gridLayout.addWidget(self.btn_show_table, 3, 0, 1, 1)
        self.btn_export_csv = QtGui.QPushButton(Dialog)
        self.btn_export_csv.setObjectName(_fromUtf8("btn_export_csv"))
        self.gridLayout.addWidget(self.btn_export_csv, 4, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "作業受託予定・実績", None))
        self.groupBox.setTitle(_translate("Dialog", "対象年度", None))
        self.groupBox_2.setTitle(_translate("Dialog", "対象作業", None))
        self.groupBox_3.setTitle(_translate("Dialog", "受託一覧", None))
        self.btn_show_table.setText(_translate("Dialog", "テーブル表示", None))
        self.btn_export_csv.setText(_translate("Dialog", "csv出力", None))

